// ═══════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════
const PROXIES      = ['', 'https://corsproxy.io/?url=', 'https://api.allorigins.win/raw?url='];
const ESPN         = 'https://site.api.espn.com/apis/site/v2/sports';

const LEAGUES = [
  {sport:'basketball',league:'nba',                    label:'NBA 🏀',       dot:'nba',    oddsKey:'basketball_nba'},
  {sport:'football',  league:'nfl',                    label:'NFL 🏈',       dot:'nfl',    oddsKey:'americanfootball_nfl'},
  {sport:'baseball',  league:'mlb',                    label:'MLB ⚾',       dot:'mlb',    oddsKey:'baseball_mlb'},
  {sport:'hockey',    league:'nhl',                    label:'NHL 🏒',       dot:'nhl',    oddsKey:'icehockey_nhl'},
  {sport:'football',  league:'college-football',       label:'NCAAF 🏈',     dot:'ncaa',   oddsKey:null},
  {sport:'basketball',league:'mens-college-basketball',label:'NCAAB 🏀',     dot:'ncaa',   oddsKey:null},
  {sport:'soccer',    league:'usa.1',                  label:'MLS ⚽',       dot:'soccer', oddsKey:'soccer_usa_mls'},
  {sport:'soccer',    league:'eng.1',                  label:'EPL ⚽',       dot:'soccer', oddsKey:'soccer_epl'},
  {sport:'soccer',    league:'uefa.champions',         label:'UCL ⚽',       dot:'soccer', oddsKey:'soccer_uefa_champs_league'},
  {sport:'soccer',    league:'esp.1',                  label:'La Liga ⚽',   dot:'soccer', oddsKey:'soccer_spain_la_liga'},
  {sport:'soccer',    league:'ger.1',                  label:'Bundesliga ⚽',dot:'soccer', oddsKey:'soccer_germany_bundesliga'},
  {sport:'soccer',    league:'ita.1',                  label:'Serie A ⚽',   dot:'soccer', oddsKey:'soccer_italy_serie_a'},
];

// Sport → which stats columns to show in the player stats table
const SPORT_STAT_CONFIGS = {
  basketball: {
    cols: ['min','pts','reb','ast','stl','blk','to','fg'],
    labels: {min:'MIN',pts:'PTS',reb:'REB',ast:'AST',stl:'STL',blk:'BLK',to:'TO',fg:'FG'},
    propStats: ['pts','reb','ast'],
    // ESPN stat key → {label, fallbackLine} — real lines fetched per-player from season avgs
    propDefs: {pts:{label:'PTS',fb:14.5}, reb:{label:'REB',fb:5.5}, ast:{label:'AST',fb:3.5}},
  },
  football: {
    cols: ['pasYds','pasTD','passInt','rushYds','rushTD','recYds','recTD','rec'],
    labels: {pasYds:'PASS YDS',pasTD:'TD',passInt:'INT',rushYds:'RUSH YDS',rushTD:'TD',recYds:'REC YDS',recTD:'TD',rec:'REC'},
    propStats: ['pasYds','rushYds','recYds'],
    propDefs: {pasYds:{label:'PASS YDS',fb:220.5}, rushYds:{label:'RUSH YDS',fb:55.5}, recYds:{label:'REC YDS',fb:35.5}},
  },
  baseball: {
    cols: ['ab','h','r','hr','rbi','bb','so','avg'],
    labels: {ab:'AB',h:'H',r:'R',hr:'HR',rbi:'RBI',bb:'BB',so:'SO',avg:'AVG'},
    propStats: ['h','hr','rbi'],
    propDefs: {h:{label:'HITS',fb:0.5}, hr:{label:'HR',fb:0.5}, rbi:{label:'RBI',fb:0.5}},
  },
  hockey: {
    cols: ['g','a','pts','plusMinus','pim','shots','toi'],
    labels: {g:'G',a:'A',pts:'PTS',plusMinus:'+/-',pim:'PIM',shots:'SOG',toi:'TOI'},
    propStats: ['g','a','pts','shots'],
    propDefs: {g:{label:'GOALS',fb:0.5}, a:{label:'ASSISTS',fb:0.5}, pts:{label:'POINTS',fb:0.5}, shots:{label:'SHOTS',fb:2.5}},
  },
  soccer: {
    cols: ['goals','assists','shots','shotsOnTarget','fouls','yellowCards'],
    labels: {goals:'G',assists:'A',shots:'SHOTS',shotsOnTarget:'SOT',fouls:'FOULS',yellowCards:'YC'},
    propStats: ['goals','shots','shotsOnTarget'],
    propDefs: {goals:{label:'GOALS',fb:0.5}, shots:{label:'SHOTS',fb:2.5}, shotsOnTarget:{label:'SOT',fb:1.5}},
  },
};

// ═══════════════════════════════════════════════════════
// STATIC ODDS FALLBACK
// Typical lines used when ESPN & external API return nothing
// spread = favourite's typical cover line, total = typical game total
// ═══════════════════════════════════════════════════════
const STATIC_ODDS = {
  nba:                    { spread: '-3.5',  total: 'O/U 224.5' },
  nfl:                    { spread: '-3.0',  total: 'O/U 44.5'  },
  mlb:                    { spread: '-1.5',  total: 'O/U 8.5'   },
  nhl:                    { spread: '-1.5',  total: 'O/U 5.5'   },
  'college-football':     { spread: '-7.0',  total: 'O/U 48.5'  },
  'mens-college-basketball':{ spread:'-4.5', total: 'O/U 142.5' },
  'usa.1':                { spread: '-0.5',  total: 'O/U 2.5'   },
  'eng.1':                { spread: '-0.5',  total: 'O/U 2.5'   },
  'uefa.champions':       { spread: '-0.5',  total: 'O/U 2.5'   },
  'esp.1':                { spread: '-0.5',  total: 'O/U 2.5'   },
  'ger.1':                { spread: '-0.5',  total: 'O/U 2.5'   },
  'ita.1':                { spread: '-0.5',  total: 'O/U 2.5'   },
};

// ═══════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════
const cache      = {};
const inFlight   = {};
let prevScores   = {};
let allGames     = [];
let activeTab    = 'all';
let appMode      = 'scores';
let selDate      = todayStr();
let weekOff      = 0;
let calMonth     = new Date();
let pollTimer    = null;
let oddsTimer    = null;       // separate odds-refresh timer
let propLinesTimer = null;     // prop-lines refresh for open modal
let prevOdds     = {};         // gameId → {spread,total} for change detection
let oddsHistory  = {};         // gameId → [{spread,total,ts}] for line movement
let prefetchQ    = [];
let prefetchBusy = false;
let currentUser  = null; // {name, id} — set after name modal (must be before picks)
let picks        = [];   // loaded properly in initUser() once currentUser is set
let goodProxy    = 0;

// Modal state
let openGameId     = null;
let modalTabActive = 'stats';
let modalStatData  = null;       // parsed player stats for open game
let modalPollTimer = null;       // auto-refresh when game is live

const SS_PREFIX = 'ls2_';
try{
  for(let i=0;i<sessionStorage.length;i++){
    const k=sessionStorage.key(i);
    if(k.startsWith(SS_PREFIX)){
      const ds=k.slice(SS_PREFIX.length);
      cache[ds]=JSON.parse(sessionStorage.getItem(k));
    }
  }
}catch(e){}

// ═══════════════════════════════════════════════════════
// DATE UTILS
// ═══════════════════════════════════════════════════════
function todayStr(){return fmtD(new Date());}
function fmtD(d){return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}`;}
function pad(n){return String(n).padStart(2,'0');}
function parseD(s){return new Date(+s.slice(0,4),+s.slice(4,6)-1,+s.slice(6,8));}
function addDays(s,n){const d=parseD(s);d.setDate(d.getDate()+n);return fmtD(d);}

// ═══════════════════════════════════════════════════════
// HTTP
// ═══════════════════════════════════════════════════════
async function go(url,timeoutMs=8000){
  const order=[goodProxy,...PROXIES.map((_,i)=>i).filter(i=>i!==goodProxy)];
  for(const pi of order){
    const pfx=PROXIES[pi];
    try{
      const u=pfx?pfx+encodeURIComponent(url):url;
      const r=await Promise.race([fetch(u), timeoutPromise(timeoutMs)]);
      if(!r.ok) continue;
      const d=await r.json();
      if(d){goodProxy=pi;return d;}
    }catch{continue;}
  }
  return null;
}

// ═══════════════════════════════════════════════════════
// REQUEST CACHE / DEDUP LAYER
// Prevents duplicate in-flight requests and caches results with TTL
// ═══════════════════════════════════════════════════════
const _reqCache = {};
async function cachedFetch(key, fetchFn, ttlMs=30000) {
  const now = Date.now();
  // Return cached result if still valid
  if(_reqCache[key] && _reqCache[key].expiresAt > now && _reqCache[key].result !== undefined) {
    return _reqCache[key].result;
  }
  // Return in-flight promise if one exists
  if(_reqCache[key] && _reqCache[key].promise) {
    return _reqCache[key].promise;
  }
  // Start new request
  const promise = fetchFn().then(result => {
    _reqCache[key] = { result, expiresAt: now + ttlMs, promise: null };
    return result;
  }).catch(err => {
    delete _reqCache[key];
    throw err;
  });
  _reqCache[key] = { promise, expiresAt: 0, result: undefined };
  return promise;
}
function invalidateCache(keyPrefix) {
  Object.keys(_reqCache).forEach(k => { if(k.startsWith(keyPrefix)) delete _reqCache[k]; });
}

// ═══════════════════════════════════════════════════════
// ESPN PARSE — scoreboard
// ═══════════════════════════════════════════════════════
function parseGames(data,lg,sp,dot,label){
  return(data.events||[]).map(ev=>{
    const comp=ev?.competitions?.[0]; if(!comp) return null;
    const cs=comp.competitors||[];
    const home=cs.find(c=>c.homeAway==='home')||cs[0]||{};
    const away=cs.find(c=>c.homeAway==='away')||cs[1]||{};
    const st=comp.status?.type;
    const isLive=st?.state==='in',isFinal=st?.state==='post',isPre=st?.state==='pre';
    const hs=parseInt(home.score),as2=parseInt(away.score);
    const hw=isFinal&&hs>as2,aw=isFinal&&as2>hs;
    const eo=comp.odds?.[0]||{};
    return{
      id:ev.id,sport:sp,league:lg,dot,leagueLabel:label,
      isLive,isFinal,isPre,
      statusText:st?.shortDetail||st?.description||'',
      startTime:ev.date?new Date(ev.date).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'',
      home:{name:home.team?.shortDisplayName||home.team?.displayName||'Home',abbr:home.team?.abbreviation||'?',logo:home.team?.logo||null,id:home.team?.id||null,score:isNaN(hs)?'—':hs,record:home.records?.[0]?.summary||'',winner:hw,loser:isFinal&&!hw},
      away:{name:away.team?.shortDisplayName||away.team?.displayName||'Away',abbr:away.team?.abbreviation||'?',logo:away.team?.logo||null,id:away.team?.id||null,score:isNaN(as2)?'—':as2,record:away.records?.[0]?.summary||'',winner:aw,loser:isFinal&&!aw},
      odds:parseOdds(eo, sp, lg),
    };
  }).filter(Boolean);
}

// Parse ESPN odds object — handles spread, moneyline, run line, puck line, and totals
function parseOdds(eo, sport, league){
  if(!eo) return {spread:null,total:null,src:null};
  let spread=null, total=null, src=null;

  // Total / over-under
  if(eo.overUnder!=null) { total=`O/U ${eo.overUnder}`; src='espn'; }

  // Spread / details — ESPN uses 'details' for point spread string e.g. "LAD -1.5"
  if(eo.details) { spread=eo.details; src='espn'; }

  // Baseball run line / hockey puck line come through as 'homeTeamOdds.spreadOdds' etc.
  // Also try awayTeamOdds
  if(!spread){
    const hOdds=eo.homeTeamOdds||{}, aOdds=eo.awayTeamOdds||{};
    const hSpread=hOdds.spreadOdds||hOdds.spread||hOdds.moneyLine;
    const aSpread=aOdds.spreadOdds||aOdds.spread||aOdds.moneyLine;
    if(hSpread!=null||aSpread!=null){
      // show favourite's spread
      const favLine=hOdds.favorite ? (hSpread>0?`+${hSpread}`:String(hSpread))
                                   : (aSpread>0?`+${aSpread}`:String(aSpread));
      spread=favLine; src='espn';
    }
  }

  // Moneyline fallback (use awayTeamOdds.moneyLine / homeTeamOdds.moneyLine)
  // Don't override a real spread with a moneyline

  return {spread, total, src};
}


// ═══════════════════════════════════════════════════════
async function fetchGameStats(game){
  // Use cached/deduped fetch — 30s TTL for live, 5min for pre-game
  const ttl = game.isLive ? 30000 : 300000;
  return cachedFetch(`stats:${game.id}`, () => _fetchGameStatsImpl(game), ttl);
}
async function _fetchGameStatsImpl(game){
  const lg=LEAGUES.find(l=>l.league===game.league);
  if(!lg) return null;
  const cfg=SPORT_STAT_CONFIGS[game.sport]||SPORT_STAT_CONFIGS.basketball;

  // Always fetch summary endpoint first — it works, it's reliable, and for pre-game
  // it contains roster + season leaders. The per-athlete/statistics endpoint 404s.
  const summaryData = await go(`${ESPN}/${lg.sport}/${lg.league}/summary?event=${game.id}`, 10000);

  if(game.isPre){
    if(summaryData){
      // Extract roster + season avgs from summary's leaders and roster sections
      const teams = parsePreGameRosterFromSummary(summaryData, game, cfg);
      if(teams && teams.length) return {teams, cfg, preGame:true};
    }
    // Fallback to roster endpoint (gets names but no stats — still better than synthetic)
    const [awayRoster, homeRoster] = await Promise.all([
      fetchTeamRoster(lg.sport, lg.league, game.away.id, game.away.name, game.away.logo),
      fetchTeamRoster(lg.sport, lg.league, game.home.id, game.home.name, game.home.logo),
    ]);
    const teams=[];
    if(awayRoster) teams.push(awayRoster);
    if(homeRoster) teams.push(homeRoster);
    if(!teams.length){
      teams.push(makeSyntheticRoster(game.away.name, game.away.logo, cfg));
      teams.push(makeSyntheticRoster(game.home.name, game.home.logo, cfg));
    }
    return {teams, cfg, preGame:true};

  } else {
    // Live/Final: boxscore in summary
    if(summaryData){
      const parsed=parseSummaryStats(summaryData, game.sport, cfg);
      if(parsed) return parsed;
    }
    // Fallback
    const [awayRoster, homeRoster] = await Promise.all([
      fetchTeamRoster(lg.sport, lg.league, game.away.id, game.away.name, game.away.logo),
      fetchTeamRoster(lg.sport, lg.league, game.home.id, game.home.name, game.home.logo),
    ]);
    const teams=[];
    if(awayRoster) teams.push(awayRoster);
    if(homeRoster) teams.push(homeRoster);
    if(!teams.length){
      teams.push(makeSyntheticRoster(game.away.name, game.away.logo, cfg));
      teams.push(makeSyntheticRoster(game.home.name, game.home.logo, cfg));
    }
    return {teams, cfg, preGame:false};
  }
}

// Extract player roster + season averages from the game summary endpoint
// ESPN summary contains: rosters[]{team, athletes[]} AND leaders[]{leaders[]{athlete, statistics[]}}
function parsePreGameRosterFromSummary(data, game, cfg){
  const teams = [];

  // ── Path 1: summary.rosters[]{team, athletes[{athlete, statistics[]}]} ──
  const rosters = data.rosters || [];
  rosters.forEach(r=>{
    const tInfo = r.team || {};
    const players = [];
    (r.athletes || []).forEach(entry=>{
      const ath = entry.athlete || entry;
      const name = ath.displayName || ath.fullName || ath.shortName || '';
      if(!name || name.length < 2) return;
      // Extract season avgs directly from the athlete entry in rosters
      const seasonAvgs = {};
      // Try entry.statistics[] — ESPN sometimes embeds per-player stats here
      (entry.statistics || []).forEach(s=>{
        const key = (s.name||s.abbreviation||'').toLowerCase().replace(/[^a-z0-9]/g,'');
        const val = s.displayValue || s.value;
        if(key && val && val !== '--') seasonAvgs[key] = val;
      });
      players.push({
        id: String(ath.id || Math.random().toString(36).slice(2)),
        name,
        position: (ath.position?.abbreviation || ath.position?.name || '').slice(0,3).toUpperCase(),
        headshot: ath.headshot?.href || null,
        active: true,
        seasonAvgs,
      });
    });
    if(players.length){
      teams.push({
        name: tInfo.shortDisplayName || tInfo.displayName || tInfo.name || '',
        logo: tInfo.logo || null,
        players: players.slice(0, 12),
      });
    }
  });

  // ── Path 2: summary.leaders[] — top statistical leaders with season avgs ──
  // Use leaders to ENRICH players found in rosters, or build a standalone list
  const leaderMap = {}; // athleteId -> {pts, reb, ast, ...}
  (data.leaders || []).forEach(catLeader=>{
    const statName = (catLeader.name||catLeader.displayName||'').toLowerCase().replace(/[^a-z0-9]/g,'');
    (catLeader.leaders || []).forEach(l=>{
      const ath = l.athlete || {};
      const id = String(ath.id || '');
      if(!id) return;
      if(!leaderMap[id]) leaderMap[id] = { _name: ath.displayName||'', _pos: ath.position?.abbreviation||'', _logo: ath.headshot?.href||null, _team: ath.team?.displayName||'' };
      // Map ESPN stat category names to our keys
      const val = l.displayValue || l.value;
      leaderMap[id][statName] = val;
    });
  });

  // Enrich roster players with leader data
  teams.forEach(team=>{
    team.players.forEach(p=>{
      const ldata = leaderMap[p.id];
      if(ldata) Object.assign(p.seasonAvgs, ldata);
    });
  });

  // If rosters path gave nothing, build teams from leaders alone
  if(!teams.length && Object.keys(leaderMap).length){
    const byTeam = {};
    Object.entries(leaderMap).forEach(([id, ldata])=>{
      const teamName = ldata._team || 'Team';
      if(!byTeam[teamName]) byTeam[teamName] = [];
      byTeam[teamName].push({
        id, name: ldata._name, position: ldata._pos,
        headshot: ldata._logo, active:true, seasonAvgs: ldata,
      });
    });
    Object.entries(byTeam).forEach(([tName, players])=>{
      teams.push({name:tName, logo:null, players});
    });
  }

  // ── Path 3: summary.boxscore.players — pre-game sometimes has projected lineups ──
  if(!teams.length){
    const fromBoxscore = parseSummaryStats(data, game.sport, cfg);
    if(fromBoxscore && fromBoxscore.teams) return fromBoxscore.teams;
  }

  return teams;
}

// enrichTeamsWithSeasonStats: DISABLED — athletes/statistics endpoint returns 404
// Kept as no-op to avoid breaking any call sites
async function enrichTeamsWithSeasonStats(teams, sport, league, cfg){
  // No-op: per-athlete statistics endpoint (athletes/{id}/statistics) returns 404
  // Season avgs are now extracted directly from the summary endpoint
}

// Build a synthetic roster with generic player slots so the props tab always renders
function makeSyntheticRoster(teamName, teamLogo, cfg){
  const positions = {
    basketball:['PG','SG','SF','PF','C','PG','SG','SF'],
    football:  ['QB','RB','WR','WR','TE','RB','WR','OL'],
    baseball:  ['CF','SS','1B','DH','RF','3B','LF','2B','C','SP'],
    hockey:    ['LW','C','RW','D','D','G','LW','C'],
    soccer:    ['FW','FW','MF','MF','MF','DF','DF','GK'],
  };
  const sport = cfg === SPORT_STAT_CONFIGS.basketball ? 'basketball'
    : cfg === SPORT_STAT_CONFIGS.football ? 'football'
    : cfg === SPORT_STAT_CONFIGS.baseball ? 'baseball'
    : cfg === SPORT_STAT_CONFIGS.hockey   ? 'hockey'
    : 'soccer';
  const pos = positions[sport] || positions.basketball;
  const players = pos.map((p,i)=>({
    id: `syn_${teamName}_${i}`,
    name: `${teamName} #${i+1}`,
    position: p,
    headshot: null,
    stats: {},
    active: true,
  }));
  return {name:teamName, logo:teamLogo, players, synthetic:true};
}

async function fetchTeamRoster(sport, league, teamId, teamName, teamLogo){
  if(!teamId) return null;
  return cachedFetch(`roster:${teamId}`, () => _fetchTeamRosterImpl(sport, league, teamId, teamName, teamLogo), 300000);
}
async function _fetchTeamRosterImpl(sport, league, teamId, teamName, teamLogo){
  const rawPlayers=[];

  // Primary: team roster endpoint
  const rosterData = await go(`${ESPN}/${sport}/${league}/teams/${teamId}/roster`, 8000);
  if(rosterData){
    const groups = rosterData.athletes || [];
    groups.forEach(group=>{
      (group.items || group.athletes || [group]).forEach(ath=>{
        // Handle both grouped format and flat format
        const a = ath.athlete || ath;
        const name = a.displayName || a.fullName || a.shortName || ath.displayName || '';
        if(!name || name.length < 2) return;
        rawPlayers.push({
          id: String(a.id || ath.id || Math.random().toString(36).slice(2)),
          name,
          position: ((a.position||ath.position)?.abbreviation || (a.position||ath.position)?.name || '').slice(0,3).toUpperCase(),
          headshot: (a.headshot || ath.headshot)?.href || null,
          active: true,
          seasonAvgs: {},
        });
      });
    });
  }

  // Fallback: team athletes endpoint (different structure)
  if(!rawPlayers.length){
    const teamData = await go(`${ESPN}/${sport}/${league}/teams/${teamId}?enable=roster,stats`, 8000);
    if(teamData){
      const athletes = teamData.team?.athletes || teamData.athletes || [];
      athletes.forEach(ath=>{
        const name = ath.displayName || ath.fullName || '';
        if(!name) return;
        rawPlayers.push({
          id: String(ath.id || Math.random().toString(36).slice(2)),
          name,
          position: (ath.position?.abbreviation || '').slice(0,3).toUpperCase(),
          headshot: ath.headshot?.href || null,
          active: true,
          seasonAvgs: {},
        });
      });
    }
  }

  if(!rawPlayers.length) return null;

    const top = rawPlayers.slice(0, 10);
  // athletes/{id}/statistics returns 404 — avgs come from summary endpoint

  const tInfo = rosterData?.team || {};
  return {
    name: tInfo.shortDisplayName || tInfo.displayName || teamName,
    logo: tInfo.logo || teamLogo,
    players: top,
  };
}


// Parse ESPN athlete statistics endpoint to extract per-game season averages
function parseAthleteSeasonAvgs(data, sport){
  if(!data) return {};
  const avgs={};

  // ESPN athlete/statistics endpoint returns:
  // data.splits.categories[] — each category has names[] + averages[] + totals[]
  // We want averages (per-game), never totals (cumulative)
  const cats = (data.splits && data.splits.categories) || data.categories || [];
  cats.forEach(cat=>{
    const names = cat.names || cat.labels || [];
    // Try averages first, then displayValues, never totals
    const vals = cat.averages || cat.displayValues || cat.stats || [];
    if(!vals.length) return;
    names.forEach((nm,i)=>{
      const key = nm.toLowerCase().replace(/[^a-z0-9]/g,'');
      const raw = vals[i];
      if(raw!=null && raw!=='--' && raw!=='' && String(raw)!=='0') avgs[key]=raw;
    });
  });

  // Also check data.athlete.statistics[] flat list (alternate endpoint format)
  const flatStats = data.athlete?.statistics || data.statistics || [];
  flatStats.forEach(s=>{
    const key = (s.name||s.abbreviation||s.displayName||'').toLowerCase().replace(/[^a-z0-9]/g,'');
    const val = s.displayValue || s.value;
    if(key && val!=null && val!=='--' && val!=='') avgs[key]=val;
  });

  // Debug: log first player's avgs so we can verify keys (remove after confirming)

  return avgs;
}

// Convert season average to a sportsbook-style prop line
// Sportsbooks typically shade lines 0.5-1.5 below the true average to create action on both sides
function avgToLine(avg){
  const n=parseFloat(avg);
  if(isNaN(n)||n<=0) return null;
  // Shade 5% below average (books set lines under the true avg to juice the over)
  // then round to nearest 0.5
  const shaded = n * 0.95;
  return Math.round(shaded * 2) / 2;
}

// Get the real prop line for a player+stat. Uses season avg if available, else fallback.
function getPlayerPropLine(player, statKey, cfg){
  const propDef = (cfg.propDefs||{})[statKey];
  if(!propDef) return 0.5;
  const avgs = player.seasonAvgs||{};

  // ESPN stat abbreviation keys (after .toLowerCase().replace(/[^a-z0-9]/g,''))
  const espnKeys = {
    // Basketball — abbreviations (boxscore) + full names (leaders/rosters)
    pts:  ['pts','points','ppg','pointspergame','avgpoints','scoringaverage'],
    reb:  ['reb','rebounds','rpg','reboundspergame','avgrebounds','totalrebounds','trb'],
    ast:  ['ast','assists','apg','assistspergame','avgassists'],
    stl:  ['stl','steals','avgsteals'],
    blk:  ['blk','blocks','avgblocks'],
    // Football
    pasYds:  ['pyds','passingyards','passyards','passingyardspergame','yds'],
    rushYds: ['ryds','rushingyards','rushyards','rushingyardspergame'],
    recYds:  ['recyds','receivingyards','recyards','receivingyardspergame'],
    // Baseball
    h:   ['h','hits','avg','battingaverage','ba'],
    hr:  ['hr','homeruns','homerun'],
    rbi: ['rbi','runsbattedin'],
    // Hockey
    g:    ['g','goals','goalspergame','avggoals'],
    a:    ['a','assists','assistspergame','avgassists'],
    shots:['sog','shots','shotsperga','shotattempts'],
    // Soccer
    goals:         ['goals','g','goalspergame'],
    shotsOnTarget: ['sot','shotsontarget'],
  }

  const keyVariants = espnKeys[statKey]||[statKey.toLowerCase()];
  for(const k of keyVariants){
    if(avgs[k]!=null){
      const line=avgToLine(avgs[k]);
      if(line!==null) return line;
    }
  }

  // No ESPN data — use position-based realistic defaults
  const posDefaults = {
    basketball: {
      PG:{pts:18.5,reb:4.5,ast:7.5}, SG:{pts:17.5,reb:4.0,ast:4.0},
      SF:{pts:16.5,reb:6.0,ast:3.5}, PF:{pts:14.5,reb:8.0,ast:2.5},
      C: {pts:13.5,reb:9.5,ast:2.0}, G: {pts:16.5,reb:4.0,ast:5.0},
      F: {pts:15.0,reb:6.5,ast:3.0}, _: {pts:14.5,reb:5.5,ast:3.5},
    },
    football: {
      QB:{pasYds:242.5,rushYds:18.5,recYds:0}, RB:{pasYds:0,rushYds:62.5,recYds:28.5},
      WR:{pasYds:0,rushYds:2.5,recYds:58.5},   TE:{pasYds:0,rushYds:1.5,recYds:42.5},
      _: {pasYds:0,rushYds:38.5,recYds:42.5},
    },
    baseball: { _:{h:0.5,hr:0.5,rbi:0.5} },
    hockey: {
      LW:{g:0.5,a:0.5,shots:2.5}, C:{g:0.5,a:0.5,shots:2.5},
      RW:{g:0.5,a:0.5,shots:2.5}, D:{g:0.5,a:0.5,shots:1.5},
      _: {g:0.5,a:0.5,shots:2.5},
    },
  };
  const sport = cfg===SPORT_STAT_CONFIGS.basketball?'basketball'
    :cfg===SPORT_STAT_CONFIGS.football?'football'
    :cfg===SPORT_STAT_CONFIGS.baseball?'baseball'
    :cfg===SPORT_STAT_CONFIGS.hockey?'hockey':'basketball';
  const pd = posDefaults[sport]||posDefaults.basketball;
  const pos = (player.position||'').toUpperCase();
  const posLine = (pd[pos]||pd[pos.slice(0,1)]||pd['_']||{})[statKey];
  return posLine!=null ? posLine : propDef.fb;
}

function parseSummaryStats(data, sport, cfg){
  if(!cfg) cfg=SPORT_STAT_CONFIGS[sport]||SPORT_STAT_CONFIGS.basketball;
  const teams=[];

  // Try boxscore (live/final)
  const boxscore=data.boxscore||data.boxScore;
  if(boxscore?.players?.length){
    (boxscore.players||[]).forEach(teamData=>{
      const teamInfo=teamData.team||{};
      const players=[];
      (teamData.statistics||[]).forEach(statGroup=>{
        const cols=statGroup.labels||[];
        (statGroup.athletes||[]).forEach(athData=>{
          const ath=athData.athlete||{};
          const vals=athData.stats||[];
          if(!vals.length) return;
          const stats={};
          cols.forEach((col,i)=>{ stats[col.toLowerCase().replace(/\s+/g,'_')]=vals[i]??'—'; });
          players.push({
            id: String(ath.id||Math.random().toString(36).slice(2)),
            name: ath.displayName||ath.shortName||'Unknown',
            position: ath.position?.abbreviation||'',
            headshot: ath.headshot?.href||null,
            stats: normalizeStats(stats, sport),
            active: athData.active!==false,
          });
        });
      });
      if(players.length) teams.push({name:teamInfo.shortDisplayName||teamInfo.displayName||'',logo:teamInfo.logo||null,players});
    });
    if(teams.length) return {teams,cfg,preGame:false};
  }

  // Try rosters (pre-game summary fallback)
  if(data.rosters?.length){
    (data.rosters||[]).forEach(rosterData=>{
      const teamInfo=rosterData.team||{};
      const players=[];
      (rosterData.athletes||[]).forEach(group=>{
        const list=group.athletes||group.items||(Array.isArray(group)?group:[]);
        list.forEach(athData=>{
          const ath=athData.athlete||athData||{};
          const name=ath.displayName||ath.shortName||ath.fullName||'';
          if(!name||name==='Unknown') return;
          players.push({
            id: String(ath.id||Math.random().toString(36).slice(2)),
            name,
            position: (ath.position?.abbreviation||ath.position?.name||'').slice(0,3),
            headshot: ath.headshot?.href||null,
            stats: {},
            active: true,
          });
        });
      });
      if(players.length) teams.push({name:teamInfo.shortDisplayName||teamInfo.displayName||'',logo:teamInfo.logo||null,players});
    });
    if(teams.length) return {teams,cfg,preGame:true};
  }

  return null;
}

function normalizeStats(raw, sport){
  // ESPN column names vary — map common variants to our standard keys
  const maps = {
    basketball: {
      'min':'min','pts':'pts','reb':'reb','ast':'ast','stl':'stl','blk':'blk',
      'to':'to','turnover':'to','fg':'fg',
      'fg%':'fg','fgm-a':'fg','fg-fga':'fg',
      'rebounds':'reb','assists':'ast','steals':'stl','blocks':'blk','points':'pts',
    },
    football: {
      'yds':'pasYds','att-cmp':'fg','td':'pasTD','int':'passInt',
      'car':'rushAtt','rushing_yds':'rushYds','rushing_td':'rushTD',
      'rec':'rec','receiving_yds':'recYds','receiving_td':'recTD',
      'passing_yds':'pasYds','pass_yards':'pasYds','rush_yards':'rushYds','rec_yards':'recYds',
    },
    baseball: {
      'ab':'ab','h':'h','r':'r','hr':'hr','rbi':'rbi','bb':'bb','k':'so','so':'so','avg':'avg',
    },
    hockey: {
      'g':'g','a':'a','pts':'pts','+/-':'plusMinus','pim':'pim','sog':'shots','toi':'toi',
      'goals':'g','assists':'a','plus_minus':'plusMinus',
    },
    soccer: {
      'g':'goals','a':'assists','sh':'shots','sog':'shotsOnTarget','f':'fouls','yc':'yellowCards',
      'goals':'goals','assists':'assists','shots':'shots',
    },
  };
  const map = maps[sport] || maps.basketball;
  const out = {};
  Object.entries(raw).forEach(([k,v])=>{
    const mapped = map[k] || map[k.toLowerCase()] || k;
    out[mapped] = v;
    // Also keep original key
    out[k] = v;
  });
  return out;
}

function getStatVal(stats, key){
  const val = stats[key];
  if(val === undefined || val === null) return '—';
  return val;
}

// ═══════════════════════════════════════════════════════
// EXTERNAL ODDS
// ═══════════════════════════════════════════════════════
// ─── ODDS POLLING ───────────────────────────────────────
// Fetches external odds (The Odds API) and also re-reads ESPN scoreboard odds.
// Called once on init, then on a 3-min timer.  Surgically patches DOM so only
// changed pills flash — no full re-render needed.

function loadAllExternalOdds(){
  // Odds come from ESPN scoreboard directly — no external API needed
  // Just re-enrich games in case ESPN odds loaded after initial render
  if(cache[selDate]){
    const freshGames=enrichOdds(cache[selDate]);
    patchOddsDOM(freshGames);
    cache[selDate]=freshGames;
    allGames=freshGames;
  }
}

// Surgically update odds pills on score cards — only touches changed values
function patchOddsDOM(games){
  games.forEach(g=>{
    const prev=prevOdds[g.id]||{};
    const spreadChanged = g.odds.spread && g.odds.spread !== prev.spread;
    const totalChanged  = g.odds.total  && g.odds.total  !== prev.total;
    if(!spreadChanged && !totalChanged) return;

    const card=document.getElementById(`card-${g.id}`);
    if(!card) return;  // card not visible right now

    // Find or build the odds-bar
    let bar=card.querySelector('.odds-bar');
    if(!bar){
      // Card didn't have an odds bar — inject one before the pick section
      const pickSec=card.querySelector('.pick-section');
      const insertBefore=pickSec||null;
      bar=document.createElement('div');
      bar.className='odds-bar';
      card.insertBefore(bar, insertBefore);
    }

    // Rebuild bar HTML with flash classes on changed pills
    let html='';
    if(g.odds.spread){
      const cls=spreadChanged?'odds-updated':'';
      html+=`<div class="odds-pill ${cls}"><div class="odds-label">Spread</div><div class="odds-val ${cls}">${g.odds.spread}</div>${g.odds.src?`<div class="odds-src">${g.odds.src}</div>`:''}</div>`;
    }
    if(g.odds.total){
      const cls=totalChanged?'odds-updated':'';
      html+=`<div class="odds-pill ${cls}"><div class="odds-label">Total</div><div class="odds-val ${cls}">${g.odds.total}</div>${g.odds.src?`<div class="odds-src">${g.odds.src}</div>`:''}</div>`;
    }
    bar.innerHTML=html;

    // Remove flash classes after animation completes so they can re-trigger
    setTimeout(()=>{
      bar.querySelectorAll('.odds-updated').forEach(el=>el.classList.remove('odds-updated'));
    }, 2000);

    prevOdds[g.id]={spread:g.odds.spread, total:g.odds.total};
  });
}

// Snapshot current odds into prevOdds (called after first render so flashes only on real changes)
function snapshotOdds(){
  allGames.forEach(g=>{
    const prev=prevOdds[g.id]||{};
    // Record history if odds changed
    if(g.odds.spread&&g.odds.spread!==prev.spread){
      if(!oddsHistory[g.id]) oddsHistory[g.id]=[];
      oddsHistory[g.id].push({spread:g.odds.spread,total:g.odds.total,ts:Date.now()});
      if(oddsHistory[g.id].length>10) oddsHistory[g.id].shift(); // keep last 10
    }
    prevOdds[g.id]={spread:g.odds.spread, total:g.odds.total};
  });
}

// Schedule recurring odds refresh (every 3 minutes)
function scheduleOddsPoll(){
  clearTimeout(oddsTimer);
  oddsTimer=setTimeout(async()=>{
    await loadAllExternalOdds();
    scheduleOddsPoll();
  }, 3*60*1000); // 3 minutes
}

function enrichOdds(games){
  const norm=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'');
  return games.map(g=>{
    let spread=g.odds.spread, total=g.odds.total, src=g.odds.src;

    // Layer 2: (external odds API removed — ESPN provides odds directly)

    // Layer 3: Static per-league fallback — ONLY fills fields still missing after real sources
    // Never overwrites a real ESPN or external line with an estimate
    const fallback=STATIC_ODDS[g.league];
    if(fallback){
      if(!spread){ spread=fallback.spread; src=src||'est'; }
      if(!total){  total=fallback.total;   src=src||'est'; }
    }

    return {...g, odds:{spread,total,src}};
  });
}

// ═══════════════════════════════════════════════════════
// CORE FETCH — scoreboard (parallel, streaming)
// ═══════════════════════════════════════════════════════
function fetchDate(ds){
  if(cache[ds]) return Promise.resolve(cache[ds]);
  if(inFlight[ds]) return inFlight[ds];

  const promise=(async()=>{
    const isSel=()=>ds===selDate;
    if(isSel()) setSpinner(true);

    const fetches=LEAGUES.map(l=>
      go(`${ESPN}/${l.sport}/${l.league}/scoreboard?dates=${ds}`,9000)
        .then(data=>{
          if(!data?.events) return[];
          const games=parseGames(data,l.league,l.sport,l.dot,l.label);
          if(isSel()&&games.length){
            allGames=enrichOdds([...allGames,...games.filter(g=>!allGames.find(x=>x.id===g.id))]);
            allGames.sort((a,b)=>(b.isLive-a.isLive)||(a.isPre-b.isPre));
            streamRender();
          }
          return games;
        }).catch(()=>[])
    );

    const results=await Promise.allSettled(fetches);
    let allFound=results.filter(r=>r.status==='fulfilled').flatMap(r=>r.value);
    allFound=enrichOdds(allFound);
    allFound.sort((a,b)=>(b.isLive-a.isLive)||(a.isPre-b.isPre));

    cache[ds]=allFound;
    try{sessionStorage.setItem(SS_PREFIX+ds,JSON.stringify(allFound));}catch(e){}
    delete inFlight[ds];

    if(isSel()){
      allGames=allFound;
      setSpinner(false);
      fullRender();
    }else{
      buildDateStrip();
      if(appMode==='calendar') patchCalendarCell(ds);
    }
    drainPrefetchQueue();
    return allFound;
  })();

  inFlight[ds]=promise;
  return promise;
}

// ═══════════════════════════════════════════════════════
// RENDER HELPERS
// ═══════════════════════════════════════════════════════
let streamRenderTimer=null;

// ── Hoisted globals (originally declared in injected feature blocks) ──
const AUTH_COOLDOWN_MS = 4000; // 4s cooldown between auth attempts
const DEFAULT_WAGER = 50;      // default pick wager
const STARTING_BANKROLL = 1000; // starting bankroll balance
const CHALLENGE_KEY = 'daily_challenge_pick'; // daily challenge localStorage key
let serverSyncTimer = null;    // server sync interval
let authSession = null;       // Supabase auth session
let currentAuthTab = 'login'; // auth modal active tab
let _authLastAttempt = 0;     // rate-limit guard
let _authAttemptCount = 0;
let wsConnection = null;      // WebSocket (reserved)
let wsReconnectTimer = null;
let wsEnabled = false;
let wsGameIds = new Set();
let fastPollTimer = null;     // fast poll interval during live games
let searchOpen = false;       // global search panel state
function streamRender(){
  clearTimeout(streamRenderTimer);
  streamRenderTimer=setTimeout(()=>{const _sy=window.scrollY;clearSkeleton();buildTabs();renderScores();updateTicker();buildDateStrip();requestAnimationFrame(()=>{window.scrollTo(0,_sy);});},80);
}
function updateSlateSummary(){
  const el=document.getElementById('slateSummary');
  if(!el) return;
  const games=allGames;
  if(!games.length){el.innerHTML='';return;}

  const live=games.filter(g=>g.isLive);
  const pre=games.filter(g=>g.isPre);
  const fin=games.filter(g=>g.isFinal);

  // My action today
  const myPending=picks.filter(pk=>pk.result==='pending'&&games.find(g=>g.id===pk.gameId||g.id===pk.actualGameId));
  const myWon=picks.filter(pk=>pk.result==='won'&&games.find(g=>g.id===pk.gameId||g.id===pk.actualGameId));
  const myLost=picks.filter(pk=>pk.result==='lost'&&games.find(g=>g.id===pk.gameId||g.id===pk.actualGameId));

  const pills=[];

  if(live.length){
    pills.push(`<div class="slate-pill live-pill"><span class="slate-pill-dot"></span>LIVE <span class="slate-pill-val">${live.length}</span></div>`);
  }
  if(pre.length){
    pills.push(`<div class="slate-pill"><span>🕐</span>UPCOMING <span class="slate-pill-val">${pre.length}</span></div>`);
  }
  if(fin.length){
    pills.push(`<div class="slate-pill"><span>✅</span>FINAL <span class="slate-pill-val">${fin.length}</span></div>`);
  }
  pills.push(`<div class="slate-pill"><span>🎮</span>TOTAL <span class="slate-pill-val">${games.length} GAMES</span></div>`);

  if(myPending.length||myWon.length||myLost.length){
    const rec=myWon.length||myLost.length?` · ${myWon.length}-${myLost.length}`:'';
    pills.push(`<div class="slate-pill my-action"><span class="slate-pill-dot"></span>MY PICKS <span class="slate-pill-val">${myPending.length+myWon.length+myLost.length}${rec}</span></div>`);
  }

  el.innerHTML=pills.join('');
}

function fullRender(){
  clearTimeout(streamRenderTimer);
  const _scrollY = window.scrollY;
  clearSkeleton();buildTabs();renderScores();updateTicker();buildDateStrip();updateRecordUI();checkPickResults();checkPropPickResults();checkParlayResults();updateSlateSummary();
  renderBestBetCard();renderDailyChallenge();updateBankrollUI();
  if(typeof renderWeeklyRecap==='function') renderWeeklyRecap();
  if(typeof upgradePollIfLive==='function') upgradePollIfLive();
  snapshotOdds(); // baseline after re-render so next odds poll only flashes real changes
  if(appMode==='calendar') renderCalendar();
  requestAnimationFrame(() => { window.scrollTo(0, _scrollY); });
}
function clearSkeleton(){document.getElementById('skeletonGrid')?.remove();}

// ═══════════════════════════════════════════════════════
// PREFETCH
// ═══════════════════════════════════════════════════════
function enqueuePrefetch(dates){
  dates.forEach(ds=>{if(!cache[ds]&&!inFlight[ds]&&!prefetchQ.includes(ds)) prefetchQ.push(ds);});
  drainPrefetchQueue();
}
function drainPrefetchQueue(){
  if(prefetchBusy||!prefetchQ.length) return;
  if(inFlight[selDate]){setTimeout(drainPrefetchQueue,500);return;}
  const ds=prefetchQ.shift();
  if(!ds||cache[ds]){drainPrefetchQueue();return;}
  prefetchBusy=true;
  fetchDate(ds).finally(()=>{prefetchBusy=false;drainPrefetchQueue();});
}
function prefetchNeighbors(){
  const neighbors=[-3,-2,-1,1,2,3,4,5].map(n=>addDays(selDate,n));
  enqueuePrefetch(neighbors);
}
function patchCalendarCell(ds){
  const cell=document.querySelector(`[data-ds="${ds}"]`);
  if(!cell) return;
  const games=cache[ds]||[];
  const dm={};games.forEach(g=>{dm[g.dot]=true;});
  const dots=Object.keys(dm).map(c=>`<div class="cal-dot dot-${c}"></div>`).join('');
  cell.querySelector('.cal-dots').innerHTML=dots;
  const gcnt=cell.querySelector('.cal-gcnt');
  if(games.length){if(gcnt)gcnt.textContent=`${games.length} games`;else cell.insertAdjacentHTML('beforeend',`<div class="cal-gcnt">${games.length} games</div>`);}
}

function setSpinner(on){
  document.getElementById('refreshRing')?.parentElement.classList.toggle('refreshing',on);
  if(!on) document.getElementById('lastUpdate').textContent=new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});
}

// ═══════════════════════════════════════════════════════
// POLLING
// ═══════════════════════════════════════════════════════
function schedulePoll(){
  clearTimeout(pollTimer);
  const live=allGames.filter(g=>g.isLive).length;
  const pi=document.getElementById('pollInd');
  if(pi){pi.textContent=live?'●●●':'●○○';pi.className='poll-indicator'+(live?' fast':'');}
  pollTimer=setTimeout(async()=>{
    // Fetch fresh data WITHOUT nuking cache first — compare to decide render strategy
    const prevCount = allGames.length;
    const prevIds = new Set(allGames.map(g=>g.id));
    delete cache[selDate];
    try{sessionStorage.removeItem(SS_PREFIX+selDate);}catch(e){}
    await fetchDate(selDate);
    // Settle any picks whose games just went final
    checkPickResults();
    checkParlayResults();
    checkPropPickResults();
    // Refresh modal if open and game is live
    if(openGameId){
      const g=allGames.find(x=>x.id===openGameId);
      if(g){updateModalScoreboard(g);}
    }
    // If game count/IDs unchanged, just patch scores in-place (no scroll jump)
    const newIds = new Set(allGames.map(g=>g.id));
    const sameGames = prevCount===allGames.length && [...prevIds].every(id=>newIds.has(id));
    if(sameGames && appMode==='scores'){
      patchScores();
      updateSlateSummary();
      updateRecordUI();
      updateBankrollUI();
      renderLivePickBar();
    }
    // If games changed (new game started, game appeared/disappeared), fullRender already ran via fetchDate
    schedulePoll();
  },live?5000:30000);
}
function patchScores(){
  allGames.forEach(g=>{
    const prev=prevScores[g.id]; if(!prev) return;
    const hs=g.home.score,as2=g.away.score;
    if(prev.hs!==hs){const el=document.getElementById(`hs-${g.id}`);if(el){el.textContent=hs;el.classList.remove('score-changed');void el.offsetWidth;el.classList.add('score-changed');}}
    if(prev.as!==as2){const el=document.getElementById(`as-${g.id}`);if(el){el.textContent=as2;el.classList.remove('score-changed');void el.offsetWidth;el.classList.add('score-changed');}}
    const stEl=document.getElementById(`st-${g.id}`);
    if(stEl&&g.isLive) stEl.textContent=g.statusText;
    prevScores[g.id]={hs,as:as2};
  });
}

// ═══════════════════════════════════════════════════════
// MODE
// ═══════════════════════════════════════════════════════
function setMode(m){
  appMode=m;
  // Desktop nav buttons
  const dBtns={scores:'btnScores',calendar:'btnCalendar',history:'btnHistory',
    leaderboard:'btnLeaderboard',news:'btnNews',analysis:'btnAnalysis',contests:'btnContests',picks:'btnPicks',bracket:'btnBracket',trends:'btnTrends',feed:'btnFeed',battles:'btnBattles'};
  Object.entries(dBtns).forEach(([k,id])=>{const el=document.getElementById(id);if(el)el.classList.toggle('active',k===m);});
  // Mobile nav buttons
  const mBtns={scores:'mobBtnScores',myaction:'mobBtnMyaction',leaderboard:'mobBtnLeaderboard',picks:'mobBtnPicks'};
  Object.entries(mBtns).forEach(([k,id])=>{const el=document.getElementById(id);if(el)el.classList.toggle('active',k===m);});
  // Secondary views highlight the More button
  const moreViews=['history','trends','battles','analysis','contests','bracket','calendar','news','feed'];
  const moreBtn=document.getElementById('mobBtnMore');
  if(moreBtn) moreBtn.classList.toggle('active',moreViews.includes(m));
  // Show/hide views
  const views=['scoresView','calendarView','historyView','leaderboardView','newsView','analysisView','contestsView','bracketView','trendsView','feedView','battlesView','myactionView'];
  const viewMap={scores:'scoresView',calendar:'calendarView',history:'historyView',
    leaderboard:'leaderboardView',news:'newsView',analysis:'analysisView',contests:'contestsView',bracket:'bracketView',trends:'trendsView',feed:'feedView',battles:'battlesView',myaction:'myactionView'};
  views.forEach(v=>{const el=document.getElementById(v);if(el)el.style.display='none';});
  const active=document.getElementById(viewMap[m]);
  if(active) active.style.display='';
  document.getElementById('tabsWrap').style.display=m==='scores'?'':'none';
  // Render as needed
  if(m==='calendar') renderCalendar();
  if(m==='history') renderHistoryView();
  if(m==='leaderboard') renderLeaderboardView();
  if(m==='news') renderNewsView();
  if(m==='analysis') renderAnalysisView();
  if(m==='contests') renderContestsView();
  if(m==='bracket') renderBracketView();
  if(m==='trends') { m='analysis'; appMode='analysis'; renderAnalyticsView(); }
  if(m==='feed') renderPickFeed();
  if(m==='battles') renderBattlesView();
  if(m==='myaction') renderMyActionView();
}

// ═══════════════════════════════════════════════════════
// DATE STRIP
// ═══════════════════════════════════════════════════════
function buildDateStrip(){
  const strip=document.getElementById('dateStrip');
  const today=todayStr();
  const anchor=addDays(today,weekOff*7);
  const days=Array.from({length:14},(_,i)=>addDays(anchor,i-3));
  strip.innerHTML=days.map(ds=>{
    const d=parseD(ds);
    const isSel=ds===selDate,isToday=ds===today;
    const cnt=cache[ds]?.length;
    const loading=!cache[ds]&&inFlight[ds];
    return `<div class="date-pill${isToday?' tod':''}${isSel?' sel':''}" onclick="selectDate('${ds}')">
      <span class="dp-dow">${d.toLocaleDateString([],{weekday:'short'}).slice(0,3).toUpperCase()}</span>
      <span class="dp-num">${d.getDate()}</span>
      <span class="dp-cnt">${loading?'…':cnt!=null?cnt:''}</span>
    </div>`;
  }).join('');
  requestAnimationFrame(()=>{strip.querySelector('.date-pill.sel')?.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'});});
}
function selectDate(ds){
  if(ds===selDate) return;
  clearTimeout(pollTimer);
  selDate=ds; activeTab='all';
  buildDateStrip();
  if(cache[ds]){allGames=cache[ds];clearSkeleton();fullRender();schedulePoll();prefetchNeighbors();}
  else{showSkeleton();fetchDate(ds).then(()=>{schedulePoll();prefetchNeighbors();});}
}
function shiftWeek(dir){
  weekOff+=dir; buildDateStrip();
  const today=todayStr(),anchor=addDays(today,weekOff*7);
  const days=Array.from({length:14},(_,i)=>addDays(anchor,i-3));
  enqueuePrefetch(days.filter(d=>d!==selDate));
}
function showSkeleton(){
  const skel='<div style="background:var(--card);border:1px solid var(--border);border-radius:8px;padding:14px;height:120px"><div class="sk" style="width:38%;height:9px;margin-bottom:12px"></div><div style="display:flex;gap:9px;align-items:center;margin-bottom:9px"><div class="sk" style="width:28px;height:28px;border-radius:50%;flex-shrink:0"></div><div style="flex:1"><div class="sk" style="width:55%;height:9px"></div></div><div class="sk" style="width:34px;height:20px"></div></div><div style="height:1px;background:var(--border);margin:5px 0"></div><div style="display:flex;gap:9px;align-items:center"><div class="sk" style="width:28px;height:28px;border-radius:50%;flex-shrink:0"></div><div style="flex:1"><div class="sk" style="width:50%;height:9px"></div></div><div class="sk" style="width:34px;height:20px"></div></div></div>';
  document.getElementById('scoresGrid').innerHTML=`<div class="score-grid">${skel.repeat(4)}</div>`;
}

// ═══════════════════════════════════════════════════════
// TABS
// ═══════════════════════════════════════════════════════
function buildTabs(){
  const groups={};
  allGames.forEach(g=>{if(!groups[g.leagueLabel])groups[g.leagueLabel]={total:0,live:0};groups[g.leagueLabel].total++;if(g.isLive)groups[g.leagueLabel].live++;});
  const totalLive=allGames.filter(g=>g.isLive).length;
  const tabs=[{key:'all',label:'All',total:allGames.length,live:totalLive},...Object.entries(groups).map(([k,v])=>({key:k,label:k,...v}))];
  document.getElementById('tabsCont').innerHTML=tabs.map(t=>`<button class="tab ${activeTab===t.key?'active':''}" onclick="setTab('${t.key}')">${t.label}<span class="cnt${t.live>0?' lc':''}">${t.live>0?'● '+t.live:t.total}</span></button>`).join('');
  // Auto-scroll active tab into view on mobile (horizontal only)
  requestAnimationFrame(()=>{
    const wrap=document.getElementById('tabsWrap');
    const activeEl=document.querySelector('.tab.active');
    if(wrap && activeEl){
      if(activeTab==='all'){
        wrap.scrollLeft=0; // ALL is first — always start at beginning
      } else {
        const wrapRect=wrap.getBoundingClientRect();
        const tabRect=activeEl.getBoundingClientRect();
        if(tabRect.left < wrapRect.left || tabRect.right > wrapRect.right){
          wrap.scrollLeft += (tabRect.left - wrapRect.left) - (wrapRect.width/2) + (tabRect.width/2);
        }
      }
    }
  });
}
function setTab(k){activeTab=k;buildTabs();renderScores();}

// ═══════════════════════════════════════════════════════
// RENDER SCORES
// ═══════════════════════════════════════════════════════
function renderScores(){
  clearSkeleton();
  const el=document.getElementById('scoresGrid');
  const fil=activeTab==='all'?allGames:allGames.filter(g=>g.leagueLabel===activeTab);
  if(!fil.length){
    el.innerHTML=inFlight[selDate]
      ?`<div class="empty-state" style="border-color:var(--dim)"><span style="color:var(--accent)">Loading games…</span><small>Fetching schedules from all leagues</small></div>`
      :`<div class="empty-state">NO GAMES SCHEDULED<small>Try a different date or check back later</small></div>`;
    return;
  }
  const grps={};
  fil.forEach(g=>{if(!grps[g.leagueLabel])grps[g.leagueLabel]=[];grps[g.leagueLabel].push(g);});
  el.innerHTML=Object.entries(grps).map(([label,games])=>`
    <div class="sec-hdr"><span class="sec-title">${label}</span><div class="sec-line"></div><span class="sec-cnt">${games.length} GAME${games.length!==1?'S':''}</span></div>
    <div class="score-grid">${games.map(cardHTML).join('')}</div>
  `).join('');
  allGames.forEach(g=>{prevScores[g.id]={hs:g.home.score,as:g.away.score};});
}

// Returns line movement indicator HTML for a game's spread
function lineMovementHTML(g){
  const hist = oddsHistory[g.id];
  if(!hist||hist.length<2||!g.odds.spread) return '';
  // Parse spread numbers
  const parseSpreadNum = s => {
    if(!s) return null;
    const m = s.match(/([+-]?\d+\.?\d*)\s*$/);
    return m ? parseFloat(m[1]) : null;
  };
  const current = parseSpreadNum(g.odds.spread);
  const opening = parseSpreadNum(hist[0].spread);
  if(current===null||opening===null||current===opening) return '';
  const diff = current - opening;
  const dir = diff > 0 ? 'up' : 'down';
  const arrow = diff > 0 ? '▲' : '▼';
  const absDiff = Math.abs(diff).toFixed(1).replace('.0','');
  return `<span class="line-move ${dir}"><span class="line-move-arrow">${arrow}</span>${absDiff}</span>`;
}

function logoEl(t,size=28){
  return t.logo
    ?`<img class="team-logo" style="width:${size}px;height:${size}px" src="${t.logo}" alt="${t.abbr}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div class="team-logo-ph" style="display:none;width:${size}px;height:${size}px">${t.abbr}</div>`
    :`<div class="team-logo-ph" style="width:${size}px;height:${size}px">${t.abbr}</div>`;
}

function cardHTML(g){
  const stat=g.isLive
    ?`<span class="game-status s-live"><span id="st-${g.id}">${g.statusText}</span></span>`
    :g.isFinal?`<span class="game-status s-final">FINAL</span>`
    :`<span class="game-status s-pre">${g.startTime}</span>`;
  const _steam = g.isPre ? steamBadgeHTML(g.id) : '';
  const _pubSharp = g.isPre && g.odds && g.odds.spread ? pubSharpHTML(g) : '';
  const sc=t=>g.isPre?'ts-pre':g.isLive?'':t.winner?'ts-win':t.loser?'ts-loss':'';
  const aS=g.isPre?'—':g.away.score,hS=g.isPre?'—':g.home.score;
  let odds='';
  if(g.odds.spread||g.odds.total){
    odds=`<div class="odds-bar">
      ${g.odds.spread?`<div class="odds-pill"><div class="odds-label">Spread</div><div class="odds-val-wrap"><div class="odds-val">${g.odds.spread}</div>${lineMovementHTML(g)}</div>${g.odds.src?`<div class="odds-src">${g.odds.src}</div>`:''}</div>`:''}
      ${g.odds.total?`<div class="odds-pill"><div class="odds-label">Total</div><div class="odds-val">${g.odds.total}</div>${g.odds.src?`<div class="odds-src">${g.odds.src}</div>`:''}</div>`:''}
    </div>`;
  }
  return `<div class="score-card ${g.isLive?'live':''}" id="card-${g.id}" onclick="openGame('${g.id}')">
    <div class="card-top">${stat}${_steam}<span class="view-stats-hint">TAP FOR STATS ›</span></div>
    <div class="team-row"><div class="team-info">${logoEl(g.away)}
      <div class="team-name-wrap"><div class="team-name">${g.away.name}</div>${g.away.record?`<div class="team-rec">${g.away.record}</div>`:''}</div>
    </div><div class="team-score ${sc(g.away)}" id="as-${g.id}">${aS}</div></div>
    <div class="divider"></div>
    <div class="team-row"><div class="team-info">${logoEl(g.home)}
      <div class="team-name-wrap"><div class="team-name">${g.home.name}</div>${g.home.record?`<div class="team-rec">${g.home.record}</div>`:''}</div>
    </div><div class="team-score ${sc(g.home)}" id="hs-${g.id}">${hS}</div></div>
    ${odds}${_pubSharp}${buildPickHTML(g)}
  </div>`;
}

// ═══════════════════════════════════════════════════════
// GAME DETAIL MODAL
// ═══════════════════════════════════════════════════════
async function openGame(gameId){
  const g=allGames.find(x=>x.id===gameId);
  if(!g) return;
  openGameId=gameId;
  // Default to props tab for pre-game (no live stats yet), stats for in-progress/final
  modalTabActive = g.isPre ? 'props' : 'stats';
  modalStatData=null;

  // Render scoreboard header immediately
  populateModalHeader(g);

  // Show modal
  document.getElementById('modalOverlay').classList.add('open');
  document.body.style.overflow='hidden';

  // Set tabs
  renderModalTabs(g);

  // Show loading, then fetch stats
  document.getElementById('modalBody').innerHTML=`<div class="stats-loading"><div class="stats-loading-ring"></div>LOADING PLAYER STATS…</div>`;

  const statsData=await fetchGameStats(g);
  modalStatData=statsData;

  if(openGameId===gameId){ // still same game open
    renderModalTab(g, modalTabActive);
  }

  // Auto-refresh: live games every 30s, pre-game every 5min for prop line updates
  clearTimeout(modalPollTimer);
  if(g.isLive||g.isPre){
    scheduleModalPoll(gameId);
  }
}

function scheduleModalPoll(gameId){
  clearTimeout(modalPollTimer);
  const g0=allGames.find(x=>x.id===gameId);
  const delay=g0?.isLive ? 30000 : 5*60*1000; // 30s live, 5min pre-game
  modalPollTimer=setTimeout(async()=>{
    if(openGameId!==gameId) return;
    const g=allGames.find(x=>x.id===gameId);
    if(!g) return;
    if(g.isLive){
      // Live: refresh full box-score stats
      const fresh=await fetchGameStats(g);
      if(fresh&&openGameId===gameId){
        modalStatData=fresh;
        if(modalTabActive==='stats'||modalTabActive==='props') renderModalTab(g,modalTabActive);
      }
      scheduleModalPoll(gameId);
    } else if(g.isPre){
      // Pre-game: re-fetch season stats → recompute prop lines, patch DOM if changed
      const fresh=await fetchGameStats(g);
      if(fresh&&openGameId===gameId){
        const prevData=modalStatData;
        modalStatData=fresh;
        if(modalTabActive==='props'){
          patchPropLines(g, prevData, fresh);
        }
      }
      scheduleModalPoll(gameId);
    }
  }, delay);
}

// Surgically update prop line numbers in the open modal when they change
function patchPropLines(g, prevData, freshData){
  if(!prevData||!freshData) return;
  const cfg=SPORT_STAT_CONFIGS[g.sport]||SPORT_STAT_CONFIGS.basketball;
  const propStats=cfg.propStats||[];

  // Build a map of playerId+statKey → old line from prevData
  const oldLines={};
  (prevData.teams||[]).forEach(team=>{
    (team.players||[]).forEach(p=>{
      propStats.forEach(sk=>{
        const line=getPlayerPropLine(p,sk,cfg);
        oldLines[`${p.id}_${sk}`]=line;
      });
    });
  });

  // For each player in fresh data, check if their prop line changed
  (freshData.teams||[]).forEach(team=>{
    (team.players||[]).forEach(p=>{
      propStats.forEach(sk=>{
        const newLine=getPlayerPropLine(p,sk,cfg);
        const oldLine=oldLines[`${p.id}_${sk}`];
        if(oldLine==null||newLine===oldLine) return;

        // Find prop-btn rows for this player+stat by data attributes
        // Buttons are inside a .prop-pick-row; match by scanning onclick for gameId+playerId+statKey
        const safeId=p.id.replace(/['"\\]/g,'');
        document.querySelectorAll('.prop-btn').forEach(btn=>{
          const oc=btn.getAttribute('onclick')||'';
          if(oc.includes(g.id)&&oc.includes(safeId)&&oc.includes(sk)){
            // Update line display
            const lineEl=btn.querySelector('.prop-line-num');
            if(lineEl){
              lineEl.textContent=newLine;
              lineEl.classList.add('prop-line-updated');
              setTimeout(()=>lineEl.classList.remove('prop-line-updated'),2500);
            }
            // Update onclick to use new line value
            const updated=oc.replace(/,(\d+\.?\d*),'(over|under)'/,`,${newLine},'$2'`);
            btn.setAttribute('onclick',updated);
          }
        });
      });
    });
  });
}

function closeModal(){
  document.getElementById('modalOverlay').classList.remove('open');
  document.body.style.overflow='';
  openGameId=null;
  clearTimeout(modalPollTimer);
}

function handleModalOverlayClick(e){
  if(e.target===document.getElementById('modalOverlay')) closeModal();
}

function populateModalHeader(g){
  document.getElementById('modalLeague').textContent=g.leagueLabel;

  // Away team
  const away=document.getElementById('modalAwayTeam');
  away.innerHTML=`${logoEl(g.away,52)}<div class="modal-team-name">${g.away.name}</div>${g.away.record?`<div class="modal-team-rec">${g.away.record}</div>`:''}`;

  // Home team
  const home=document.getElementById('modalHomeTeam');
  home.innerHTML=`${logoEl(g.home,52)}<div class="modal-team-name">${g.home.name}</div>${g.home.record?`<div class="modal-team-rec">${g.home.record}</div>`:''}`;

  updateModalScoreboard(g);
}

function updateModalScoreboard(g){
  const aScoreEl=document.getElementById('modalAwayScore');
  const hScoreEl=document.getElementById('modalHomeScore');
  const statusEl=document.getElementById('modalStatus');

  if(g.isPre){
    aScoreEl.textContent='—'; hScoreEl.textContent='—';
    aScoreEl.className='modal-score-num'; hScoreEl.className='modal-score-num';
    statusEl.className='modal-status pre'; statusEl.textContent=g.startTime;
  } else {
    aScoreEl.textContent=g.away.score; hScoreEl.textContent=g.home.score;
    if(g.isFinal){
      aScoreEl.className='modal-score-num '+(g.away.winner?'winner':'loser');
      hScoreEl.className='modal-score-num '+(g.home.winner?'winner':'loser');
      statusEl.className='modal-status final'; statusEl.textContent='FINAL';
    } else {
      aScoreEl.className='modal-score-num'; hScoreEl.className='modal-score-num';
      statusEl.className='modal-status live'; statusEl.textContent=g.statusText;
    }
  }
}

function renderModalTabs(g){
  const tabs=[
    {id:'stats', label:'Player Stats'},
    {id:'props', label:'Player Props'},
    {id:'picks', label:'Game Picks'},
  ];
  // Prop builder button (injected separately, not as a tab)
  const builderBtn = g.isPre ? `<button class="modal-tab" onclick="openPropBuilder('${g.id}')" style="margin-left:auto;color:var(--accent)">🎯 Builder</button>` : '';
  setTimeout(()=>{
    const wrap = document.getElementById('modalTabs');
    if(wrap && !wrap.querySelector('.prop-builder-injected') && g.isPre){
      const btn = document.createElement('button');
      btn.className = 'modal-tab prop-builder-injected';
      btn.style.marginLeft = 'auto';
      btn.style.color = 'var(--accent)';
      btn.textContent = '🎯 Builder';
      btn.onclick = ()=>openPropBuilder(g.id);
      wrap.appendChild(btn);
    }
  }, 50);
  document.getElementById('modalTabs').innerHTML=tabs.map(t=>
    `<button class="modal-tab ${modalTabActive===t.id?'active':''}" data-tab="${t.id}" onclick="switchModalTab('${t.id}')">${t.label}</button>`
  ).join('');
}

function switchModalTab(tab){
  modalTabActive=tab;
  document.getElementById('modalTabs').querySelectorAll('.modal-tab').forEach(el=>{
    el.classList.toggle('active', el.dataset.tab===tab);
  });
  const g=allGames.find(x=>x.id===openGameId);
  if(g) renderModalTab(g,tab);
}

function renderModalTab(g, tab){
  const body=document.getElementById('modalBody');
  if(tab==='stats'){
    if(!modalStatData){
      body.innerHTML=g.isPre
        ?`<div class="stats-no-data">Game hasn't started yet — stats will appear once it begins.</div>`
        :`<div class="stats-no-data">No player stats available for this game.</div>`;
      return;
    }
    body.innerHTML=renderStatsTable(g, modalStatData);
  } else if(tab==='props'){
    // Props work pre-game too — use roster from statsData or show default roster
    body.innerHTML=renderPropsTable(g, modalStatData);
  } else if(tab==='picks'){
    body.innerHTML=renderGamePicksInModal(g);
  }
}

// ═══════════════════════════════════════════════════════
// STATS TABLE RENDERER
// ═══════════════════════════════════════════════════════
function renderStatsTable(g, statsData){
  const cfg=statsData.cfg || SPORT_STAT_CONFIGS[g.sport] || SPORT_STAT_CONFIGS.basketball;
  const cols=cfg.cols || [];

  return statsData.teams.map(team=>`
    <div class="stats-team-hdr">
      ${team.logo?`<img class="stats-team-logo" src="${team.logo}" alt="">`:''}<span class="stats-team-name">${team.name}</span>
    </div>
    <table class="stats-table">
      <thead><tr>
        <th>Player</th>
        ${cols.map(c=>`<th>${cfg.labels[c]||c.toUpperCase()}</th>`).join('')}
      </tr></thead>
      <tbody>
        ${team.players.filter(p=>p.active).map(p=>{
          // Find the leader for each stat column in this team for gold highlight
          return `<tr>
            <td>${p.name}${p.position?` <span style="color:var(--muted);font-size:9px">${p.position}</span>`:''}</td>
            ${cols.map(c=>{
              const val=getStatVal(p.stats,c);
              // Highlight top value per column
              const numVal=parseFloat(String(val).replace(/[^0-9.]/g,''));
              const isLeader=!isNaN(numVal)&&numVal>0&&isTeamLeader(team.players,c,p.id);
              return `<td class="${isLeader?'stat-leader':'stat-val'}">${val}</td>`;
            }).join('')}
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  `).join('');
}

function isTeamLeader(players, col, playerId){
  let maxVal=-Infinity, leaderId=null;
  players.filter(p=>p.active).forEach(p=>{
    const v=parseFloat(String(getStatVal(p.stats,col)).replace(/[^0-9.]/g,''));
    if(!isNaN(v)&&v>maxVal){maxVal=v;leaderId=p.id;}
  });
  return leaderId===playerId && maxVal>0;
}

// ═══════════════════════════════════════════════════════
// PLAYER PROPS RENDERER
// ═══════════════════════════════════════════════════════
function renderPropsTable(g, statsData){
  const cfg = SPORT_STAT_CONFIGS[g.sport] || SPORT_STAT_CONFIGS.basketball;
  const propStats = cfg.propStats || [];
  const isPreGame = g.isPre || (statsData && statsData.preGame);
  const fin = (!g.isPre) ? 'disabled' : ''; // lock props once game starts

  if(!propStats.length) return `<div class="stats-no-data">Player props not available for this sport.</div>`;
  if(!statsData || !statsData.teams || !statsData.teams.length){
    return `<div class="stats-loading"><div class="stats-loading-ring"></div>LOADING ROSTER…</div>`;
  }

  let html = '';

  propStats.forEach(statKey=>{
    const propDef = (cfg.propDefs||{})[statKey] || {label:statKey.toUpperCase(), fb:0.5};
    const statLabel = propDef.label;

    html += `<div class="prop-stat-section">
      <div class="prop-stat-hdr">
        <span class="prop-stat-title">${statLabel}</span>
        <span class="prop-stat-line-badge" style="font-size:9px;color:var(--muted)">Season avg line per player</span>
      </div>`;

    statsData.teams.forEach(team=>{
      const isSynthetic = !!team.synthetic;
      const players = isPreGame
        ? team.players.slice(0, isSynthetic ? 6 : 12)
        : team.players.filter(p=>p.active).slice(0, 12);
      if(!players.length) return;

      html += `<div class="prop-team-block">
        <div class="prop-team-label">
          ${team.logo ? `<img src="${team.logo}" alt="" style="width:14px;height:14px;object-fit:contain;margin-right:5px">` : ''}
          <span>${team.name}</span>
        </div>`;

      players.forEach(p=>{
        // Get real line: season avg for this player/stat (rounded to .5), else fallback
        const line = isSynthetic ? propDef.fb : getPlayerPropLine(p, statKey, cfg);
        const currentVal = (!isPreGame && !isSynthetic) ? getStatVal(p.stats, statKey) : null;
        const numCurrent = currentVal ? parseFloat(String(currentVal).replace(/[^0-9.]/g,'')) : NaN;
        const pickKey = `prop_${g.id}_${p.id}_${statKey}`;
        const existingPick = picks.find(pk=>pk.gameId===pickKey);
        const resultClass = existingPick?.result && existingPick.result!=='pending' ? existingPick.result : '';
        const isHot = !isPreGame && !isSynthetic && !isNaN(numCurrent) && numCurrent >= line;
        const showCurrent = currentVal && currentVal !== '—' && !isSynthetic;
        // Mark if line is from season avg vs pure fallback
        const hasRealLine = !isSynthetic && (p.seasonAvgs && Object.keys(p.seasonAvgs).length>0);

        const safeId = p.id.replace(/['"\\]/g,'');
        const safeName = p.name.replace(/'/g,"\\'");
        const safeSL = statLabel.replace(/'/g,"\\'");
        const safeAway = g.away.name.replace(/'/g,"\\'");
        const safeHome = g.home.name.replace(/'/g,"\\'");

        html += `<div class="prop-pick-row">
          <div class="prop-player-info">
            <span class="prop-player-name">${isSynthetic ? '<span style="color:var(--dim)">Pending lineup</span>' : p.name}</span>
            ${p.position ? `<span class="prop-pos-badge">${p.position}</span>` : ''}
          </div>
          ${showCurrent ? `<div class="prop-cur-wrap">
            <div class="prop-current ${isHot?'hot':''}">${currentVal}</div>
            <div class="prop-cur-label">NOW</div>
          </div>` : `<div style="min-width:8px"></div>`}
          <div class="prop-btns">
            <button class="prop-btn over ${existingPick?.side==='over'?'active':''} ${existingPick?.side==='over'?resultClass:''} ${fin||isSynthetic?'disabled':''}"
              onclick="makePropPick('${g.id}','${safeId}','${safeName}','${statKey}','${safeSL}',${line},'over','${safeAway} vs ${safeHome}')">
              <span class="prop-dir">OVER</span><span class="prop-line-num">${line}${hasRealLine?'':''}</span>
            </button>
            <button class="prop-btn under ${existingPick?.side==='under'?'active':''} ${existingPick?.side==='under'?resultClass:''} ${fin||isSynthetic?'disabled':''}"
              onclick="makePropPick('${g.id}','${safeId}','${safeName}','${statKey}','${safeSL}',${line},'under','${safeAway} vs ${safeHome}')">
              <span class="prop-dir">UNDER</span><span class="prop-line-num">${line}</span>
            </button>
          </div>
        </div>`;
      });

      html += `</div>`;
    });

    html += `</div>`;
  });

  return html || `<div class="stats-no-data">No player data available.</div>`;
}

// ═══════════════════════════════════════════════════════
// GAME PICKS IN MODAL (spread / total)
// ═══════════════════════════════════════════════════════
function renderGamePicksInModal(g){
  const html=buildPickHTML(g);
  if(!html) return `<div class="stats-no-data">No odds available for game picks on this game.</div>`;
  return `<div style="padding:8px 0">${html}</div>`;
}

// ═══════════════════════════════════════════════════════
// PLAYER PROP PICKS LOGIC
// ═══════════════════════════════════════════════════════
function makePropPick(gameId, playerId, playerName, statKey, statLabel, line, side, gameStr){
  if(!currentUser){ alert('Enter your name to make picks.'); return; }
  const g=allGames.find(x=>x.id===gameId);
  if(g&&!g.isPre) return; // block once game starts
  // Use a composite key so prop picks are distinct from game picks
  const pickKey=`prop_${gameId}_${playerId}_${statKey}`;

  // Toggle off if same side
  const idx=picks.findIndex(p=>p.gameId===pickKey&&p.side===side);
  if(idx!==-1){
    picks.splice(idx,1);
    savePicks();updateRecordUI();renderPicksPanel();
    // Re-render props tab
    if(g && openGameId===gameId) renderModalTab(g,'props');
    return;
  }

  // Remove opposite pick for same player/stat
  picks=picks.filter(p=>!(p.gameId===pickKey));

  picks.push({
    gameId:pickKey, type:'prop', side,
    description:`${playerName} ${statLabel} ${side==='over'?'O':'U'} ${line}`,
    gameStr,
    result:'pending',
    playerId, statKey, line,
    playerName, statLabel,
    homeTeam:g?.home.name||'',awayTeam:g?.away.name||'',
    league:g?.leagueLabel||'',madeAt:Date.now(),
    // Store the actual game id separately for result checking
    actualGameId: gameId,
  });
  savePicks();updateRecordUI();renderPicksPanel();
  // Subtle flash on the game card
  requestAnimationFrame(()=>{
    const card=document.getElementById('card-'+gameId);
    if(card){card.classList.remove('pick-flash');void card.offsetWidth;card.classList.add('pick-flash');}
  });

  // Re-render props tab to reflect selection (works even pre-game)
  if(g && openGameId===gameId) renderModalTab(g,'props');
}

async function checkPropPickResults(){
  // Group pending prop picks by game so we fetch each boxscore at most once
  const pendingProps=picks.filter(pk=>pk.type==='prop'&&pk.result==='pending');
  if(!pendingProps.length) return;

  const gameIds=[...new Set(pendingProps.map(pk=>pk.actualGameId||pk.gameId))];
  let changed=false;

  await Promise.allSettled(gameIds.map(async gid=>{
    const g=allGames.find(x=>x.id===gid);
    if(!g||!g.isFinal) return;

    // Use cached modal data if this game is open, otherwise fetch boxscore fresh
    let statsData=null;
    if(openGameId===gid && modalStatData){
      statsData=modalStatData;
    } else {
      const lg=LEAGUES.find(l=>l.league===g.league);
      if(!lg) return;
      const data=await go(`${ESPN}/${lg.sport}/${lg.league}/summary?event=${gid}`,10000);
      if(data) statsData=parseSummaryStats(data, g.sport);
    }
    if(!statsData) return;

    picks.forEach(pick=>{
      if(pick.type!=='prop'||pick.result!=='pending') return;
      if((pick.actualGameId||pick.gameId)!==gid) return;
      let finalVal=null;
      (statsData.teams||[]).forEach(team=>{
        const pl=team.players.find(p=>p.id===pick.playerId);
        if(pl){
          const v=parseFloat(String(getStatVal(pl.stats,pick.statKey)).replace(/[^0-9.]/g,''));
          if(!isNaN(v)) finalVal=v;
        }
      });
      if(finalVal===null) return;
      const line=pick.line;
      if(Math.abs(finalVal-line)<0.01) pick.result='push';
      else if(pick.side==='over') pick.result=finalVal>line?'won':'lost';
      else pick.result=finalVal<line?'won':'lost';
      changed=true;
    });
  }));

  if(changed){ savePicks(); checkAchievements(); updateRecordUI(); renderPicksPanel(); }
}

// ═══════════════════════════════════════════════════════
// GAME PICKS (spread / total)
// ═══════════════════════════════════════════════════════
// ─── USER IDENTITY ──────────────────────────────────────────────
function loadUser(){
  try{ return JSON.parse(localStorage.getItem('ls_user')||'null'); }catch{ return null; }
}
function saveUser(u){ localStorage.setItem('ls_user',JSON.stringify(u)); }

function initUser(){
  const u=loadUser();
  if(u&&u.name){
    currentUser=u;
    picks=loadPicks(); // load picks now that currentUser is set
    applyUser();
    document.getElementById('nameModalOverlay').classList.add('hidden');
  } else {
    // Modal is visible by default; just focus the input
    setTimeout(()=>{ const inp=document.getElementById('nameInput'); if(inp) inp.focus(); },100);
  }
}

function applyUser(){
  if(!currentUser) return;
  const chip=document.getElementById('userChip');
  const av=document.getElementById('userChipAvatar');
  const nm=document.getElementById('userChipName');
  if(chip){ chip.style.display='flex'; }
  if(av)  { av.textContent=currentUser.name[0].toUpperCase(); }
  if(nm)  { nm.textContent=currentUser.name; }
  picks=loadPicks();
  try{ computeRatingsDaily(); }catch{}
  updateRecordUI();
  setTimeout(updateBankrollUI, 100);
  if(typeof startServerSync==='function') startServerSync();
  if(typeof checkOnboarding==='function') setTimeout(checkOnboarding, 1200);
  if(typeof scheduleDailyDigest==='function') setTimeout(scheduleDailyDigest, 5000);
  if(typeof scheduleWeeklyRecapPush==='function') setTimeout(scheduleWeeklyRecapPush, 3000);
  setTimeout(()=>{
    if(!localStorage.getItem('push_prompt_shown')){
      localStorage.setItem('push_prompt_shown','1');
      if(typeof renderPushPrompt==='function') renderPushPrompt();
    }
  }, 4000);
}

// submitName is now replaced by submitGuest/submitLogin/submitSignup
// Kept as no-op for any legacy references
function submitName(){ submitGuest(); }

function promptRename(){
  const newName=prompt('Change your display name:',currentUser?.name||'');
  if(!newName||!newName.trim()) return;
  const name=newName.trim().slice(0,24);
  currentUser={...currentUser, name};
  saveUser(currentUser);
  applyUser();
  publishToLeaderboard();
}

// Auth keyboard shortcuts (nameInput/nameSubmitBtn removed — now handled inline)
// Enter key handled via onkeydown attributes on each auth input

// ─── PICKS STORAGE (user-scoped) ─────────────────────────────────
function picksKey(){ return `ls_picks_${currentUser?.id||'anon'}`; }
function loadPicks(){
  try{ return JSON.parse(localStorage.getItem(picksKey())||'[]'); }catch{ return []; }
}
function savePicks(){
  localStorage.setItem(picksKey(),JSON.stringify(picks));
  try{ if(typeof computeRatingsDaily==="function") computeRatingsDaily(); }catch{}
  try{ if(typeof syncPicksToServer==="function") syncPicksToServer(); }catch{}
  publishToLeaderboard();   // async, fire-and-forget
  publishPickTrends();      // async, fire-and-forget
  checkAchievements();
  updateMobileBadge();
}
// ═══════════════════════════════════════════════════════
// SHARP RATING (PROPRIETARY) — Daily Recalculation (Client)
// NOTE: In a production setup, move this to a server job.
// This implementation recalculates once per local day and caches results.
// ═══════════════════════════════════════════════════════
const RATINGS_KEY = () => `ls_ratings_${currentUser?.id||'anon'}`;

function todayKey(ts=Date.now()){
  const d=new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function clamp(x, a, b){ return Math.max(a, Math.min(b, x)); }

function americanProfit(risk, american){
  const o = parseFloat(american);
  if(!isFinite(o)) return Math.round(risk*(100/110)*100)/100;
  if(o>0) return Math.round(risk*(o/100)*100)/100;
  return Math.round(risk*(100/Math.abs(o))*100)/100;
}
function pickPnL(p){
  const risk = Math.max(0, +p.wager||0);
  if(p.result==='won') return americanProfit(risk, p.odds||-110);
  if(p.result==='lost') return -risk;
  return 0; // push/void
}

function weekKeyFromTs(ts){
  // ISO week key: YYYY-WW
  const d=new Date(ts);
  // Thursday in current week decides the year.
  d.setHours(0,0,0,0);
  d.setDate(d.getDate() + 3 - ((d.getDay()+6)%7));
  const week1=new Date(d.getFullYear(),0,4);
  const weekNo=1+Math.round(((d-week1)/86400000 - 3 + ((week1.getDay()+6)%7))/7);
  return `${d.getFullYear()}-${String(weekNo).padStart(2,'0')}`;
}

function computeConsistencyScore(picksArr){
  // Consistency: penalize weeks with ROI < -5%
  const byWeek={};
  picksArr.forEach(p=>{
    const ts = p.settledAt || p.madeAt || Date.now();
    const wk = weekKeyFromTs(ts);
    if(!byWeek[wk]) byWeek[wk]={risk:0,pnl:0};
    const risk=Math.max(0, +p.wager||0);
    byWeek[wk].risk += risk;
    byWeek[wk].pnl  += pickPnL(p);
  });
  const weeks=Object.keys(byWeek);
  if(!weeks.length) return 0;
  let bad=0;
  weeks.forEach(w=>{
    const r=byWeek[w].risk||0;
    const roi = r>0 ? (byWeek[w].pnl||0)/r : 0;
    if(roi < -0.05) bad++;
  });
  return clamp(100 - (bad/weeks.length)*120, 0, 100);
}

function computeSinglesRating(picksArr, isAllTime){
  const n = picksArr.length;
  if(n<=0) return {rating:null, tier:'—', n:0, winRate:0, roi:0, subs:null};
  const wins=picksArr.filter(p=>p.result==='won').length;
  const losses=picksArr.filter(p=>p.result==='lost').length;
  const risk=picksArr.reduce((a,p)=>a+Math.max(0,+p.wager||0),0);
  const pnl=picksArr.reduce((a,p)=>a+pickPnL(p),0);
  const winRate = (wins+losses)>0 ? wins/(wins+losses) : 0;
  const roi = risk>0 ? pnl/risk : 0;

  // Subscores (0–100) — proprietary anchors
  const accuracyScore = clamp(((winRate - 0.45) / 0.20) * 100, 0, 100);
  const roiScore = clamp(((roi - (-0.05)) / 0.20) * 100, 0, 100);
  const consistencyScore = computeConsistencyScore(picksArr);
  const confDen = isAllTime ? 30 : 20;
  const confidenceScore = clamp((Math.sqrt(n)/confDen) * 100, 0, 100);

  const rating = (
    (isAllTime ? 0.30 : 0.35) * accuracyScore +
    (isAllTime ? 0.30 : 0.35) * roiScore +
    0.15 * consistencyScore +
    (isAllTime ? 0.25 : 0.15) * confidenceScore
  );

  return {
    rating: Math.round(rating),
    tier: tierForSingles(rating, n),
    n, winRate, roi,
    subs:{accuracyScore, roiScore, consistencyScore, confidenceScore}
  };
}

function tierForSingles(r, n){
  if(!isFinite(r)) return '—';
  // Gate elite by volume
  if(r>=85 && n>=100) return 'Elite';
  if(r>=70) return 'Pro';
  if(r>=55) return 'Sharp';
  if(r>=40) return 'Solid';
  return 'Rookie';
}

function computeParlayRating(parlaysArr, isAllTime){
  const n = parlaysArr.length;
  if(n<=0) return {rating:null, tier:'—', n:0, roi:0, avgLegs:0, subs:null};

  const risk=parlaysArr.reduce((a,p)=>a+Math.max(0,+p.wager||0),0);
  const pnl=parlaysArr.reduce((a,p)=>a+pickPnL(p),0);
  const roi = risk>0 ? pnl/risk : 0;
  const avgLegs = parlaysArr.length ? (parlaysArr.reduce((a,p)=>a+((p.parlayLegs||[]).length||0),0)/parlaysArr.length) : 0;

  const efficiencyScore = clamp(((roi - (-0.10))/0.40)*100, 0, 100);
  const riskScore = clamp(100 - Math.abs(avgLegs - 3)*15, 0, 100);
  const confidenceScore = clamp((Math.sqrt(n)/15)*100, 0, 100);

  const rating = 0.50*efficiencyScore + 0.25*riskScore + 0.25*confidenceScore;

  return {
    rating: Math.round(rating),
    tier: tierForParlay(rating, n),
    n, roi, avgLegs,
    subs:{efficiencyScore, riskScore, confidenceScore}
  };
}

function tierForParlay(r, n){
  if(!isFinite(r)) return '—';
  if(r>=85 && n>=50) return 'Sniper';
  if(r>=70) return 'Strategic';
  if(r>=55) return 'Calculated';
  if(r>=40) return 'Aggressive';
  return 'Reckless';
}

function computeSharpRatingsSnapshot(nowTs=Date.now()){
  const MS_90D = 90*24*60*60*1000;
  const since90 = nowTs - MS_90D;

  const settled = picks.filter(p=>p.result && p.result!=='pending');
  const settledSingles = settled.filter(p=>p.type!=='parlay' && p.type!=='prop' ? true : true).filter(p=>p.type!=='parlay'); // singles includes spread/total/prop
  const settledParlays = settled.filter(p=>p.type==='parlay');

  // Odds guardrails (singles only)
  function inOddsRange(p){
    const o = parseFloat(p.odds);
    if(!isFinite(o)) return true;
    return o>=-250 && o<=250;
  }

  const singles90 = settledSingles.filter(p=>(p.settledAt||p.madeAt||0) >= since90).filter(inOddsRange);
  const singlesAT = settledSingles.filter(inOddsRange);

  const parlays90 = settledParlays.filter(p=>(p.settledAt||p.madeAt||0) >= since90);
  const parlaysAT = settledParlays;

  // Per-sport buckets for singles
  function sportKey(p){
    return (p.league||'Other').toUpperCase();
  }
  const sportBuckets90 = {};
  const sportBucketsAT = {};
  singles90.forEach(p=>{
    const k=sportKey(p);
    (sportBuckets90[k]=sportBuckets90[k]||[]).push(p);
  });
  singlesAT.forEach(p=>{
    const k=sportKey(p);
    (sportBucketsAT[k]=sportBucketsAT[k]||[]).push(p);
  });

  // Compute per-sport ratings (gate display by n thresholds)
  const sports90 = {};
  const sportsAT = {};
  Object.keys(sportBuckets90).forEach(k=>{
    if((sportBuckets90[k]||[]).length>=20){
      sports90[k]=computeSinglesRating(sportBuckets90[k], false);
    }
  });
  Object.keys(sportBucketsAT).forEach(k=>{
    if((sportBucketsAT[k]||[]).length>=50){
      sportsAT[k]=computeSinglesRating(sportBucketsAT[k], true);
    }
  });

  // Overall: pick-count weighted across eligible sports
  function weightedOverall(sportsObj){
    const items = Object.entries(sportsObj).filter(([,v])=>v && isFinite(v.rating));
    const denom = items.reduce((a,[,v])=>a+(v.n||0),0);
    if(!denom) return {rating:null, tier:'—', n:0};
    const num = items.reduce((a,[,v])=>a+(v.rating*(v.n||0)),0);
    const r = num/denom;
    return {rating: Math.round(r), tier: tierForSingles(r, denom), n: denom};
  }

  const overall90 = weightedOverall(sports90);
  const overallAT = weightedOverall(sportsAT);

  const parlay90 = computeParlayRating(parlays90,false);
  const parlayAT = computeParlayRating(parlaysAT,true);

  // Inactivity decay (90D only): if no singles pick made in last 14 days
  const lastSingleTs = (picks.filter(p=>p.type!=='parlay').map(p=>p.madeAt||0).sort((a,b)=>b-a)[0]) || 0;
  const daysInactive = lastSingleTs ? Math.floor((nowTs - lastSingleTs)/86400000) : 999;
  if(overall90.rating!==null && daysInactive>=14){
    const weeksInactive = Math.min(5, Math.floor((daysInactive-14)/7)+1);
    overall90.rating = clamp(overall90.rating - weeksInactive, 0, 100);
    overall90.tier = tierForSingles(overall90.rating, overall90.n||0);
    overall90.decay = weeksInactive;
  } else {
    overall90.decay = 0;
  }

  return {
    asOf: nowTs,
    dayKey: todayKey(nowTs),
    overall90, overallAT,
    sports90, sportsAT,
    parlay90, parlayAT
  };
}

function computeRatingsDaily(force=false){
  if(!currentUser) return null;
  const key = RATINGS_KEY();
  let cached=null;
  try{ cached = JSON.parse(localStorage.getItem(key)||'null'); }catch{}
  const today = todayKey();
  if(!force && cached && cached.dayKey===today) return cached;
  const snap = computeSharpRatingsSnapshot(Date.now());
  try{ localStorage.setItem(key, JSON.stringify(snap)); }catch{}
  return snap;
}


// ─── SUPABASE REST API (plain fetch — no library, no workers) ──────
const SUPA_URL = 'https://uibdzjvoehhpmjniksyk.supabase.co';
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVpYmR6anZvZWhocG1qbmlrc3lrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIzMzgwMDUsImV4cCI6MjA4NzkxNDAwNX0.6-d8KmqsKBRfP5IZEJnm-Mhd3eAwFVFIRk2NM3xAAS4';
const SUPA_HDR = {'apikey':SUPA_KEY,'Authorization':'Bearer '+SUPA_KEY,'Content-Type':'application/json'};
const SUPA_REST = SUPA_URL+'/rest/v1';
const SUPA_AUTH = SUPA_URL + '/auth/v1';
const SUPA_AUTH_HDR = { 'apikey': SUPA_KEY, 'Content-Type': 'application/json' };

// ── Supabase connectivity state ────────────────────────────────────
let supaOnline = true;          // flips false after repeated failures
let supaFailCount = 0;
const SUPA_MAX_FAILS = 3;       // stop retrying after 3 consecutive failures
const SUPA_RETRY_AFTER = 60000; // re-test after 60s if offline

function markSupaFail(label, err){
  supaFailCount++;
  const msg = err?.message || String(err);
  if(msg.includes('Failed to fetch')){
    if(supaFailCount===1) console.warn(`⚠️ Supabase unreachable — check if project is paused at supabase.com/dashboard (free tier pauses after 7 days of inactivity). Will retry.`);
  } else {
    console.warn(`[${label}]`, msg);
  }
  if(supaFailCount >= SUPA_MAX_FAILS){
    if(supaOnline){
      supaOnline = false;
      console.warn('⚠️ Supabase offline — falling back to localStorage only. Will retry in 60s.');
      setTimeout(retrySupaConnection, SUPA_RETRY_AFTER);
    }
  }
}

function markSupaOk(){
  if(!supaOnline || supaFailCount > 0){
    console.log('✅ Supabase reconnected');
  }
  supaOnline = true;
  supaFailCount = 0;
}

async function retrySupaConnection(){
  try{
    const r = await Promise.race([
      fetch(`${SUPA_REST}/leaderboard?select=user_id&limit=1`,{headers:{...SUPA_HDR,'Accept':'application/json'}}),
      timeoutPromise(5000)
    ]);
    if(r.ok){ markSupaOk(); publishToLeaderboard(); }
    else throw new Error(`HTTP ${r.status}`);
  }catch(e){
    supaFailCount = SUPA_MAX_FAILS - 1; // allow one more fail before suppressing
    markSupaFail('retry', e);
    setTimeout(retrySupaConnection, SUPA_RETRY_AFTER);
  }
}

function timeoutPromise(ms){ return new Promise((_,rej)=>setTimeout(()=>rej(new Error('Request timed out')),ms)); }

async function sbFetch(url, opts={}){
  if(!supaOnline) throw new Error('Supabase offline');
  // Use Promise.race instead of AbortSignal to avoid structured-clone errors
  return Promise.race([
    fetch(url, opts),
    timeoutPromise(8000)
  ]);
}

async function sbSelect(table, params=''){
  try{
    const r = await sbFetch(`${SUPA_REST}/${table}?${params}`, {
      headers:{...SUPA_HDR,'Accept':'application/json'}
    });
    if(!r.ok){
      const txt = await r.text();
      throw new Error(`HTTP ${r.status}: ${txt}`);
    }
    markSupaOk();
    return r.json();
  }catch(e){
    markSupaFail(table, e);
    throw new Error(`[${table}] ${e.message}`);
  }
}


async function sbRpc(fn, args={}){
  try{
    const r = await sbFetch(`${SUPA_REST}/rpc/${fn}`, {
      method:'POST',
      headers:{...SUPA_HDR,'Accept':'application/json'},
      body: JSON.stringify(args||{})
    });
    if(!r.ok){
      const t = await r.text();
      throw new Error(`HTTP ${r.status}: ${t}`);
    }
    markSupaOk();
    return r.json();
  }catch(e){
    markSupaFail('rpc:'+fn, e);
    throw new Error(`[rpc:${fn}] ${e.message}`);
  }
}


async function sbUpsert(table, row){
  try{
    const r = await sbFetch(`${SUPA_REST}/${table}`, {
      method:'POST',
      headers:{...SUPA_HDR,'Prefer':'resolution=merge-duplicates,return=minimal'},
      body:JSON.stringify(row)
    });
    if(!r.ok){
      const txt = await r.text();
      throw new Error(`HTTP ${r.status}: ${txt}`);
    }
    markSupaOk();
  }catch(e){
    markSupaFail(table, e);
    throw new Error(`[${table}] ${e.message}`);
  }
}

// ─── LEADERBOARD (Supabase, falls back to localStorage) ────────────
async function publishToLeaderboard(){
  if(!currentUser) return;
  const settled=picks.filter(pk=>pk.result!=='pending');
  const w=settled.filter(pk=>pk.result==='won').length;
  const l=settled.filter(pk=>pk.result==='lost').length;
  const p=settled.filter(pk=>pk.result==='push').length;
  const total=picks.length;
  const lastPick=picks.length?Math.max(...picks.map(pk=>pk.madeAt)):0;
  const bankroll = computeBankroll();
  const pnl = totalPnL();
  const lockRec = getLockRecord();
  const row={
    user_id: currentUser.id,
    name: currentUser.name,
    w, l, p, total,
    last_pick: lastPick,
    updated_at: Date.now(),
    recent_picks: settled.slice(-20).map(pk=>({result:pk.result,type:pk.type,madeAt:pk.madeAt,isLock:pk.isLock||false})),
    bankroll: Math.round(bankroll),
    pnl: Math.round(pnl),
    lock_w: lockRec.w,
    lock_l: lockRec.l,
  };
  // Also persist locally as fallback
  try{ localStorage.setItem('lb:'+currentUser.id, JSON.stringify({...row, id:currentUser.id, recentPicks:row.recent_picks})); }catch{}
  try{
    await sbUpsert('leaderboard', row);
  }catch(e){ if(supaOnline!==false) console.warn('Leaderboard publish failed:',e?.message); }
}

async function fetchLeaderboard(){
  try{
    const data=await sbSelect('leaderboard','select=*&order=w.desc');
    if(data && data.length){
      return data.map(r=>({
        id: r.user_id,
        name: r.name,
        w: r.w||0, l: r.l||0, p: r.p||0, total: r.total||0,
        lastPick: r.last_pick||0,
        recentPicks: r.recent_picks||[],
        bankroll: r.bankroll||1000,
        pnl: r.pnl||0,
        lockW: r.lock_w||0,
        lockL: r.lock_l||0,
      }));
    }
  }catch(e){ if(supaOnline!==false) console.warn('Leaderboard fetch failed:',e?.message); }
  // Fallback: localStorage
  const entries=[];
  try{
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);
      if(!k||!k.startsWith('lb:')) continue;
      try{ const v=localStorage.getItem(k); if(v) entries.push(JSON.parse(v)); }catch{}
    }
  }catch{}
  return entries;
}

function buildPickHTML(g){
  const hasPick=picks.find(p=>p.gameId===g.id&&p.type!=='prop');
  if(!g.odds.spread&&!g.odds.total&&!hasPick) return '';
  const locked=!g.isPre;
  const fin=locked?'disabled':'';
  const lockTip=locked?' title="Picks locked — game has started"':'';
  let html=`<div class="pick-section" onclick="event.stopPropagation()">`;
  if(locked){
    html+=`<div class="pick-label" style="color:var(--muted)">🔒 Picks Closed</div>`;
  } else {
    html+=`<div class="pick-label">Game Picks</div>`;
  }
  if(g.odds.spread){
    // ESPN 'details' format: "AWAY_ABBR LINE" e.g. "HOU -15.5" means away team is -15.5
    // parts[last] is the numeric line; if string has a team abbr prefix it belongs to away
    const parts=g.odds.spread.trim().split(/\s+/);
    const rawLine=parts[parts.length-1];
    const rawNum=parseFloat(rawLine);
    // Determine which team the ESPN line belongs to
    // If details starts with a team abbr (letters before the number), it's the away line
    // If it's just a bare number (fallback path), treat it as the favorite's line
    const hasTeamPrefix = parts.length > 1 && isNaN(parseFloat(parts[0]));
    // awayLine: the line for the away team; homeLine: the opposite
    let awayLine, homeLine;
    if(hasTeamPrefix){
      // Standard ESPN format: "HOU -15.5" → away is -15.5, home is +15.5
      awayLine = rawNum > 0 ? `+${rawNum}` : String(rawNum);
      homeLine = rawNum > 0 ? `-${Math.abs(rawNum)}` : `+${Math.abs(rawNum)}`;
    } else {
      // Bare number — ESPN gave us the favorite's line without team prefix
      // Convention: negative = favorite. Assign to whichever side makes sense.
      // We'll show it as the home line (most common ESPN fallback behavior)
      homeLine = rawNum > 0 ? `+${rawNum}` : String(rawNum);
      awayLine = rawNum > 0 ? `-${Math.abs(rawNum)}` : `+${Math.abs(rawNum)}`;
    }
    const pA=picks.find(p=>p.gameId===g.id&&p.type==='spread'&&p.side===g.away.name);
    const pH=picks.find(p=>p.gameId===g.id&&p.type==='spread'&&p.side===g.home.name);
    const spreadPick=pA||pH;
    html+=`<div class="pick-row">
      <button class="pick-btn ${pA?'picked-spread':''} ${pA?.result||''} ${fin}" data-gid="${g.id}" data-type="spread" data-side="${g.away.name}" data-desc="${g.away.name} ${awayLine}" data-game="${g.away.name} ${g.away.score} @ ${g.home.name} ${g.home.score}" onclick="pickFromBtn(this,event)"${lockTip}>${g.away.name}<br><span style="color:var(--gold);font-size:11px">${awayLine}</span></button>
      <button class="pick-btn ${pH?'picked-spread':''} ${pH?.result||''} ${fin}" data-gid="${g.id}" data-type="spread" data-side="${g.home.name}" data-desc="${g.home.name} ${homeLine}" data-game="${g.away.name} ${g.away.score} @ ${g.home.name} ${g.home.score}" onclick="pickFromBtn(this,event)"${lockTip}>${g.home.name}<br><span style="color:var(--gold);font-size:11px">${homeLine}</span></button>
    </div>`;
    if(!locked && spreadPick){
      html += wagerSelectorHTML(g.id,'spread');
    }
  }
  if(g.odds.total){
    const ouLine=g.odds.total.replace('O/U ','').trim();
    const pO=picks.find(p=>p.gameId===g.id&&p.type==='total'&&p.side==='over');
    const pU=picks.find(p=>p.gameId===g.id&&p.type==='total'&&p.side==='under');
    const totalPick=pO||pU;
    html+=`<div class="pick-row">
      <button class="pick-btn ${pO?'picked-over':''} ${pO?.result||''} ${fin}" data-gid="${g.id}" data-type="total" data-side="over" data-desc="Over ${ouLine}" data-game="${g.away.name} @ ${g.home.name}" onclick="pickFromBtn(this,event)"${lockTip}>OVER<br><span style="color:var(--gold);font-size:11px">${ouLine}</span></button>
      <button class="pick-btn ${pU?'picked-under':''} ${pU?.result||''} ${fin}" data-gid="${g.id}" data-type="total" data-side="under" data-desc="Under ${ouLine}" data-game="${g.away.name} @ ${g.home.name}" onclick="pickFromBtn(this,event)"${lockTip}>UNDER<br><span style="color:var(--gold);font-size:11px">${ouLine}</span></button>
    </div>`;
    if(!locked && totalPick){
      html += wagerSelectorHTML(g.id,'total');
    }
  }
  return html+'</div>';
}
// pendingPickSel: tracks a highlighted-but-not-yet-placed selection per game+type
// key: `${gameId}_${type}`, value: {btn, gid, type, side, desc, game}
// pendingPickSel: tracks a highlighted-but-not-yet-placed selection per game+type
const pendingPickSel = {};

function pickFromBtn(btn, evt){
  (evt||window.event||{}).stopPropagation?.();
  const gid  = btn.dataset.gid;
  const type = btn.dataset.type;
  const selKey = gid + '_' + type;

  // If this exact button is already the pending selection -> deselect
  if(pendingPickSel[selKey] && pendingPickSel[selKey].btn === btn){
    btn.classList.remove('selecting');
    delete pendingPickSel[selKey];
    const wrap = btn.closest('.pick-section');
    const panel = wrap && wrap.querySelector('.prepick-panel[data-sel-key="'+selKey+'"]');
    if(panel) panel.remove();
    return;
  }

  // If there's already a placed pick for this game+type, toggle it off
  const alreadyPicked = picks.find(p=>p.gameId===gid&&p.type===type&&p.side===btn.dataset.side);
  if(alreadyPicked){
    makePick(gid, type, btn.dataset.side, btn.dataset.desc, btn.dataset.game);
    return;
  }

  // Clear any prior pending selection for same game+type
  if(pendingPickSel[selKey]){
    pendingPickSel[selKey].btn.classList.remove('selecting');
    const wrap2 = pendingPickSel[selKey].btn.closest('.pick-section');
    const old2 = wrap2 && wrap2.querySelector('.prepick-panel[data-sel-key="'+selKey+'"]');
    if(old2) old2.remove();
  }

  // Mark this button as selected
  btn.classList.add('selecting');
  const wager = DEFAULT_WAGER;
  const profit = calcPayout(wager, -110);
  const bankData = computeBankroll();
  const bal = typeof bankData === 'object' ? (bankData.balance||STARTING_BANKROLL) : (bankData||STARTING_BANKROLL);
  const maxBet = Math.floor(bal);
  const presets = [25, 50, 100, 250];

  pendingPickSel[selKey] = {btn, gid, type, side:btn.dataset.side, desc:btn.dataset.desc, game:btn.dataset.game, wager};

  // Build pre-pick panel with wager + parlay + place button
  const row = btn.closest('.pick-row');
  if(row){
    const panel = document.createElement('div');
    panel.className = 'prepick-panel';
    panel.dataset.selKey = selKey;
    panel.onclick = (e) => e.stopPropagation();
    panel.innerHTML = '<div class="wager-row">'
      + '<span class="wager-label">WAGER</span>'
      + '<div class="wager-presets">'
      + presets.map(amt =>
          '<div class="wager-preset '+(wager===amt?'active':'')+'" onclick="updatePendingWager(\''+selKey+'\','+amt+')">$'+amt+'</div>'
        ).join('')
      + '</div>'
      + '<input class="wager-custom" type="number" min="1" max="'+maxBet+'" value="'+wager+'" onchange="updatePendingWager(\''+selKey+'\',+this.value)" onclick="event.stopPropagation()">'
      + '</div>'
      + '<div class="wager-payout" id="prepick-payout-'+selKey+'">Win: <span class="win-amt">+$'+profit+'</span> &middot; Risk: $'+wager+'</div>'
      + '<div style="display:flex;gap:6px;margin-top:6px">'
      + '<button class="place-pick-btn" style="flex:2" onclick="placePendingPick(\''+selKey+'\')">&#10003;  PLACE PICK</button>'
      + '<button class="parlay-add-btn" style="flex:1;margin:0;width:auto" onclick="addPendingToParlay(\''+selKey+'\')">+ PARLAY</button>'
      + '</div>';
    row.insertAdjacentElement('afterend', panel);
  }
}

function updatePendingWager(selKey, amount){
  const sel = pendingPickSel[selKey];
  if(!sel) return;
  const bankData = computeBankroll();
  const bal = typeof bankData === 'object' ? (bankData.balance||STARTING_BANKROLL) : (bankData||STARTING_BANKROLL);
  const maxBet = Math.floor(bal);
  sel.wager = Math.max(1, Math.min(Math.round(amount), maxBet));
  const profit = calcPayout(sel.wager, -110);
  const panel = document.querySelector('.prepick-panel[data-sel-key="'+selKey+'"]');
  if(panel){
    panel.querySelectorAll('.wager-preset').forEach(function(el){
      el.classList.toggle('active', parseInt(el.textContent.replace('$',''))===sel.wager);
    });
    var input = panel.querySelector('.wager-custom');
    if(input) input.value = sel.wager;
    var payout = panel.querySelector('.wager-payout');
    if(payout) payout.innerHTML = 'Win: <span class="win-amt">+$'+profit+'</span> &middot; Risk: $'+sel.wager;
  }
}

function placePendingPick(selKey){
  const sel = pendingPickSel[selKey];
  if(!sel) return;
  sel.btn.classList.remove('selecting');
  const panel = document.querySelector('.prepick-panel[data-sel-key="'+selKey+'"]');
  if(panel) panel.remove();
  delete pendingPickSel[selKey];
  _pendingWager = sel.wager;
  makePick(sel.gid, sel.type, sel.side, sel.desc, sel.game);
  _pendingWager = null;
}
let _pendingWager = null;

function addPendingToParlay(selKey){
  const sel = pendingPickSel[selKey];
  if(!sel) return;
  addToParlay(sel.gid, sel.type, sel.side, sel.desc);
  // Update the parlay button to show it's been added
  const panel = document.querySelector('.prepick-panel[data-sel-key="'+selKey+'"]');
  if(panel){
    const pBtn = panel.querySelector('.parlay-add-btn');
    if(pBtn){ pBtn.textContent = '✓ IN PARLAY'; pBtn.style.borderColor='var(--green)'; pBtn.style.color='var(--green)'; pBtn.disabled=true; }
  }
}
function makePick(gameId,type,side,description,gameStr){
  if(!currentUser){ alert('Enter your name to make picks.'); return; }
  const g=allGames.find(x=>x.id===gameId);
  if(g&&!g.isPre) return; // silently block — UI already shows lock
  const idx=picks.findIndex(p=>p.gameId===gameId&&p.type===type&&p.side===side);
  if(idx!==-1){picks.splice(idx,1);savePicks();renderScores();updateRecordUI();renderPicksPanel();return;}
  picks=picks.filter(p=>!(p.gameId===gameId&&p.type===type));
  picks.push({gameId,type,side,description,gameStr,result:'pending',homeTeam:g?.home.name||'',awayTeam:g?.away.name||'',league:g?.leagueLabel||'',madeAt:Date.now(),wager:_pendingWager||DEFAULT_WAGER,odds:-110});
  savePicks();renderScores();updateRecordUI();renderPicksPanel();updateBankrollUI();
  // Subtle pick-made flash on the card
  requestAnimationFrame(()=>{
    const card=document.getElementById('card-'+gameId);
    if(card){card.classList.remove('pick-flash');void card.offsetWidth;card.classList.add('pick-flash');}
  });
}

function checkPickResults(){
  let changed=false;
  picks.forEach(pick=>{
    if(pick.result!=='pending') return;
    if(pick.type==='prop'){checkPropPickResults();return;}
    const g=allGames.find(x=>x.id===pick.gameId);
    if(!g||!g.isFinal) return;
    const hs=parseFloat(g.home.score),as2=parseFloat(g.away.score);
    if(isNaN(hs)||isNaN(as2)) return;
    if(pick.type==='spread'){
      const line=parseFloat(pick.description.split(' ').pop());
      const isHome=pick.side===g.home.name;
      const adj=isHome?(hs+line):(as2+line),opp=isHome?as2:hs;
      pick.result=Math.abs(adj-opp)<0.01?'push':adj>opp?'won':'lost';
    }else{
      const total=parseFloat(pick.description.replace(/over |under /i,''));
      const combined=hs+as2;
      pick.result=Math.abs(combined-total)<0.01?'push':pick.side==='over'?(combined>total?'won':'lost'):(combined<total?'won':'lost');
    }
    changed=true;
  });
  if(changed){ savePicks(); checkAchievements(); }
}

let activePickCat = 'all'; // 'all' | 'spread' | 'total' | 'prop'
function setPickCat(cat){
  activePickCat=cat;
  document.querySelectorAll('.pick-cat-tab').forEach(el=>el.classList.toggle('active',el.dataset.cat===cat));
  updateRecordUI();
  renderPicksPanel();
}

function filteredPicks(){
  if(activePickCat==='all') return picks;
  return picks.filter(p=>p.type===activePickCat);
}

function recordFor(type){
  const p = type==='all' ? picks : picks.filter(x=>x.type===type);
  return {
    w: p.filter(x=>x.result==='won').length,
    l: p.filter(x=>x.result==='lost').length,
    p: p.filter(x=>x.result==='push').length,
    n: p.filter(x=>x.result==='pending').length,
    total: p.length,
  };
}

function updateRecordUI(){
  // Header pill — overall W-L-Push
  const all = recordFor('all');
  const safe=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v;};
  safe('hdrW',all.w); safe('hdrL',all.l); safe('hdrP',all.p);

  // Render the always-visible 3-row breakdown table
  const bd = document.getElementById('recordBreakdown');
  if(!bd) return;

  const cats = [
    {type:'all',    label:'ALL'},
    {type:'spread', label:'SPREAD'},
    {type:'total',  label:'O/U'},
    {type:'prop',   label:'PROPS'},
  ];

  bd.innerHTML = cats.map(c=>{
    const r = recordFor(c.type);
    const isActive = activePickCat===c.type;
    if(r.total===0 && c.type!=='all') return ''; // hide empty rows
    return `<div class="rb-row" style="${isActive?'border-color:rgba(0,229,255,.4)':''}">
      <div class="rb-label${isActive?' active':''}">${c.label}</div>
      <div class="rb-cells">
        <div class="rb-cell"><div class="rb-cell-lbl">W</div><div class="rb-cell-val w">${r.w}</div></div>
        <div class="rb-cell"><div class="rb-cell-lbl">L</div><div class="rb-cell-val l">${r.l}</div></div>
        <div class="rb-cell"><div class="rb-cell-lbl">PUSH</div><div class="rb-cell-val p">${r.p}</div></div>
        <div class="rb-cell"><div class="rb-cell-lbl">PEND</div><div class="rb-cell-val n">${r.n}</div></div>
      </div>
    </div>`;
  }).join('');

  // Add Lock of the Day row if user has any locks
  const lockRec = getLockRecord();
  const todaysLock = getTodaysLock();
  if(lockRec.total > 0 || todaysLock) {
    const lockPending = picks.filter(p=>p.isLock && p.result==='pending').length;
    bd.innerHTML += `<div class="rb-row" style="border-color:rgba(255,165,2,.3);background:rgba(255,165,2,.03)">
      <div class="rb-label" style="color:var(--gold)">🔒 LOCK</div>
      <div class="rb-cells">
        <div class="rb-cell"><div class="rb-cell-lbl">W</div><div class="rb-cell-val w">${lockRec.w}</div></div>
        <div class="rb-cell"><div class="rb-cell-lbl">L</div><div class="rb-cell-val l">${lockRec.l}</div></div>
        <div class="rb-cell"><div class="rb-cell-lbl">PUSH</div><div class="rb-cell-val p">${lockRec.p}</div></div>
        <div class="rb-cell"><div class="rb-cell-lbl">PEND</div><div class="rb-cell-val n">${lockPending}</div></div>
      </div>
    </div>`;
  }
}

function typeLabel(type){
  if(type==='spread') return 'SPREAD';
  if(type==='total')  return 'O/U';
  if(type==='prop')   return 'PROP';
  return type.toUpperCase();
}

function renderPicksPanel(){
  const el=document.getElementById('panelPicksList');
  const fp=filteredPicks();
  const pending=fp.filter(p=>p.result==='pending');
  const settled=fp.filter(p=>p.result!=='pending');

  if(!fp.length){
    const msg=activePickCat==='all'
      ?'NO PICKS YET<br><br>Open any game to pick props,<br>spreads, or totals'
      :`NO ${typeLabel(activePickCat)} PICKS YET`;
    el.innerHTML=`<div class="no-picks">${msg}</div>`;
    return;
  }

  let html='';

  // ── Active / pending picks — can delete ──
  if(pending.length){
    html+=`<div class="picks-section-hdr">
      <span class="picks-section-title">Active</span>
      <div class="picks-section-line"></div>
      <span class="picks-section-cnt">${pending.length}</span>
    </div>`;
    html+=pending.sort((a,b)=>b.madeAt-a.madeAt).map(p=>{
      const idx=picks.findIndex(x=>x.gameId===p.gameId&&x.type===p.type&&x.side===p.side);
      const pKey=`${p.gameId}_${p.type}_${p.side}`;
      return `<div class="pick-item">
        <div class="pi-top">
          <div style="display:flex;align-items:center;gap:6px">
            <span class="pi-type-tag">${typeLabel(p.type)}</span>
            <span class="pi-league">${p.league||''}</span>
            ${p.type==='parlay'?`<span class="parlay-tag">PARLAY</span>`:''}
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            <span class="pi-badge pending">PENDING</span>
            ${lockBadgeHTML(p)}
            ${p.type==='parlay'?`<button class="pi-share-btn" onclick="manualSettleParlay(${idx})" title="Force settle this parlay" style="font-size:9px;padding:2px 5px">🔄</button>`:''}
            <button class="pi-share-btn" onclick="sharePickCard({...picks[${idx}],name:currentUser?.name})" title="Share pick">📤</button>
            <button class="pi-del" onclick="deletePick(${idx})" title="Remove pick">✕</button>
          </div>
        </div>
        <div class="pi-pick">${p.description}</div>
        ${p.wager?`<div class="pi-wager">💰 $${p.wager} to win +$${calcPayout(p.wager,p.odds||-110)}</div>`:''}
        <div class="pi-score">${p.gameStr||''}</div>
        ${p.type!=='parlay'?confidenceHTML(pKey,p.confidence||0):''}
        ${p.type!=='parlay'?lockBtnHTML(p):''}
        ${p.type!=='parlay'?pickCommentHTML(p):''}
      </div>`;
    }).join('');
  }

  // ── Settled picks — locked, no delete, result shown ──
  if(settled.length){
    html+=`<div class="picks-section-hdr" style="margin-top:${pending.length?'6px':'0'}">
      <span class="picks-section-title">Settled</span>
      <div class="picks-section-line"></div>
      <span class="picks-section-cnt">${settled.length}</span>
    </div>`;
    html+=settled.sort((a,b)=>b.madeAt-a.madeAt).map(p=>{
      return `<div class="pick-item pick-item-settled pick-settled-${p.result}">
        <div class="pi-top">
          <div style="display:flex;align-items:center;gap:6px">
            <span class="pi-type-tag">${typeLabel(p.type)}</span>
            <span class="pi-league">${p.league||''}</span>
            ${p.type==='parlay'?`<span class="parlay-tag">PARLAY</span>`:''}
          </div>
          <span class="pi-badge ${p.result}">${p.result.toUpperCase()}</span>
          ${lockBadgeHTML(p)}
        </div>
        <div class="pi-pick">${p.description}</div>
        ${p.wager?(()=>{
          const profit=calcPayout(p.wager,p.odds||-110);
          if(p.result==='won') return `<div class="pi-pnl pos">+$${profit}</div>`;
          if(p.result==='lost') return `<div class="pi-pnl neg">-$${p.wager}</div>`;
          return `<div class="pi-wager">💰 $${p.wager}</div>`;
        })():''}
        <div class="pi-score">${p.gameStr||''}</div>
        ${p.confidence?`<div style="font-size:11px;color:var(--gold)">${'★'.repeat(p.confidence)}${'☆'.repeat(5-p.confidence)}</div>`:''}
        ${p.comment?`<div class="pick-comment-display">${p.comment}</div>`:''}
        <div class="pi-locked-note">🔒 Settled — view full history in History tab</div>
      </div>`;
    }).join('');
  }

  el.innerHTML=html;
}


function deletePick(idx){
  // Only allow deleting pending picks
  const pick = picks[idx];
  if(!pick||pick.result!=='pending') return;
  deletePickFromServer(pick); // async fire-and-forget
  picks.splice(idx,1);
  savePicks();renderPicksPanel();updateRecordUI();renderScores();
}
function clearAllPicks(){
  // Only clears pending picks; completed are preserved in history
  const hadPending=picks.some(p=>p.result==='pending');
  if(!hadPending) return;
  showConfirm('Remove pending picks?','Settled picks stay in History — only pending picks will be removed.',()=>{
    picks=picks.filter(p=>p.result!=='pending');
    savePicks();renderPicksPanel();updateRecordUI();renderScores();
  });
}
// History filter state
let histFilterType = 'all';
let histFilterResult = 'all';
let histFilterLeague = 'all';
let histSortBy = 'date';
let histSearch = '';

function renderHistoryView(){
  const el=document.getElementById('historyContent');
  const allSettled=picks.filter(p=>p.result!=='pending');
  // Apply filters
  let settled = allSettled.filter(p=>{
    if(histFilterType!=='all' && p.type!==histFilterType) return false;
    if(histFilterResult!=='all' && p.result!==histFilterResult) return false;
    if(histFilterLeague!=='all' && (p.league||'Other')!==histFilterLeague) return false;
    if(histSearch && !p.description?.toLowerCase().includes(histSearch.toLowerCase()) &&
       !p.gameStr?.toLowerCase().includes(histSearch.toLowerCase())) return false;
    return true;
  });
  if(histSortBy==='pnl') settled.sort((a,b)=>{
    const pnl=p=>{if(p.result==='won') return calcPayout(p.wager||50,p.odds||-110); if(p.result==='lost') return -(p.wager||50); return 0;};
    return pnl(b)-pnl(a);
  });
  else settled.sort((a,b)=>b.madeAt-a.madeAt);

  // Build league list for filter
  const allLeagues = [...new Set(allSettled.map(p=>p.league||'Other'))].sort();

  // Filter bar HTML
  const filterBar = `<div class="hist-filter-bar">
    <input class="hist-search" type="text" placeholder="🔍 Search picks…" value="${histSearch}"
      oninput="histSearch=this.value;renderHistoryView()" />
    <div class="hist-filter-row">
      <select class="hist-filter-sel" onchange="histFilterType=this.value;renderHistoryView()">
        <option value="all" ${histFilterType==='all'?'selected':''}>All Types</option>
        <option value="spread" ${histFilterType==='spread'?'selected':''}>Spread</option>
        <option value="total" ${histFilterType==='total'?'selected':''}>O/U</option>
        <option value="prop" ${histFilterType==='prop'?'selected':''}>Props</option>
        <option value="parlay" ${histFilterType==='parlay'?'selected':''}>Parlay</option>
      </select>
      <select class="hist-filter-sel" onchange="histFilterResult=this.value;renderHistoryView()">
        <option value="all" ${histFilterResult==='all'?'selected':''}>All Results</option>
        <option value="won" ${histFilterResult==='won'?'selected':''}>Wins</option>
        <option value="lost" ${histFilterResult==='lost'?'selected':''}>Losses</option>
        <option value="push" ${histFilterResult==='push'?'selected':''}>Push</option>
      </select>
      <select class="hist-filter-sel" onchange="histFilterLeague=this.value;renderHistoryView()">
        <option value="all">All Leagues</option>
        ${allLeagues.map(l=>`<option value="${l}" ${histFilterLeague===l?'selected':''}>${l}</option>`).join('')}
      </select>
      <select class="hist-filter-sel" onchange="histSortBy=this.value;renderHistoryView()">
        <option value="date" ${histSortBy==='date'?'selected':''}>By Date</option>
        <option value="pnl" ${histSortBy==='pnl'?'selected':''}>By P&L</option>
      </select>
    </div>
  </div>`;

  if(!settled.length){
    el.innerHTML = filterBar + `<div class="hist-empty">
      <div style="font-size:32px;margin-bottom:16px">${allSettled.length?'🔍':'📋'}</div>
      ${allSettled.length?'NO PICKS MATCH YOUR FILTERS':'NO PICK HISTORY YET'}
      <small>${allSettled.length?'Try changing or clearing your filters':'Make picks on games \u2014 once they go final they\u2019ll appear here'}</small>
    </div>`;
    return;
  }

  // Totals per type
  const types=['spread','total','prop'];
  const tally=(arr)=>({
    w:arr.filter(p=>p.result==='won').length,
    l:arr.filter(p=>p.result==='lost').length,
    p:arr.filter(p=>p.result==='push').length,
  });
  const all=tally(settled);
  const byType={spread:tally(settled.filter(p=>p.type==='spread')), total:tally(settled.filter(p=>p.type==='total')), prop:tally(settled.filter(p=>p.type==='prop'))};
  const decided=all.w+all.l;
  const pct=decided>0?Math.round(all.w/decided*100):0;

  // Group settled by date picked
  const byDate={};
  settled.forEach(p=>{
    const d=new Date(p.madeAt);
    const ds=`${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
    if(!byDate[ds]) byDate[ds]=[];
    byDate[ds].push(p);
  });
  const sortedDates=Object.keys(byDate).sort((a,b)=>b.localeCompare(a));

  let html=filterBar+`
  <div class="hist-page-hdr">
    <div>
      <div class="hist-page-title">Pick History</div>
      <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--muted);margin-top:4px;letter-spacing:1px">${settled.length} settled pick${settled.length!==1?'s':''}</div>
    </div>
    <div class="hist-summary">
      <div class="hist-stat"><div class="hist-stat-val w">${all.w}</div><div class="hist-stat-lbl">Wins</div></div>
      <div class="hist-stat"><div class="hist-stat-val l">${all.l}</div><div class="hist-stat-lbl">Losses</div></div>
      <div class="hist-stat"><div class="hist-stat-val p">${all.p}</div><div class="hist-stat-lbl">Push</div></div>
      <div class="hist-stat" style="border-color:rgba(0,229,255,.3)"><div class="hist-pct">${pct}%</div><div class="hist-stat-lbl">Win Rate</div></div>
    </div>
  </div>

  <div class="hist-type-summary">
    <div class="hist-type-row">
      <span class="hist-type-label">Spread</span>
      <span class="hist-type-rec"><span class="w">${byType.spread.w}W</span> <span class="l">${byType.spread.l}L</span>${byType.spread.p?' <span class="p">'+byType.spread.p+'P</span>':''}</span>
      <div class="hist-type-bar-wrap"><div class="hist-type-bar" style="width:${byType.spread.w+byType.spread.l>0?Math.round(byType.spread.w/(byType.spread.w+byType.spread.l)*100):0}%"></div></div>
    </div>
    <div class="hist-type-row">
      <span class="hist-type-label">O/U</span>
      <span class="hist-type-rec"><span class="w">${byType.total.w}W</span> <span class="l">${byType.total.l}L</span>${byType.total.p?' <span class="p">'+byType.total.p+'P</span>':''}</span>
      <div class="hist-type-bar-wrap"><div class="hist-type-bar" style="width:${byType.total.w+byType.total.l>0?Math.round(byType.total.w/(byType.total.w+byType.total.l)*100):0}%"></div></div>
    </div>
    <div class="hist-type-row">
      <span class="hist-type-label">Props</span>
      <span class="hist-type-rec"><span class="w">${byType.prop.w}W</span> <span class="l">${byType.prop.l}L</span>${byType.prop.p?' <span class="p">'+byType.prop.p+'P</span>':''}</span>
      <div class="hist-type-bar-wrap"><div class="hist-type-bar" style="width:${byType.prop.w+byType.prop.l>0?Math.round(byType.prop.w/(byType.prop.w+byType.prop.l)*100):0}%"></div></div>
    </div>
  </div>`;

  sortedDates.forEach(ds=>{
    const group=byDate[ds];
    const g=tally(group);
    const decided2=g.w+g.l;
    const dateObj=new Date(+ds.slice(0,4),+ds.slice(4,6)-1,+ds.slice(6,8));
    const dateLabel=dateObj.toLocaleDateString([],{weekday:'long',month:'long',day:'numeric',year:'numeric'});

    html+=`<div class="hist-date-group">
      <div class="hist-date-hdr">
        <div class="hist-date-label">${dateLabel}</div>
        <div class="hist-date-line"></div>
        <div class="hist-date-record">
          <span class="w">${g.w}W</span>&nbsp;<span class="l">${g.l}L</span>${g.p?`&nbsp;<span class="p">${g.p}P</span>`:''}&nbsp;
          ${decided2>0?`<span style="color:var(--accent)">${Math.round(g.w/decided2*100)}%</span>`:''}
        </div>
      </div>
      <div class="hist-grid">`;

    group.sort((a,b)=>b.madeAt-a.madeAt).forEach(p=>{
      const resultIcon=p.result==='won'?'✓':p.result==='lost'?'✕':'↔';
      const pnlVal = p.result==='won'&&p.wager ? `+$${calcPayout(p.wager,p.odds||-110)}` : p.result==='lost'&&p.wager ? `-$${p.wager}` : '';
      const pnlColor = p.result==='won'?'#2ed573':p.result==='lost'?'#ff4757':'';
      html+=`<div class="hist-card ${p.result}">
        <div class="hist-card-top">
          <div style="display:flex;align-items:center;gap:6px">
            <span class="hist-type-tag">${typeLabel(p.type)}</span>
            <span style="font-family:'DM Mono',monospace;font-size:9px;color:var(--dim)">${p.league||''}</span>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            ${pnlVal?`<span style="font-family:'DM Mono',monospace;font-size:10px;font-weight:700;color:${pnlColor}">${pnlVal}</span>`:''}
            <span class="hist-result-badge ${p.result}">${resultIcon} ${p.result.toUpperCase()}</span>
          </div>
        </div>
        <div class="hist-pick-desc">${p.description}</div>
        <div class="hist-game-str">${p.gameStr||''}</div>
        ${p.comment?`<div style="font-size:10px;color:var(--muted);font-style:italic;margin-top:4px">"${p.comment}"</div>`:''}
        ${typeof settlementAuditHTML==='function'?settlementAuditHTML(p):''}
      </div>`;
    });

    html+=`</div></div>`;
  });

  el.innerHTML=html;
}

function openPanel(){checkPickResults();checkPropPickResults();checkParlayResults();renderPicksPanel();updateRecordUI();document.getElementById('picksPanel').classList.add('open');document.getElementById('panelOverlay').classList.add('open');}
function closePanel(){document.getElementById('picksPanel').classList.remove('open');document.getElementById('panelOverlay').classList.remove('open');}

// ═══════════════════════════════════════════════════════
// KEYBOARD — close modal on Escape
// ═══════════════════════════════════════════════════════
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
    if(openGameId) closeModal();
    else closePanel();
  }
});

// ═══════════════════════════════════════════════════════
// CALENDAR
// ═══════════════════════════════════════════════════════
function renderCalendar(){
  const y=calMonth.getFullYear(),m=calMonth.getMonth();
  document.getElementById('monthTitle').textContent=calMonth.toLocaleDateString([],{month:'long',year:'numeric'});
  const firstDow=new Date(y,m,1).getDay(),daysInM=new Date(y,m+1,0).getDate(),today=todayStr();
  let html=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=>`<div class="cal-dow">${d}</div>`).join('');
  for(let i=0;i<firstDow;i++) html+=`<div class="cal-cell empty"></div>`;
  for(let day=1;day<=daysInM;day++){
    const ds=`${y}${pad(m+1)}${pad(day)}`;
    const isToday=ds===today,isSel=ds===selDate;
    const games=cache[ds]||[],cnt=games.length;
    const dm={};games.forEach(g=>{dm[g.dot]=true;});
    const dots=Object.keys(dm).map(c=>`<div class="cal-dot dot-${c}"></div>`).join('');
    html+=`<div class="cal-cell${isToday?' tod':''}${isSel?' sel':''}" data-ds="${ds}" onclick="calClick('${ds}')">
      <div class="cal-num">${day}</div><div class="cal-dots">${dots}</div>
      ${cnt>0?`<div class="cal-gcnt">${cnt} games</div>`:''}
    </div>`;
  }
  document.getElementById('calGrid').innerHTML=html;
  const uncached=[];
  for(let day=1;day<=daysInM;day++){const ds=`${y}${pad(m+1)}${pad(day)}`;if(!cache[ds])uncached.push(ds);}
  uncached.sort((a,b)=>Math.abs(a.localeCompare(todayStr()))-Math.abs(b.localeCompare(todayStr())));
  enqueuePrefetch(uncached);
}
function calClick(ds){selDate=ds;document.querySelectorAll('.cal-cell.sel').forEach(c=>c.classList.remove('sel'));document.querySelector(`[data-ds="${ds}"]`)?.classList.add('sel');setMode('scores');selectDate(ds);}
function shiftMonth(dir){calMonth.setMonth(calMonth.getMonth()+dir);renderCalendar();}
function goToday(){calMonth=new Date();renderCalendar();}

// ═══════════════════════════════════════════════════════
// LEADERBOARD
// ═══════════════════════════════════════════════════════
async function renderLegacyLeaderboardView(){
  const el=document.getElementById('leaderboardContent');
  el.innerHTML=`<div class="lb-empty"><div style="font-size:28px;margin-bottom:12px">⏳</div>LOADING LEADERBOARD…</div>`;

  const entries=await fetchLeaderboard();

  if(!entries.length){
    el.innerHTML=`<div class="lb-empty">
      <div style="font-size:32px;margin-bottom:16px">🏆</div>
      NO PICKS YET
      <small>Be the first! Make some picks on today's games.</small>
    </div>`;
    return;
  }

  // Sort: by win % (min 1 decided pick), then total picks
  entries.sort((a,b)=>{
    const aPct=(a.w+a.l)>0?a.w/(a.w+a.l):0;
    const bPct=(b.w+b.l)>0?b.w/(b.w+b.l):0;
    if(Math.abs(aPct-bPct)>0.001) return bPct-aPct;
    return (b.w+b.l+b.p)-(a.w+a.l+a.p); // tiebreak: more picks
  });

  const rankIcon=(i)=>i===0?'🥇':i===1?'🥈':i===2?'🥉':`${i+1}`;
  const rankClass=(i)=>i===0?'gold':i===1?'silver':i===2?'bronze':'';
  const meId=currentUser?.id;

  // Compute streaks from recentPicks
  function getStreak(entry){
    const rp=(entry.recentPicks||[]).filter(p=>p.result!=='push').reverse();
    if(!rp.length) return null;
    const last=rp[0].result;
    let count=0;
    for(const p of rp){ if(p.result===last) count++; else break; }
    return {type:last,count};
  }

  let html=`<div class="lb-hdr">
    <div>
      <div class="lb-title" style="display:flex;align-items:center;gap:8px"><img src="assets/sharppick-mark.png" alt="SharpPick" width="20" height="20" style="border-radius:6px;box-shadow:0 0 0 1px rgba(0,229,255,.14)"/>Leaderboard</div>
      <div class="lb-subtitle">${entries.length} PICKER${entries.length!==1?'S':''} · RANKED BY WIN %</div>
    </div>
    <button class="lb-refresh" onclick="renderLeaderboardView()">↻ REFRESH</button>
  </div>
  <div class="lb-table-wrap">
  <table class="lb-table">
    <thead class="lb-head">
      <tr>
        <th style="width:40px">#</th>
        <th>PICKER</th>
        <th class="num">W</th>
        <th class="num">L</th>
        <th class="num">P</th>
        <th class="num">WIN %</th>
        <th class="num" title="Weighted by confidence stars">★ WTD</th>
        <th class="num" title="Fake money bankroll">💰</th>
        <th class="num" title="Lock of the Day record">🔒</th>
        <th class="lb-bar-cell"></th>
        <th class="num">STREAK</th>
      </tr>
    </thead>
    <tbody>`;

  entries.forEach((entry,i)=>{
    const isMe=entry.id===meId;
    const decided=entry.w+entry.l;
    const pct=decided>0?Math.round(entry.w/decided*100):0;
    const barW=decided>0?Math.round(entry.w/decided*100):0;
    const streak=getStreak(entry);
    const streakHtml=streak&&streak.count>=2
      ?`<span class="lb-streak ${streak.type==='won'?'hot':'cold'}">${streak.type==='won'?'🔥':'🥶'} ${streak.count}</span>`
      :'<span style="color:var(--dim)">—</span>';
    const rowClass=`lb-row ${isMe?'me':''} ${i<3?'rank-'+(i+1):''}`.trim();

    html+=`<tr class="${rowClass}" onclick="openProfile(${JSON.stringify(entry).replace(/"/g,'&quot;').replace(/'/g,'&#39;')})">
      <td class="lb-cell lb-rank ${rankClass(i)}">${rankIcon(i)}</td>
      <td class="lb-cell">
        <div class="lb-name-cell">
          <div class="lb-avatar ${isMe?'me':''}">${entry.name[0].toUpperCase()}</div>
          <div>
            <div class="lb-username">${entry.name}${isMe?'<span class="lb-you"> YOU</span>':''}</div>
            <div class="lb-last-pick">${entry.total||0} pick${(entry.total||0)!==1?'s':''}</div>
          </div>
        </div>
      </td>
      <td class="lb-cell num lb-w">${entry.w||0}</td>
      <td class="lb-cell num lb-l">${entry.l||0}</td>
      <td class="lb-cell num lb-p">${entry.p||0}</td>
      <td class="lb-cell num"><span class="lb-pct">${decided>0?pct+'%':'—'}</span></td>
      <td class="lb-cell num" style="color:var(--gold);font-size:11px;font-family:'DM Mono',monospace">
        ${isMe && decided>0 ? Math.round(weightedWinPct(picks)*100)+'%' : decided>0 ? pct+'%' : '—'}
      </td>
      <td class="lb-cell num">
        ${(()=>{
          const b=isMe?computeBankroll():(entry.bankroll||1000);
          const d=b-1000;
          const cls=d>0?'pos':d<0?'neg':'even';
          return `<span class="lb-money ${cls}">$${b.toLocaleString()}</span>`;
        })()}
      </td>
      <td class="lb-cell lb-lock-col">
        ${(()=>{
          const lw = isMe ? getLockRecord().w : (entry.lockW||0);
          const ll = isMe ? getLockRecord().l : (entry.lockL||0);
          return (lw+ll) > 0 ? `${lw}-${ll}` : '<span style="color:var(--dim)">—</span>';
        })()}
      </td>
      <td class="lb-cell lb-bar-cell">
        <div class="lb-bar-wrap"><div class="lb-bar" style="width:${barW}%"></div></div>
      </td>
      <td class="lb-cell num">${streakHtml}</td>
    </tr>`;
  });

  html+=`</tbody></table></div>`;
  el.innerHTML=html;

  // Load head-to-head records after rendering
  if(currentUser){
    computeH2H(currentUser.id).then(h2hData=>{
      renderH2HSection(h2hData);
    });
  }
}

// ═══════════════════════════════════════════════════════
// SHARP RATING LEADERBOARD (Verified / Provisional / Specialists)
// ═══════════════════════════════════════════════════════
let LB_SHARP_TAB = 'verified'; // 'verified' | 'provisional' | 'specialists'
let LB_SPECIALIST_SPORT = 'ALL';

function tierLabelFromRating(r, verified){
  if(r==null || !isFinite(r)) return '—';
  const v = Number(r);
  if(!verified) return 'PROVISIONAL';
  if(v>=85) return 'ELITE';
  if(v>=70) return 'PRO';
  if(v>=55) return 'SHARP';
  if(v>=40) return 'SOLID';
  return 'ROOKIE';
}

function fmt1(x){
  if(x==null || !isFinite(x)) return '—';
  return (Math.round(Number(x)*10)/10).toFixed(1);
}

async function fetchNameMap(){
  try{
    const rows = await sbSelect('leaderboard','select=user_id,name&limit=1000');
    const m = {};
    (rows||[]).forEach(r=>{ if(r?.user_id) m[r.user_id]=r.name||('User '+String(r.user_id).slice(0,6)); });
    return m;
  }catch(e){
    return {};
  }
}

async function fetchSharpLeaderboard(tab){
  const limit_n = 100;
  try{
    if(tab==='verified'){
      return await sbRpc('get_leaderboard_90',{limit_n});
    }
    if(tab==='provisional' || tab==='specialists'){
      return await sbRpc('get_leaderboard_90_provisional',{limit_n});
    }
  }catch(e){
    // If RPC isn't set up yet, return empty and let UI show guidance
    return [];
  }
  return [];
}

async function fetchMyRatings(){
  if(!currentUser) return null;
  try{
    const rows = await sbSelect('user_ratings', `select=*&user_id=eq.${currentUser.id}&order=calculated_at.desc&limit=1`);
    return rows && rows[0] ? rows[0] : null;
  }catch(e){
    return null;
  }
}

// ─────────────────────────────────────────────────────────────
// SHARP RATING: Movers, Public Profiles, Rating History
// ─────────────────────────────────────────────────────────────
function escapeAttr(s){
  return String(s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

async function fetchTopMoversToday(){
  try{
    const limit_n = 6;
    return await sbRpc('get_top_movers_today', { limit_n });
  }catch(e){
    return [];
  }
}

async function fetchRatingHistory(userId, days=30){
  try{
    return await sbRpc('get_rating_history', { p_user_id: userId, days });
  }catch(e){
    return [];
  }
}

async function fetchPublicUserStats(userId){
  try{
    const rows = await sbRpc('get_public_user_stats', { p_user_id: userId });
    // Supabase RPC may return object or array depending on helper; normalize to first row
    if(Array.isArray(rows)) return rows[0]||null;
    return rows||null;
  }catch(e){
    return null;
  }
}

async function fetchRecentPicks(userId, limit_n=10){
  try{
    return await sbRpc('get_public_recent_picks', { p_user_id: userId, limit_n });
  }catch(e){
    return [];
  }
}

function sparklineSVG(points, w=220, h=46){
  const vals = (points||[]).map(p=>Number(p.singles_overall_90)).filter(v=>isFinite(v));
  if(vals.length<2){
    return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">
      <rect x="0" y="0" width="${w}" height="${h}" rx="10" fill="rgba(255,255,255,.04)"></rect>
      <text x="${w/2}" y="${h/2+4}" text-anchor="middle" font-size="11" fill="rgba(255,255,255,.35)">No history yet</text>
    </svg>`;
  }
  const min=Math.min(...vals), max=Math.max(...vals);
  const pad=8;
  const nx = (i)=> pad + (i*(w-2*pad)/(vals.length-1));
  const ny = (v)=> {
    const t = (max===min)?0.5:((v-min)/(max-min));
    return (h-pad) - t*(h-2*pad);
  };
  const d = vals.map((v,i)=> `${i===0?'M':'L'} ${nx(i).toFixed(2)} ${ny(v).toFixed(2)}`).join(' ');
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">
    <rect x="0" y="0" width="${w}" height="${h}" rx="10" fill="rgba(255,255,255,.04)"></rect>
    <path d="${d}" fill="none" stroke="rgba(0,229,255,.9)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path>
  </svg>`;
}

function miniStat(label, value){
  return `<div class="sp-stat">
    <div class="sp-stat-label">${label}</div>
    <div class="sp-stat-val">${value}</div>
  </div>`;
}

function formatPct(x){
  if(x==null || !isFinite(x)) return '—';
  return `${(Number(x)*100).toFixed(1)}%`;
}
function formatUnits(x){
  if(x==null || !isFinite(x)) return '—';
  const v = Number(x);
  const s = (Math.round(v*100)/100).toFixed(2);
  return (v>0?'+':'')+s;
}

function leaguePill(league){
  const lg = String(league||'').toUpperCase().trim();
  if(!lg) return '';
  const cls = 'sp-pill sp-pill-'+lg.replace(/[^A-Z0-9]+/g,'');
  return `<span class="${cls}">${lg}</span>`;
}

function bestSportsBadges(bySport, topN=3){
  try{
    const pairs = Object.entries(bySport||{}).map(([k,v])=>[k,Number(v)]).filter(([,v])=>isFinite(v));
    pairs.sort((a,b)=>b[1]-a[1]);
    return pairs.slice(0,topN).map(([k,v])=>`<span class="sp-pill sp-pill-sport">${escapeAttr(k)} <span class="sp-pill-sub">${fmt1(v)}</span></span>`).join(' ');
  }catch(e){ return ''; }
}

function currentStreakFromRecent(recent){
  const settled = (recent||[]).filter(r=>r && r.result && ['win','loss'].includes(String(r.result).toLowerCase()));
  if(!settled.length) return {label:'—', kind:'none'};
  const first = String(settled[0].result).toLowerCase();
  let n=0;
  for(const r of settled){
    const rr = String(r.result).toLowerCase();
    if(rr===first) n++; else break;
  }
  return {label: (first==='win'?'W':'L')+n, kind:first};
}

function avgOddsFromRecent(recent){
  const nums = (recent||[]).map(r=>Number(r?.odds)).filter(v=>isFinite(v) && v!==0);
  if(!nums.length) return null;
  return Math.round(nums.reduce((a,b)=>a+b,0)/nums.length);
}


async function openPublicProfile(userId, name){
  const overlay = document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.66);z-index:9999;display:flex;align-items:flex-end;justify-content:center;padding:18px;';
  overlay.onclick=(e)=>{ if(e.target===overlay) overlay.remove(); };

  const card = document.createElement('div');
  card.style.cssText='width:min(760px,100%);background:var(--panel);border:1px solid rgba(255,255,255,.10);border-radius:18px;padding:14px 14px 12px;box-shadow:0 18px 60px rgba(0,0,0,.55);';

  card.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
      <div style="display:flex;align-items:center;gap:12px">
        <div class="lb-avatar" style="width:40px;height:40px;border-radius:14px;font-weight:900">${String(name||'U')[0].toUpperCase()}</div>
        <div>
          <div style="font-weight:900;font-size:16px;letter-spacing:.2px">${escapeAttr(name||'User')}</div>
          <div style="color:var(--dim);font-size:11px;letter-spacing:2px;text-transform:uppercase">Public Profile</div>
        </div>
      </div>
      <button class="lb-refresh" onclick="this.closest('.modal-overlay').remove()">✕</button>
    </div>

    <div id="spProfileBody" style="margin-top:12px">
      <div class="lb-empty" style="padding:22px 14px"><div style="font-size:26px;margin-bottom:10px">⏳</div>LOADING STATS…</div>
    </div>
  `;
  overlay.appendChild(card);
  document.body.appendChild(overlay);

  const [stats, history, recent] = await Promise.all([
    fetchPublicUserStats(userId),
    fetchRatingHistory(userId, 30),
    fetchRecentPicks(userId, 10)
  ]);

  const body = card.querySelector('#spProfileBody');

  if(!stats){
    body.innerHTML = `<div class="lb-empty" style="padding:22px 14px"><div style="font-size:26px;margin-bottom:10px">⚠️</div>PROFILE NOT AVAILABLE<small>This user may not have public stats yet.</small></div>`;
    return;
  }

  const tier = tierLabelFromRating(stats.singles_overall_90, stats.singles_verified_90);
  const spark = sparklineSVG(history||[], 240, 52);

  const topSport = (()=>{
    try{
      const by = stats.singles_by_sport_90 || {};
      const pairs = Object.entries(by).map(([k,v])=>[k,Number(v)]).filter(([,v])=>isFinite(v)).sort((a,b)=>b[1]-a[1]);
      return pairs.length ? `${pairs[0][0]} ${fmt1(pairs[0][1])}` : '—';
    }catch{return '—'}
  })();

  const settled90 = stats.singles_picks_90 || 0;
  const progPct = Math.max(0, Math.min(100, (settled90/20)*100));

  const bestSports = bestSportsBadges(stats.singles_by_sport_90, 3);
  const streak = currentStreakFromRecent(recent||[]);
  const avgOdds = avgOddsFromRecent(recent||[]);

  body.innerHTML = `
    <div class="sp-card" style="margin-top:8px">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <div>
          <div style="color:var(--dim);font-size:11px;letter-spacing:2px;text-transform:uppercase">Sharp Rating (90D)</div>
          <div style="margin-top:6px;display:flex;align-items:baseline;gap:10px">
            <div style="font-size:30px;font-weight:1000;color:var(--cyan)">${fmt1(stats.singles_overall_90)}</div>
            <span style="font-size:11px;padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10)">${stats.singles_verified_90?'VERIFIED':'PROVISIONAL'}</span>
            <span style="color:var(--dim);font-size:11px">${tier}</span>
          </div>
          <div style="margin-top:8px;color:var(--dim);font-size:11px">Top sport: <span style="color:var(--gold)">${escapeAttr(topSport)}</span></div>
          ${bestSports?`<div class="sp-badges-row" style="margin-top:10px">${bestSports}</div>`:''}
          <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
            <span class="sp-pill sp-pill-metric">Streak <span class="sp-pill-sub">${escapeAttr(streak.label)}</span></span>
            <span class="sp-pill sp-pill-metric">Avg Odds <span class="sp-pill-sub">${avgOdds==null?'—':(avgOdds>0?`+${avgOdds}`:`${avgOdds}`)}</span></span>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end">
          ${spark}
          <div style="color:var(--dim);font-size:11px">30-day trend</div>
        </div>
      </div>

      <div style="margin-top:14px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <div style="color:var(--dim);font-size:11px;letter-spacing:2px;text-transform:uppercase">Unlock Verified</div>
          <div style="color:var(--text);font-size:12px;font-weight:800">${settled90}/20</div>
        </div>
        <div style="height:10px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden;border:1px solid rgba(255,255,255,.08)">
          <div style="height:100%;width:${progPct}%;background:rgba(0,229,255,.75)"></div>
        </div>
        <div style="margin-top:6px;color:var(--dim);font-size:11px">${Math.max(0,20-settled90)} to unlock Verified leaderboard</div>
      </div>
    </div>

    <div class="sp-grid">
      ${miniStat('Current Streak', escapeAttr(streak.label))}
      ${miniStat('Avg Odds (Last 10)', avgOdds==null?'—':(avgOdds>0?`+${avgOdds}`:`${avgOdds}`))}
      ${miniStat('90D Singles', `${stats.singles_wins_90||0}-${stats.singles_losses_90||0}-${stats.singles_pushes_90||0}`)}
      ${miniStat('90D Win Rate', formatPct(stats.singles_win_rate_90))}
      ${miniStat('90D ROI', formatPct(stats.singles_roi_90))}
      ${miniStat('90D Units', formatUnits(stats.singles_units_90))}
      ${miniStat('All-time Singles', `${stats.singles_wins_all_time||0}-${stats.singles_losses_all_time||0}-${stats.singles_pushes_all_time||0}`)}
      ${miniStat('All-time ROI', formatPct(stats.singles_roi_all_time))}
      ${miniStat('90D Parlays', `${stats.parlays_wins_90||0}-${stats.parlays_losses_90||0}-${stats.parlays_pushes_90||0}`)}
      ${miniStat('90D Parlay ROI', formatPct(stats.parlays_roi_90))}
    </div>

    <div class="sp-card" style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div style="color:var(--dim);font-size:11px;letter-spacing:2px;text-transform:uppercase">Recent Picks</div>
        <div style="color:var(--dim);font-size:11px">Public · last ${Math.min(10,(recent||[]).length)}</div>
      </div>
      <div style="margin-top:10px;display:flex;flex-direction:column;gap:10px">
        ${(recent||[]).map(r=>{
          const res = (r.result||'pending').toUpperCase();
          const pill = res==='WIN'?'rgba(46,213,115,.16)':res==='LOSS'?'rgba(255,71,87,.16)':res==='PUSH'?'rgba(255,209,102,.14)':'rgba(255,255,255,.06)';
          const brd = res==='WIN'?'rgba(46,213,115,.22)':res==='LOSS'?'rgba(255,71,87,.22)':res==='PUSH'?'rgba(255,209,102,.18)':'rgba(255,255,255,.10)';
          return `<div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
            <div style="min-width:0">
              <div style="font-weight:800;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeAttr(r.description||'Pick')}</div>
              <div style="color:var(--dim);font-size:11px;margin-top:3px">${escapeAttr(r.league||'')} · Odds ${r.odds==null?'—':r.odds}</div>
            </div>
            <div style="text-align:right">
              <div style="display:inline-block;font-size:11px;padding:6px 10px;border-radius:999px;background:${pill};border:1px solid ${brd}">${res}</div>
            </div>
          </div>`;
        }).join('') || `<div style="color:var(--dim);font-size:12px">No public picks yet.</div>`}
      </div>
    </div>
  `;
}

function breakdownFromLocalSingles90(){
  const now = Date.now();
  const since = now - 90*86400000;
  const settled = (picks||[]).filter(p=>p.result && p.result!=='pending');
  const singles = settled.filter(p=>p.type!=='parlay' && (p.settledAt||p.madeAt||0) >= since);
  const n = singles.length;
  const wins = singles.filter(p=>p.result==='win' || p.result==='won').length;
  const losses = singles.filter(p=>p.result==='loss' || p.result==='lost').length;
  const decided = wins+losses;
  const winRate = decided? wins/decided : 0;

  function profitForPick(p){
    const stake = Number(p.wager||p.stake||0) || 0;
    const odds = Number(p.odds||p.odds_american||-110) || -110;
    const res = (p.result||'').toLowerCase();
    if(!stake) return 0;
    if(res==='push') return 0;
    if(res==='loss' || res==='lost') return -stake;
    if(res==='win' || res==='won'){
      if(odds>0) return stake*(odds/100);
      if(odds<0) return stake*(100/Math.abs(odds));
      return 0;
    }
    return 0;
  }
  const stakeSum = singles.reduce((a,p)=>a+(Number(p.wager||p.stake||0)||0),0);
  const profitSum = singles.reduce((a,p)=>a+profitForPick(p),0);
  const roi = stakeSum? (profitSum/stakeSum) : 0;

  // Consistency: weekly ROI volatility (last 6 weeks)
  const weeks = {};
  singles.forEach(p=>{
    const ts = (p.settledAt||p.madeAt||0);
    const wk = Math.floor(ts/604800000);
    (weeks[wk]=weeks[wk]||[]).push(p);
  });
  const wkKeys = Object.keys(weeks).map(Number).sort((a,b)=>b-a).slice(0,6);
  const wkRois = wkKeys.map(k=>{
    const arr=weeks[k];
    const st=arr.reduce((a,p)=>a+(Number(p.wager||p.stake||0)||0),0);
    const pr=arr.reduce((a,p)=>a+profitForPick(p),0);
    return st? pr/st : 0;
  });
  const mean = wkRois.length? wkRois.reduce((a,b)=>a+b,0)/wkRois.length : 0;
  const varr = wkRois.length? wkRois.reduce((a,x)=>a+(x-mean)*(x-mean),0)/wkRois.length : 0;
  const sd = Math.sqrt(varr); // higher = less consistent

  function band(val, cuts){
    if(val>=cuts[2]) return 'HIGH';
    if(val>=cuts[1]) return 'MEDIUM';
    if(val>=cuts[0]) return 'LOW';
    return 'VERY LOW';
  }

  const accuracyBand = band(winRate, [0.48, 0.52, 0.56]);
  const roiBand = band(roi, [-0.02, 0.02, 0.06]);
  const consistencyBand = sd<=0.05?'HIGH':sd<=0.10?'MEDIUM':sd<=0.18?'LOW':'VERY LOW';
  const sampleBand = n>=50?'HIGH':n>=20?'MEDIUM':n>=10?'LOW':n>=1?'VERY LOW':'—';

  return {n,wins,losses,winRate,roi,sd, accuracyBand, roiBand, consistencyBand, sampleBand};
}

function openBreakdownModal(){
  const b = breakdownFromLocalSingles90();
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.62);z-index:9999;display:flex;align-items:flex-end;justify-content:center;padding:18px;';
  overlay.onclick = (e)=>{ if(e.target===overlay) overlay.remove(); };
  const card = document.createElement('div');
  card.style.cssText = 'width:min(520px,100%);background:var(--panel);border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:16px 16px 14px;box-shadow:0 20px 60px rgba(0,0,0,.55);';
  const row = (label, band, detail)=>`
    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-top:1px solid rgba(255,255,255,.06)">
      <div>
        <div style="font-weight:800;letter-spacing:.6px">${label}</div>
        <div style="color:var(--dim);font-size:12px;margin-top:2px">${detail}</div>
      </div>
      <div style="font-family:DM Mono,monospace;font-size:12px;padding:6px 10px;border-radius:999px;background:rgba(0,229,255,.10);border:1px solid rgba(0,229,255,.20);color:var(--cyan)">${band}</div>
    </div>`;
  card.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
      <div>
        <div style="font-size:12px;letter-spacing:3px;color:var(--dim);text-transform:uppercase">Sharp Rating Breakdown</div>
        <div style="font-size:18px;font-weight:900;margin-top:4px">Last 90 Days · Singles</div>
      </div>
      <button class="btn" style="padding:8px 10px;border-radius:12px" onclick="this.closest('.modal-overlay').remove()">✕</button>
    </div>
    ${row('Accuracy', b.accuracyBand, b.n?`${Math.round(b.winRate*100)}% win rate (${b.wins}-${b.losses})`:'No settled picks yet')}
    ${row('ROI', b.roiBand, b.n?`${(Math.round(b.roi*1000)/10)}% ROI (${Math.round(b.n)} picks)`:'—')}
    ${row('Consistency', b.consistencyBand, b.n?`Weekly volatility: ${(Math.round(b.sd*1000)/10)}%`:'—')}
    ${row('Sample Size', b.sampleBand, b.n?`${b.n} settled singles (Verified at 20)`:'0 settled')}
    <div style="margin-top:10px;color:var(--dim);font-size:12px;line-height:1.4">
      Ratings are skill-based and update daily. Pending games don’t affect your score until they settle.
    </div>
  `;
  overlay.appendChild(card);
  document.body.appendChild(overlay);
}

function ratingCardHTML(r){
  const rating = r?.singles_overall_90;
  const picks90 = r?.singles_picks_90||0;
  const verified = !!r?.singles_verified_90;
  const tier = tierLabelFromRating(rating, verified);
  const pct = Math.min(100, Math.round((picks90/20)*100));
  return `
    <div class="sharp-card" style="background:linear-gradient(135deg, rgba(0,229,255,.10), rgba(0,229,255,.02));border:1px solid rgba(0,229,255,.22);border-radius:18px;padding:14px 14px 12px;margin-bottom:14px;cursor:pointer" onclick="openBreakdownModal()">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
        <div>
          <div style="font-size:11px;letter-spacing:3px;color:var(--dim);text-transform:uppercase">Sharp Rating · 90D</div>
          <div style="display:flex;align-items:baseline;gap:10px;margin-top:6px">
            <div style="font-size:34px;font-weight:950;line-height:1;color:var(--cyan)">${fmt1(rating)}</div>
            <div style="font-family:DM Mono,monospace;font-size:12px;padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08)">${tier}</div>
          </div>
          <div style="margin-top:8px;color:var(--dim);font-size:12px">
            ${picks90} settled singles · ${verified?'Verified':'Provisional'} · Updates daily
          </div>
        </div>
        <div style="min-width:120px;text-align:right">
          <div style="color:var(--dim);font-size:11px;letter-spacing:2px;text-transform:uppercase">Verified</div>
          <div style="margin-top:6px">
            <div style="height:8px;border-radius:999px;background:rgba(255,255,255,.08);overflow:hidden">
              <div style="height:100%;width:${pct}%;background:rgba(0,229,255,.65)"></div>
            </div>
            <div style="margin-top:6px;color:var(--dim);font-size:11px">${Math.max(0,20-picks90)} to unlock</div>
          </div>
        </div>
      </div>
    </div>`;
}

async function renderLeaderboardView(){
  const el=document.getElementById('leaderboardContent');
  el.innerHTML=`<div class="lb-empty"><div style="font-size:28px;margin-bottom:12px">⏳</div>LOADING SHARP LEADERBOARD…</div>`;
  const nameMap = await fetchNameMap();
  const rows = await fetchSharpLeaderboard(LB_SHARP_TAB);

  // Build header + tabs
  const tabBtn = (key,label)=>`<button class="lb-tab ${LB_SHARP_TAB===key?'on':''}" onclick="LB_SHARP_TAB='${key}';renderLeaderboardView()">${label}</button>`;
  const tabs = `
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      ${tabBtn('verified','Verified')}
      ${tabBtn('provisional','Provisional')}
      ${tabBtn('specialists','Specialists')}
    </div>`;

  // My rating card (if signed in)
  const myRatings = await fetchMyRatings();
  const myCard = myRatings ? ratingCardHTML(myRatings) : '';
  const movers = await fetchTopMoversToday();
  const moversSection = (movers && movers.length) ? `
    <div class="sp-card" style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div style="color:var(--dim);font-size:11px;letter-spacing:2px;text-transform:uppercase">Top Movers Today</div>
        <div style="color:var(--dim);font-size:11px">Δ since last update</div>
      </div>
      <div class="movers-row">
        ${movers.map(m=>{
          const nm = nameMap[m.user_id] || ('User '+String(m.user_id).slice(0,6));
          const delta = Number(m.delta||0);
          const sign = delta>0?'+':'';
          const pillBg = delta>0?'rgba(46,213,115,.14)':delta<0?'rgba(255,71,87,.14)':'rgba(255,255,255,.06)';
          const pillBr = delta>0?'rgba(46,213,115,.22)':delta<0?'rgba(255,71,87,.22)':'rgba(255,255,255,.10)';
          return `<div class="mover" data-uid="${m.user_id}" data-name="${escapeAttr(nm)}">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
              <div style="display:flex;align-items:center;gap:10px;min-width:0">
                <div class="lb-avatar" style="width:34px;height:34px;border-radius:14px">${String(nm||'U')[0].toUpperCase()}</div>
                <div style="min-width:0">
                  <div style="font-weight:900;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeAttr(nm)}</div>
                  <div style="color:var(--dim);font-size:11px">Now ${fmt1(m.current_rating)}</div>
                </div>
              </div>
              <div style="text-align:right">
                <div style="display:inline-block;font-size:11px;padding:6px 10px;border-radius:999px;background:${pillBg};border:1px solid ${pillBr}">${sign}${fmt1(delta)}</div>
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>
      <div style="margin-top:10px;color:var(--dim);font-size:11px">Tap a mover to view full stats</div>
    </div>` : '';

  if(!rows || !rows.length){
    // Empty state guidance
    el.innerHTML = `
      <div class="lb-hdr">
        <div>
          <div class="lb-title" style="display:flex;align-items:center;gap:8px"><img src="assets/sharppick-mark.png" alt="SharpPick" width="20" height="20" style="border-radius:6px;box-shadow:0 0 0 1px rgba(0,229,255,.14)"/>Sharp Rating Leaderboard</div>
          <div class="lb-subtitle">90-DAY · SKILL-BASED · NO GAMBLING</div>
          ${tabs}
        </div>
        <button class="lb-refresh" onclick="renderLeaderboardView()">↻ REFRESH</button>
      </div>
      ${myCard}
      ${moversSection}
      <div class="lb-empty">
        <div style="font-size:32px;margin-bottom:16px">🏆</div>
        ${LB_SHARP_TAB==='verified'?'NO VERIFIED SHARPS YET':'NO RATINGS YET'}
        <small>${LB_SHARP_TAB==='verified'?'Settle 20 singles to enter the Verified leaderboard.':'Make picks and come back after games settle.'}</small>
      </div>`;
    return;
  }

  // Specialists: choose sport + sort by that sport rating
  let entries = (rows||[]).map(r=>{
    const uid = r.user_id;
    return {
      user_id: uid,
      name: nameMap[uid] || ('User '+String(uid).slice(0,6)),
      rating: Number(r.singles_overall_90),
      picks: Number(r.singles_picks_90||0),
      verified: !!r.singles_verified_90,
      bySport: r.singles_by_sport_90 || {}
    };
  });

  let sportKeys = ['ALL'];
  if(LB_SHARP_TAB==='specialists'){
    const set = new Set();
    entries.forEach(e=>{ try{ Object.keys(e.bySport||{}).forEach(k=>set.add(k)); }catch{} });
    sportKeys = ['ALL', ...Array.from(set).sort()];
    if(!sportKeys.includes(LB_SPECIALIST_SPORT)) LB_SPECIALIST_SPORT='ALL';
    if(LB_SPECIALIST_SPORT!=='ALL'){
      entries = entries
        .filter(e=>e.bySport && e.bySport[LB_SPECIALIST_SPORT]!=null)
        .sort((a,b)=>Number(b.bySport[LB_SPECIALIST_SPORT])-Number(a.bySport[LB_SPECIALIST_SPORT]));
    } else {
      entries.sort((a,b)=>b.rating-a.rating);
    }
  } else {
    entries.sort((a,b)=>b.rating-a.rating);
  }

  const sportSelect = (LB_SHARP_TAB==='specialists') ? `
    <div style="margin-top:10px;display:flex;align-items:center;gap:10px">
      <div style="font-size:11px;letter-spacing:2px;color:var(--dim);text-transform:uppercase">Sport</div>
      <select class="lb-sel" onchange="LB_SPECIALIST_SPORT=this.value;renderLeaderboardView()" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10);color:var(--text);padding:8px 10px;border-radius:12px">
        ${sportKeys.map(k=>`<option value="${k}" ${k===LB_SPECIALIST_SPORT?'selected':''}>${k}</option>`).join('')}
      </select>
    </div>` : '';

  let html = `
    <div class="lb-hdr">
      <div>
        <div class="lb-title" style="display:flex;align-items:center;gap:8px"><img src="assets/sharppick-mark.png" alt="SharpPick" width="20" height="20" style="border-radius:6px;box-shadow:0 0 0 1px rgba(0,229,255,.14)"/>Sharp Rating Leaderboard</div>
        <div class="lb-subtitle">90-DAY · ${LB_SHARP_TAB==='verified'?'VERIFIED ONLY':'ALL USERS'} · UPDATED DAILY</div>
        ${tabs}
        ${sportSelect}
      </div>
      <button class="lb-refresh" onclick="renderLeaderboardView()">↻ REFRESH</button>
    </div>
    ${myCard}
    ${moversSection}
    <div class="lb-table-wrap">
      <table class="lb-table">
        <thead class="lb-head">
          <tr>
            <th style="width:40px">#</th>
            <th>PICKER</th>
            <th class="num">RATING</th>
            <th class="num">PICKS</th>
            <th class="num">STATUS</th>
            <th class="num">${LB_SHARP_TAB==='specialists' && LB_SPECIALIST_SPORT!=='ALL' ? LB_SPECIALIST_SPORT : 'TOP SPORT'}</th>
          </tr>
        </thead>
        <tbody>
  `;

  entries.slice(0,100).forEach((e,i)=>{
    const tier = tierLabelFromRating(e.rating, e.verified);
    const topSport = (()=>{
      try{
        const pairs = Object.entries(e.bySport||{}).map(([k,v])=>[k,Number(v)]).filter(([,v])=>isFinite(v));
        pairs.sort((a,b)=>b[1]-a[1]);
        if(LB_SHARP_TAB==='specialists' && LB_SPECIALIST_SPORT!=='ALL'){
          const v = e.bySport[LB_SPECIALIST_SPORT];
          return `${LB_SPECIALIST_SPORT} ${fmt1(v)}`;
        }
        return pairs.length? `${pairs[0][0]} ${fmt1(pairs[0][1])}` : '—';
      }catch{return '—'}
    })();
    html += `
      <tr class="lb-row ${e.user_id===currentUser?.id?'me':''}" data-uid="${e.user_id}" data-name="${escapeAttr(e.name)}">
        <td class="lb-cell lb-rank">${i===0?'🥇':i===1?'🥈':i===2?'🥉':(i+1)}</td>
        <td class="lb-cell">
          <div class="lb-name-cell">
            <div class="lb-avatar ${e.user_id===currentUser?.id?'me':''}">${String(e.name||'U')[0].toUpperCase()}</div>
            <div>
              <div class="lb-username">${e.name}${e.user_id===currentUser?.id?'<span class="lb-you"> YOU</span>':''}</div>
              <div class="lb-last-pick" style="color:var(--dim)">${tier}</div>
            </div>
          </div>
        </td>
        <td class="lb-cell num" style="color:var(--cyan);font-family:DM Mono,monospace">${fmt1(e.rating)}</td>
        <td class="lb-cell num">${e.picks}</td>
        <td class="lb-cell num"><span style="font-size:11px;padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08)">${e.verified?'VERIFIED':'PROVISIONAL'}</span></td>
        <td class="lb-cell num" style="color:var(--gold)">${topSport}</td>
      </tr>
    `;
  });

  html += `</tbody></table></div>`;
  el.innerHTML = html;

  // Click-through to public profile
  try{
    el.querySelectorAll('.lb-row[data-uid]').forEach(row=>{
      row.style.cursor='pointer';
      row.addEventListener('click', ()=>{
        const uid=row.dataset.uid;
        const nm=row.dataset.name;
        if(uid) openPublicProfile(uid, nm);
      });
    });
    el.querySelectorAll('.mover[data-uid]').forEach(card=>{
      card.style.cursor='pointer';
      card.addEventListener('click', ()=>{
        const uid=card.dataset.uid;
        const nm=card.dataset.name;
        if(uid) openPublicProfile(uid, nm);
      });
    });
  }catch(e){}
}



// ═══════════════════════════════════════════════════════
// TICKER
// ═══════════════════════════════════════════════════════
function updateTicker(){
  const items=allGames.filter(g=>g.isLive||g.isFinal).slice(0,30);
  if(!items.length) return;
  const html=items.map(g=>`<span class="ti">${g.isLive?`<span class="lv">● </span>`:''}${g.away.name} <span class="sc">${g.away.score}</span> — ${g.home.name} <span class="sc">${g.home.score}</span>${g.isLive?` · ${g.statusText}`:' · FINAL'}</span>`).join('');
  document.getElementById('tickerTrack').innerHTML=html+html;
}


// ═══════════════════════════════════════════════════════
// PUBLIC PICK TRENDS
// Each pick is stored shared so all users can see %
// ═══════════════════════════════════════════════════════
async function publishPickTrends(){
  if(!currentUser) return;
  const map={};
  picks.forEach(p=>{
    const gid=p.actualGameId||p.gameId;
    if(p.type==='prop') return;
    if(!map[gid]) map[gid]={spread:{},total:{}};
    if(p.type==='spread') map[gid].spread[p.side]=(map[gid].spread[p.side]||0)+1;
    if(p.type==='total')  map[gid].total[p.side]=(map[gid].total[p.side]||0)+1;
  });
  // Local fallback
  try{ localStorage.setItem('trends:'+currentUser.id, JSON.stringify(map)); }catch{}
  try{
    await sbUpsert('pick_trends',{user_id:currentUser.id, trends:map});
  }catch(e){ if(supaOnline!==false) console.warn('Trends publish failed:',e?.message); }
}

async function fetchPickTrends(){
  const merged={};
  try{
    const data=await sbSelect('pick_trends','select=trends');
    if(data){
      data.forEach(row=>{
        const t=row.trends||{};
        Object.entries(t).forEach(([gid,v])=>{
          if(!merged[gid]) merged[gid]={spread:{},total:{}};
          Object.entries(v.spread||{}).forEach(([side,cnt])=>{merged[gid].spread[side]=(merged[gid].spread[side]||0)+cnt;});
          Object.entries(v.total||{}).forEach(([side,cnt])=>{merged[gid].total[side]=(merged[gid].total[side]||0)+cnt;});
        });
      });
      return merged;
    }
  }catch(e){ if(supaOnline!==false) console.warn('Trends fetch failed:',e?.message); }
  // Fallback: localStorage
  try{
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);
      if(!k||!k.startsWith('trends:')) continue;
      let data; try{data=JSON.parse(localStorage.getItem(k)||'{}');}catch{continue;}
      Object.entries(data).forEach(([gid,v])=>{
        if(!merged[gid]) merged[gid]={spread:{},total:{}};
        Object.entries(v.spread||{}).forEach(([side,cnt])=>{merged[gid].spread[side]=(merged[gid].spread[side]||0)+cnt;});
        Object.entries(v.total||{}).forEach(([side,cnt])=>{merged[gid].total[side]=(merged[gid].total[side]||0)+cnt;});
      });
    }
  }catch{}
  return merged;
}

let cachedTrends={};
function trendHTML(g){
  const t=cachedTrends[g.id];
  if(!t) return '';
  const sp=t.spread||{}, tot=t.total||{};
  const spTotal=Object.values(sp).reduce((a,b)=>a+b,0);
  const totTotal=Object.values(tot).reduce((a,b)=>a+b,0);
  if(spTotal===0&&totTotal===0) return '';
  let html='<div class="trend-bar-wrap">';
  if(spTotal>0){
    const keys=Object.keys(sp);
    const a=keys[0],b=keys[1]||null;
    const aPct=Math.round((sp[a]||0)/spTotal*100);
    const bPct=b?100-aPct:0;
    html+=`<div class="trend-label-row"><span>${a.split(' ').slice(-1)[0]}</span><span>${b||'—'}</span></div>
    <div class="trend-bar-track"><div class="trend-away" style="width:${aPct}%"></div><div class="trend-home" style="width:${bPct}%"></div></div>
    <div class="trend-counts"><span class="trend-count-away">${sp[a]||0} pick${(sp[a]||0)!==1?'s':''} (${aPct}%)</span>${b?`<span class="trend-count-home">${sp[b]||0} picks (${bPct}%)</span>`:''}
    </div>`;
  }
  if(totTotal>0){
    const oPct=Math.round((tot.over||0)/totTotal*100);
    html+=`<div class="trend-label-row" style="margin-top:6px"><span>OVER</span><span>UNDER</span></div>
    <div class="trend-bar-track"><div class="trend-away" style="width:${oPct}%"></div><div class="trend-home" style="width:${100-oPct}%"></div></div>
    <div class="trend-counts"><span class="trend-count-away">${tot.over||0} (${oPct}%)</span><span class="trend-count-home">${tot.under||0} (${100-oPct}%)</span></div>`;
  }
  return html+'</div>';
}

async function refreshTrends(){
  cachedTrends=await fetchPickTrends();
  renderScores();
}

// ═══════════════════════════════════════════════════════
// ACHIEVEMENTS
// ═══════════════════════════════════════════════════════
const ACHIEVEMENTS=[
  {id:'first_pick',  icon:'🎯', name:'First Blood',    desc:'Make your first pick',             check:p=>p.length>=1},
  {id:'win_3',       icon:'🔥', name:'On a Roll',       desc:'Win 3 picks',                      check:(p,s)=>s.w>=3},
  {id:'win_10',      icon:'💎', name:'Diamond Hands',   desc:'Win 10 picks',                     check:(p,s)=>s.w>=10},
  {id:'win_50',      icon:'👑', name:'The King',        desc:'Win 50 picks',                     check:(p,s)=>s.w>=50},
  {id:'streak_3',    icon:'⚡', name:'Hat Trick',       desc:'Win 3 in a row',                   check:(p,s)=>s.curStreak>=3},
  {id:'streak_5',    icon:'🌋', name:'Eruption',        desc:'Win 5 in a row',                   check:(p,s)=>s.curStreak>=5},
  {id:'streak_10',   icon:'🚀', name:'To The Moon',     desc:'Win 10 in a row',                  check:(p,s)=>s.curStreak>=10},
  {id:'over_hunter', icon:'📈', name:'Over Hunter',     desc:'10 winning over picks',            check:(p)=>p.filter(x=>x.type==='total'&&x.side==='over'&&x.result==='won').length>=10},
  {id:'prop_master', icon:'🔬', name:'Prop Master',     desc:'Win 10 prop bets',                 check:(p)=>p.filter(x=>x.type==='prop'&&x.result==='won').length>=10},
  {id:'upset_king',  icon:'💥', name:'Upset King',      desc:'Win 5 underdog spread picks',      check:(p)=>p.filter(x=>x.type==='spread'&&x.result==='won'&&parseFloat((x.description||'').match(/[+-][\d.]+/)?.[0]||'0')>0).length>=5},
  {id:'pct_60',      icon:'📊', name:'Sharp',           desc:'60%+ win rate (min 20 picks)',      check:(p,s)=>s.decided>=20&&s.w/s.decided>=0.60},
  {id:'pct_70',      icon:'🧠', name:'The Algorithm',  desc:'70%+ win rate (min 30 picks)',      check:(p,s)=>s.decided>=30&&s.w/s.decided>=0.70},
  {id:'multi_sport', icon:'🌍', name:'All-Star',        desc:'Win picks in 3 different sports',  check:(p)=>new Set(p.filter(x=>x.result==='won').map(x=>x.league)).size>=3},
  {id:'perfect_day', icon:'✨', name:'Perfect Day',     desc:'Go 5-0 on a single day',           check:(p)=>{const byDay={};p.forEach(x=>{if(x.result==='won'){const d=new Date(x.madeAt).toDateString();byDay[d]=(byDay[d]||0)+1;}});const byDayL={};p.forEach(x=>{if(x.result==='lost'){const d=new Date(x.madeAt).toDateString();byDayL[d]=(byDayL[d]||0)+1;}});return Object.keys(byDay).some(d=>byDay[d]>=5&&!byDayL[d]);}},
];

function calcPickStats(p){
  const settled=p.filter(x=>x.result!=='pending');
  const w=settled.filter(x=>x.result==='won').length;
  const l=settled.filter(x=>x.result==='lost').length;
  const decided=w+l;
  // current win streak
  const ordered=[...settled].sort((a,b)=>b.madeAt-a.madeAt).filter(x=>x.result!=='push');
  let curStreak=0;
  if(ordered.length&&ordered[0].result==='won'){for(const x of ordered){if(x.result==='won')curStreak++;else break;}}
  return{w,l,decided,curStreak};
}

let unlockedAchs=new Set(JSON.parse(localStorage.getItem('ls_achs')||'[]'));
function updateMobileBadge(){
  const pending=picks.filter(p=>p.result==='pending').length;
  const badge=document.getElementById('mobPicksBadge');
  if(badge){badge.style.display=pending>0?'flex':'none';badge.textContent=String(pending);}
}

function checkAchievements(){
  const stats=calcPickStats(picks);
  ACHIEVEMENTS.forEach(a=>{
    if(unlockedAchs.has(a.id)) return;
    try{ if(a.check(picks,stats)){
      unlockedAchs.add(a.id);
      localStorage.setItem('ls_achs',JSON.stringify([...unlockedAchs]));
      showAchToast(a);
    }}catch(e){}
  });
}
function showAchToast(a){
  const t=document.getElementById('achToast');
  const n=document.getElementById('achToastName');
  const i=document.getElementById('achToastIcon');
  if(!t) return;
  i.textContent=a.icon; n.textContent=a.name;
  t.classList.add('show');
  // Auto-dismiss after 2.5s, and allow tap to dismiss
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>t.classList.remove('show'),2500);
  t.onclick=()=>{t.classList.remove('show');clearTimeout(t._timer);};
}

// ═══════════════════════════════════════════════════════
// ANALYSIS VIEW
// ═══════════════════════════════════════════════════════
function renderAnalysisView(){ renderAnalyticsView(); }
function renderAnalyticsView(){
  const el=document.getElementById('analysisContent');
  if(!el) return;
  const settled=picks.filter(p=>p.result!=='pending');
  const stats=calcPickStats(picks);
  const pct=stats.decided>0?Math.round(stats.w/stats.decided*100):0;

  // By sport/league
  const sports={};
  settled.forEach(p=>{
    const s=p.league||'Other';
    if(!sports[s]) sports[s]={w:0,l:0,p:0};
    sports[s][p.result==='won'?'w':p.result==='lost'?'l':'p']++;
  });
  const sportRows=Object.entries(sports).sort((a,b)=>{
    const aD=a[1].w+a[1].l, bD=b[1].w+b[1].l;
    const aP=aD>0?a[1].w/aD:0, bP=bD>0?b[1].w/bD:0;
    return bP-aP;
  });

  // By type
  const byType={spread:{w:0,l:0,p:0},total:{w:0,l:0,p:0},prop:{w:0,l:0,p:0}};
  settled.forEach(p=>{if(byType[p.type]) byType[p.type][p.result==='won'?'w':p.result==='lost'?'l':'p']++;});

  // By day of week
  const byDay={};
  settled.forEach(p=>{
    const d=new Date(p.madeAt).getDay();
    if(!byDay[d]) byDay[d]={w:0,l:0};
    if(p.result==='won') byDay[d].w++; else if(p.result==='lost') byDay[d].l++;
  });
  const dayNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const dayEntries=Object.entries(byDay).filter(([,v])=>v.w+v.l>=1);
  const bestDay=dayEntries.length?dayEntries.sort(([,a],[,b])=>{const ap=a.w/(a.w+a.l),bp=b.w/(b.w+b.l);return bp-ap;})[0]:null;

  // ROI
  let totalWagered=0, totalProfit=0;
  settled.forEach(p=>{
    if(p.wager){
      totalWagered+=p.wager;
      if(p.result==='won') totalProfit+=calcPayout(p.wager,p.odds||-110);
      else if(p.result==='lost') totalProfit-=p.wager;
    }
  });
  const roiPct=totalWagered>0?Math.round(totalProfit/totalWagered*100):0;

  // Streak history
  const streakHistory=settled.filter(p=>p.result!=='push').sort((a,b)=>a.madeAt-b.madeAt).map(p=>p.result==='won'?1:-1);
  const dotCount=Math.min(streakHistory.length,40);
  const dots=streakHistory.slice(-dotCount).map(v=>`<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${v===1?'var(--green)':'var(--red)'};margin:1px;"></span>`).join('');

  // Lock record
  const lockRec=getLockRecord();

  // Achievements
  const achUnlocked=ACHIEVEMENTS.filter(a=>unlockedAchs.has(a.id)).length;

  // Helper
  const p2=(w,l)=>w+l>0?Math.round(w/(w+l)*100)+'%':'—';
  const pc=(w,l)=>{const v=w+l>0?Math.round(w/(w+l)*100):50;return v>=55?'var(--green)':v>=45?'var(--gold)':'var(--red)';};

  if(!settled.length){
    el.innerHTML=`<div class="section-hdr-row"><div><div class="section-title">📊 Analytics</div><div class="section-sub">PERFORMANCE · EDGES · ACHIEVEMENTS</div></div></div>
    <div style="padding:60px 20px;text-align:center;font-family:'DM Mono',monospace;font-size:12px;color:var(--muted);letter-spacing:2px">No settled picks yet<br><small style="font-size:10px;color:var(--dim)">Make some picks to unlock your analytics</small></div>`;
    return;
  }

  el.innerHTML=`
  <div class="section-hdr-row">
    <div><div class="section-title">📊 Analytics</div><div class="section-sub">PERFORMANCE · EDGES · ACHIEVEMENTS</div></div>
    <button class="lb-refresh" onclick="setMode('analysis')">↻</button>
  </div>

  <!-- OVERVIEW CARDS -->
  <div class="analysis-grid">
    <div class="analysis-card">
      <div class="analysis-card-title">Overall Record</div>
      <div class="analysis-big-num" style="color:${pct>=55?'var(--green)':pct>=45?'var(--gold)':'var(--red)'}">${pct}%</div>
      <div class="analysis-sub">${stats.w}W — ${stats.l}L${settled.filter(p=>p.result==='push').length?' — '+settled.filter(p=>p.result==='push').length+'P':''}</div>
      <div style="margin-top:12px;height:6px;background:var(--dim);border-radius:3px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:${pct>=55?'var(--green)':pct>=45?'var(--gold)':'var(--red)'};border-radius:3px;transition:width .6s ease"></div>
      </div>
    </div>
    <div class="analysis-card">
      <div class="analysis-card-title">Current Streak</div>
      <div class="streak-display">
        <div class="streak-fire">${stats.curStreak>=5?'🔥':stats.curStreak>=3?'⚡':'🎯'}</div>
        <div class="streak-num" style="color:${stats.curStreak>=3?'var(--green)':'var(--text)'}">${stats.curStreak}</div>
        <div class="streak-label">${stats.curStreak===1?'WIN IN A ROW':stats.curStreak>1?'WINS IN A ROW':'NO ACTIVE STREAK'}</div>
      </div>
      <div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:1px">${dots}</div>
    </div>
    <div class="analysis-card">
      <div class="analysis-card-title">Bankroll & ROI</div>
      <div class="analysis-big-num" style="color:${totalProfit>=0?'var(--green)':'var(--red)'}">${totalProfit>=0?'+':''}$${Math.abs(Math.round(totalProfit))}</div>
      <div class="analysis-sub">$${totalWagered} wagered · ${roiPct>=0?'+':''}${roiPct}% ROI</div>
      <div style="margin-top:8px">${renderMiniSparkline()}</div>
    </div>
    ${lockRec.total>0?`<div class="analysis-card">
      <div class="analysis-card-title">🔒 Lock Record</div>
      <div class="analysis-big-num" style="color:${lockRec.w>=lockRec.l?'var(--gold)':'var(--red)'}">${lockRec.w}-${lockRec.l}</div>
      <div class="analysis-sub">${lockRec.total} lock${lockRec.total!==1?'s':''} placed${lockRec.w+lockRec.l>0?' · '+Math.round(lockRec.w/(lockRec.w+lockRec.l)*100)+'%':''}</div>
    </div>`:''}
  </div>

  <!-- EDGE FINDER -->
  <div class="section-hdr-row" style="margin-top:16px">
    <div><div class="section-title">🎯 Edge Finder</div><div class="section-sub">WHERE YOU WIN & WHERE TO IMPROVE</div></div>
  </div>
  <div style="margin-bottom:16px">${renderEdgeFinder()}</div>

  <!-- BY DAY OF WEEK -->
  <div class="analysis-grid">
    <div class="analysis-card" style="grid-column:span 2">
      <div class="analysis-card-title">By Day of Week</div>
      <div style="display:flex;gap:4px;align-items:flex-end;height:60px;margin-bottom:8px">
        ${dayNames.map((d,i)=>{
          const {w=0,l=0}=byDay[i]||{};
          const dp=w+l>0?Math.round(w/(w+l)*100):0;
          const h=Math.max(dp,4);
          const c=dp>=55?'#2ed573':dp<=40&&w+l>0?'#ff4757':'var(--accent)';
          return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px">
            <div style="font-family:'DM Mono',monospace;font-size:8px;color:var(--dim)">${w+l>0?dp+'%':''}</div>
            <div style="width:100%;background:${c};border-radius:3px 3px 0 0;height:${h}%;min-height:3px;opacity:${w+l>0?1:.15}"></div>
            <div style="font-family:'DM Mono',monospace;font-size:8px;color:var(--muted)">${d.slice(0,2)}</div>
          </div>`;
        }).join('')}
      </div>
      ${bestDay?`<div style="font-family:'DM Mono',monospace;font-size:10px;color:var(--green);margin-top:4px">🔥 Best: ${dayNames[bestDay[0]]} (${p2(bestDay[1].w,bestDay[1].l)})</div>`:''}
    </div>
  </div>

  <!-- BY TYPE + BY LEAGUE -->
  <div class="analysis-grid" style="margin-top:8px">
    <div class="analysis-card">
      <div class="analysis-card-title">By Pick Type</div>
      ${['spread','total','prop'].map(t=>{
        const r=byType[t]; const d=r.w+r.l; const p=d>0?Math.round(r.w/d*100):0;
        return `<div class="analysis-sport-row">
          <div class="analysis-sport-name" style="text-transform:uppercase">${t==='total'?'O/U':t}</div>
          <div class="analysis-sport-bar-wrap"><div class="analysis-sport-bar" style="width:${p}%"></div></div>
          <div class="analysis-sport-pct" style="color:${p>=55?'var(--green)':p>=45?'var(--gold)':'var(--red)'}">${d?p+'%':'—'}</div>
          <div class="analysis-sport-rec">${r.w}-${r.l}</div>
        </div>`;
      }).join('')}
    </div>
    <div class="analysis-card">
      <div class="analysis-card-title">By League</div>
      ${sportRows.slice(0,8).map(([s,r])=>{
        const d=r.w+r.l; const p=d>0?Math.round(r.w/d*100):0;
        return `<div class="analysis-sport-row">
          <div class="analysis-sport-name">${s.replace(/\s🏀|🏈|⚾|🏒|⚽/g,'').trim().toUpperCase()}</div>
          <div class="analysis-sport-bar-wrap"><div class="analysis-sport-bar" style="width:${p}%"></div></div>
          <div class="analysis-sport-pct" style="color:${p>=55?'var(--green)':p>=45?'var(--gold)':'var(--red)'}">${d?p+'%':'—'}</div>
          <div class="analysis-sport-rec">${r.w}-${r.l}</div>
        </div>`;
      }).join('')}
    </div>
  </div>

  <!-- BANKROLL CHART -->
  <div class="analysis-card" style="margin-top:8px">
    <div class="analysis-card-title">Bankroll History</div>
    ${renderBankrollChart()}
  </div>

  <!-- ACHIEVEMENTS -->
  <div class="section-hdr-row" style="margin-top:16px">
    <div><div class="section-title">🏅 Achievements</div><div class="section-sub">${achUnlocked}/${ACHIEVEMENTS.length} UNLOCKED</div></div>
  </div>
  <div class="ach-grid">
    ${ACHIEVEMENTS.map(a=>{
      const unlocked=unlockedAchs.has(a.id);
      return `<div class="ach-card ${unlocked?'unlocked':'locked'}">
        <div class="ach-icon">${a.icon}</div>
        <div class="ach-name">${a.name}</div>
        <div class="ach-desc">${a.desc}</div>
        ${unlocked?'<div class="ach-date">✓ Unlocked</div>':''}
      </div>`;
    }).join('')}
  </div>`;
}

// ═══════════════════════════════════════════════════════
// NEWS VIEW — ESPN headlines via proxy
// ═══════════════════════════════════════════════════════
const NEWS_LEAGUES=[
  {label:'All',key:'all'},
  {label:'NFL 🏈',key:'nfl',url:'https://site.api.espn.com/apis/site/v2/sports/football/nfl/news'},
  {label:'NBA 🏀',key:'nba',url:'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news'},
  {label:'MLB ⚾',key:'mlb',url:'https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/news'},
  {label:'NHL 🏒',key:'nhl',url:'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/news'},
  {label:'NCAAF 🏈',key:'ncaaf',url:'https://site.api.espn.com/apis/site/v2/sports/football/college-football/news'},
];
let newsCache={};
let newsFilter='all';

async function renderNewsView(){
  const el=document.getElementById('newsContent');
  el.innerHTML=`<div class="section-hdr-row">
    <div><div class="section-title">📰 News Feed</div><div class="section-sub">LATEST HEADLINES</div></div>
  </div>
  <div class="news-filters">${NEWS_LEAGUES.map(l=>`<button class="news-filter-btn${newsFilter===l.key?' active':''}" onclick="setNewsFilter('${l.key}')">${l.label}</button>`).join('')}</div>
  <div id="newsGrid" class="news-grid"><div class="news-loading"><div class="stats-loading-ring"></div>LOADING…</div></div>`;
  await loadNews();
}

function setNewsFilter(key){
  newsFilter=key;
  renderNewsView();
}

async function loadNews(){
  const grid=document.getElementById('newsGrid');
  if(!grid) return;
  const leagues=newsFilter==='all'?NEWS_LEAGUES.slice(1):[NEWS_LEAGUES.find(l=>l.key===newsFilter)].filter(Boolean);
  if(newsCache[newsFilter]){renderNewsGrid(newsCache[newsFilter]);return;}
  try{
    const results=await Promise.allSettled(leagues.map(async l=>{
      const data=await go(l.url,8000);
      const articles=(data?.articles||[]).slice(0,newsFilter==='all'?4:12);
      return articles.map(a=>({...a,_league:l.label}));
    }));
    const all=results.flatMap(r=>r.status==='fulfilled'?r.value:[]);
    newsCache[newsFilter]=all;
    renderNewsGrid(all);
  }catch(e){
    if(grid) grid.innerHTML=`<div class="news-loading">Could not load news</div>`;
  }
}

function renderNewsGrid(articles){
  const grid=document.getElementById('newsGrid');
  if(!grid) return;
  if(!articles.length){grid.innerHTML=`<div class="news-loading">No articles found</div>`;return;}
  grid.innerHTML=articles.map(a=>{
    const img=a.images?.[0]?.url;
    const pub=a.published?new Date(a.published).toLocaleDateString([],{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'';
    return `<div class="news-card" onclick="window.open('${a.links?.web?.href||'#'}','_blank')">
      ${img?`<img class="news-card-img" src="${img}" alt="" loading="lazy" onerror="this.style.display='none'">`
            :`<div class="news-card-img-placeholder">📰</div>`}
      <div class="news-card-body">
        <div class="news-card-league">${a._league||''}</div>
        <div class="news-card-title">${a.headline||a.title||'Untitled'}</div>
        <div class="news-card-meta">${pub}${a.byline?' · '+a.byline:''}</div>
      </div>
    </div>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════
// PICK'EM CONTESTS
// ═══════════════════════════════════════════════════════
// Contests are auto-generated from today's games
// Shared storage key: contest:{contestId}:picks:{userId}
let activeContestId=null;

function getWeeklyContestId(){
  const now=new Date();
  const day=now.getDay(); // 0=Sun
  const diff=now.getDate()-day;
  const sun=new Date(now); sun.setDate(diff); sun.setHours(0,0,0,0);
  return `week_${sun.getFullYear()}_${String(sun.getMonth()+1).padStart(2,'0')}_${String(sun.getDate()).padStart(2,'0')}`;
}

function getDailyContestId(){
  return `daily_${todayStr()}`;
}

async function renderContestsView(){
  const el=document.getElementById('contestsContent');
  el.innerHTML=`<div class="section-hdr-row"><div><div class="section-title">🏆 Pick'em Contests</div><div class="section-sub">COMPETE WITH EVERYONE</div></div></div>
  <div id="contestsInner"><div class="news-loading"><div class="stats-loading-ring"></div>LOADING…</div></div>`;
  if(activeContestId) await renderContestDetail(activeContestId);
  else await renderContestList();
}

async function renderContestList(){
  const el=document.getElementById('contestsInner');
  if(!el) return;
  const dailyId=getDailyContestId();
  const weeklyId=getWeeklyContestId();
  const today=new Date().toLocaleDateString([],{weekday:'long',month:'long',day:'numeric'});
  const contests=[
    {id:dailyId, name:`Daily Pick'em`, desc:`Pick today's games — winner takes the day`, badge:'open', games:allGames.filter(g=>g.isPre).slice(0,10)},
    {id:weeklyId, name:`Weekly Pick'em`, desc:`Best record by Sunday wins the week`, badge:'open', games:allGames.filter(g=>g.isPre).slice(0,10)},
  ];
  if(!allGames.filter(g=>g.isPre).length){
    el.innerHTML=`<div class="news-loading">No upcoming games available for pick'em today.<br><small>Check back before games start.</small></div>`;
    return;
  }
  // Load my picks for each contest from localStorage
  const myPicks={};
  for(const c of contests){
    const lsKey='ls_contest_'+c.id+'_'+(currentUser?.id||'anon');
    try{myPicks[c.id]=JSON.parse(localStorage.getItem(lsKey)||'{}');}catch{myPicks[c.id]={};}
  }
  el.innerHTML=`<div class="contests-grid">${contests.map(c=>{
    const mp=myPicks[c.id]||{};
    const pickCount=Object.keys(mp).length;
    return `<div class="contest-card active-contest" onclick="openContest('${c.id}')">
      <div class="contest-badge open">● OPEN</div>
      <div class="contest-name">${c.name}</div>
      <div class="contest-desc">${c.desc}</div>
      <div class="contest-meta">
        <div class="contest-meta-item">📅 <strong>${today}</strong></div>
        <div class="contest-meta-item">🎯 <strong>${c.games.length}</strong> games</div>
        <div class="contest-meta-item">✅ <strong>${pickCount}</strong> picked</div>
      </div>
    </div>`;
  }).join('')}</div>`;
}

async function openContest(contestId){
  activeContestId=contestId;
  await renderContestDetail(contestId);
}

async function renderContestDetail(contestId){
  const el=document.getElementById('contestsInner');
  if(!el) return;
  const isDaily=contestId.startsWith('daily_');
  const contestName=isDaily?`Daily Pick'em`:`Weekly Pick'em`;
  const games=allGames.filter(g=>g.isPre).slice(0,10);

  // Load my picks from localStorage
  const lsKey='ls_contest_'+contestId+'_'+(currentUser?.id||'anon');
  let myPicks={};
  try{myPicks=JSON.parse(localStorage.getItem(lsKey)||'{}');}catch{}

  // Build leaderboard from all ls_contest_ keys for this contest
  const lbEntries=[];
  try{
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);
      if(!k||!k.startsWith('ls_contest_'+contestId+'_')) continue;
      const userId=k.replace('ls_contest_'+contestId+'_','');
      let ep={};
      try{ep=JSON.parse(localStorage.getItem(k)||'{}');}catch{continue;}
      const correct=Object.values(ep).filter(p=>p&&p.result==='correct').length;
      const wrong=Object.values(ep).filter(p=>p&&p.result==='wrong').length;
      const total=Object.keys(ep).filter(k2=>k2!=='_name').length;
      lbEntries.push({userId,name:ep._name||userId.slice(0,8),correct,wrong,total});
    }
    lbEntries.sort((a,b)=>b.correct-a.correct||a.wrong-b.wrong);
  }catch{}

  el.innerHTML=`
  <div class="section-hdr-row">
    <button class="contest-back-btn" onclick="activeContestId=null;renderContestList()">← Back</button>
    <div style="text-align:right"><div class="section-title">${contestName}</div><div class="section-sub">${games.length} GAMES · PICK THE WINNER</div></div>
  </div>
  <div class="contest-detail">
    <div style="font-family:'DM Mono',monospace;font-size:10px;color:var(--muted);margin-bottom:12px;letter-spacing:1px">PICK EACH GAME — CLOSEST RECORD WINS</div>
    ${games.map(g=>{
      const myPick=myPicks[g.id];
      const locked=myPick&&myPick.locked;
      const hBtn=myPick?.side===g.home.name?'selected':'';
      const aBtn=myPick?.side===g.away.name?'selected':'';
      const resultH=myPick?.result==='correct'&&myPick?.side===g.home.name?'correct':myPick?.result==='wrong'&&myPick?.side===g.home.name?'wrong':'';
      const resultA=myPick?.result==='correct'&&myPick?.side===g.away.name?'correct':myPick?.result==='wrong'&&myPick?.side===g.away.name?'wrong':'';
      return `<div class="contest-game-row">
        <div class="contest-teams">${g.away.name} <span style="color:var(--muted)">@</span> ${g.home.name}
          <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted)">${g.odds?.spread||''}</div>
        </div>
        <div class="contest-game-pick">
          <button class="contest-pick-btn ${aBtn} ${resultA}" data-cpcontest="${contestId}" data-cpgame="${g.id}" data-cpside="away" data-cpname="${g.away.name.replace(/"/g,'&quot;')}" ${locked?'disabled':''}>${g.away.abbr}</button>
          <button class="contest-pick-btn ${hBtn} ${resultH}" data-cpcontest="${contestId}" data-cpgame="${g.id}" data-cpside="home" data-cpname="${g.home.name.replace(/"/g,'&quot;')}" ${locked?'disabled':''}>${g.home.abbr}</button>
        </div>
      </div>`;
    }).join('')}
  </div>
  ${lbEntries.length?`
  <div class="section-sub" style="margin-bottom:8px">STANDINGS</div>
  <table class="contest-standings-table">
    <thead><tr><th>#</th><th>Name</th><th>Correct</th><th>Wrong</th><th>Pending</th></tr></thead>
    <tbody>
      ${lbEntries.map((e,i)=>`<tr class="${e.userId===currentUser?.id?'me-row':''}">
        <td>${i+1}</td>
        <td>${e.name}${e.userId===currentUser?.id?' <span style="color:var(--accent);font-size:9px">YOU</span>':''}</td>
        <td style="color:var(--green)">${e.correct}</td>
        <td style="color:var(--red)">${e.wrong}</td>
        <td style="color:var(--muted)">${e.total-e.correct-e.wrong}</td>
      </tr>`).join('')}
    </tbody>
  </table>`:``}`;
}

async function contestPick(contestId,gameId,side){
  if(!currentUser) return;
  const lsKey='ls_contest_'+contestId+'_'+currentUser.id;
  let myPicks={};
  try{myPicks=JSON.parse(localStorage.getItem(lsKey)||'{}');}catch{}
  // Toggle: clicking same side again removes the pick
  if(myPicks[gameId]&&myPicks[gameId].side===side){
    delete myPicks[gameId];
  } else {
    myPicks[gameId]={side,result:'pending',locked:false};
  }
  myPicks._name=currentUser.name;
  localStorage.setItem(lsKey,JSON.stringify(myPicks));
  // Re-render with updated picks
  await renderContestDetail(contestId);
}

// ═══════════════════════════════════════════════════════
// PRIVATE LEAGUES
// ═══════════════════════════════════════════════════════
let lbTab = 'global';       // 'global' | 'leagues'
let activeLeagueId = null;  // currently viewed league
let myLeagues = [];         // cached list of user's leagues

function switchLbTab(tab){
  lbTab = tab;
  document.getElementById('lbTabGlobal')?.classList.toggle('active', tab==='global');
  document.getElementById('lbTabLeagues')?.classList.toggle('active', tab==='leagues');
  document.getElementById('leaderboardContent').style.display = tab==='global' ? '' : 'none';
  document.getElementById('leaguesContent').style.display = tab==='leagues' ? '' : 'none';
  if(tab==='global') renderLeaderboardView();
  if(tab==='leagues') renderLeaguesView();
}

// ── Supabase helpers for leagues ─────────────────────
function genLeagueCode(){
  return Math.random().toString(36).slice(2,8).toUpperCase();
}

async function createLeague(name){
  if(!currentUser) return null;
  const code = genLeagueCode();
  const league = {
    id: code,
    name: name.trim(),
    owner_id: currentUser.id,
    owner_name: currentUser.name,
    member_count: 1,
  };
  await sbUpsert('leagues', league);
  await sbUpsert('league_members', {
    league_id: code,
    user_id: currentUser.id,
    user_name: currentUser.name,
  });
  return code;
}

async function joinLeague(code){
  if(!currentUser) return {ok:false, msg:'Set your name first'};
  const upper = code.toUpperCase().trim();
  // Check league exists
  const rows = await sbSelect('leagues', `id=eq.${upper}&select=id,name,member_count`);
  if(!rows || !rows.length) return {ok:false, msg:'League not found — check the code'};
  // Check already member
  const mem = await sbSelect('league_members',
    `league_id=eq.${upper}&user_id=eq.${currentUser.id}&select=user_id`);
  if(mem && mem.length) return {ok:false, msg:"You're already in this league"};
  // Join
  await sbUpsert('league_members', {
    league_id: upper,
    user_id: currentUser.id,
    user_name: currentUser.name,
  });
  // Increment member count
  const newCount = (rows[0].member_count||1) + 1;
  await sbUpsert('leagues', {...rows[0], member_count: newCount});
  return {ok:true, leagueName: rows[0].name};
}

async function fetchMyLeagues(){
  if(!currentUser) return [];
  try{
    const mem = await sbSelect('league_members',
      `user_id=eq.${currentUser.id}&select=league_id`);
    if(!mem||!mem.length) return [];
    const ids = mem.map(m=>`"${m.league_id}"`).join(',');
    const leagues = await sbSelect('leagues',
      `id=in.(${ids})&select=*&order=created_at.desc`);
    return leagues || [];
  }catch(e){ console.warn('fetchMyLeagues failed:',e.message); return []; }
}

async function fetchLeagueStandings(leagueId){
  try{
    // Get all members
    const members = await sbSelect('league_members',
      `league_id=eq.${leagueId}&select=user_id,user_name`);
    if(!members||!members.length) return [];
    // Get their leaderboard entries
    const ids = members.map(m=>`"${m.user_id}"`).join(',');
    const entries = await sbSelect('leaderboard',
      `user_id=in.(${ids})&select=*`);
    // Merge with member list (some may have no picks yet)
    return members.map(m=>{
      const lb = (entries||[]).find(e=>e.user_id===m.user_id);
      return {
        id: m.user_id,
        name: m.user_name,
        w: lb?.w||0, l: lb?.l||0, p: lb?.p||0, total: lb?.total||0,
        recentPicks: lb?.recent_picks||[],
      };
    }).sort((a,b)=>{
      const ap=(a.w+a.l)>0?a.w/(a.w+a.l):0;
      const bp=(b.w+b.l)>0?b.w/(b.w+b.l):0;
      if(Math.abs(ap-bp)>0.001) return bp-ap;
      return (b.w+b.l)-(a.w+a.l);
    });
  }catch(e){ console.warn('fetchLeagueStandings failed:',e.message); return []; }
}

// ── Render ───────────────────────────────────────────
async function renderLeaguesView(){
  const el = document.getElementById('leaguesContent');
  if(!el) return;
  if(activeLeagueId){
    await renderLeagueDetail(activeLeagueId);
    return;
  }
  el.innerHTML = `<div class="leagues-page"><div style="color:var(--muted);font-family:'DM Mono',monospace;font-size:10px;text-align:center;padding:20px 0">LOADING…</div></div>`;
  myLeagues = await fetchMyLeagues();
  el.innerHTML = `<div class="leagues-page">
    ${renderCreateJoinForms()}
    ${myLeagues.length ? myLeagues.map(lg=>`
      <div class="league-card" onclick="openLeague('${lg.id}')">
        <div class="league-card-top">
          <div class="league-card-name">${lg.name}</div>
          <div class="league-code-badge">${lg.id}</div>
        </div>
        <div class="league-card-meta">
          <span>👥 ${lg.member_count||1} member${(lg.member_count||1)!==1?'s':''}</span>
          <span>👑 ${lg.owner_name}</span>
        </div>
      </div>`).join('') : `
      <div class="league-empty">
        <div class="league-empty-icon">🏆</div>
        NO LEAGUES YET<br>
        <span style="color:var(--dim)">Create one or join with an invite code</span>
      </div>`}
  </div>`;
}

function renderCreateJoinForms(){
  return `
  <div class="league-form" style="margin-bottom:12px">
    <div class="league-form-title">➕ CREATE A LEAGUE</div>
    <input id="leagueNameInput" class="league-input" placeholder="League name (e.g. Office Picks)" maxlength="40">
    <div id="createLeagueError" class="league-error" style="display:none"></div>
    <button class="league-submit-btn" onclick="handleCreateLeague()">CREATE LEAGUE</button>
  </div>
  <div class="league-form" style="margin-bottom:16px">
    <div class="league-form-title">🔗 JOIN WITH INVITE CODE</div>
    <input id="leagueCodeInput" class="league-input code-input" placeholder="ABC123" maxlength="6">
    <div id="joinLeagueError" class="league-error" style="display:none"></div>
    <button class="league-submit-btn secondary" onclick="handleJoinLeague()">JOIN LEAGUE</button>
  </div>`;
}

async function handleCreateLeague(){
  const nameEl = document.getElementById('leagueNameInput');
  const errEl  = document.getElementById('createLeagueError');
  const name   = nameEl?.value?.trim();
  if(!name){ if(errEl){errEl.textContent='Enter a league name';errEl.style.display='';} return; }
  if(!currentUser){ if(errEl){errEl.textContent='Set your name first';errEl.style.display='';} return; }
  if(errEl) errEl.style.display='none';
  try{
    const code = await createLeague(name);
    activeLeagueId = code;
    await renderLeagueDetail(code);
  }catch(e){
    if(errEl){errEl.textContent='Error: '+e.message;errEl.style.display='';}
  }
}

async function handleJoinLeague(){
  const codeEl = document.getElementById('leagueCodeInput');
  const errEl  = document.getElementById('joinLeagueError');
  const code   = codeEl?.value?.trim().toUpperCase();
  if(!code||code.length<4){ if(errEl){errEl.textContent='Enter a valid invite code';errEl.style.display='';} return; }
  if(errEl) errEl.style.display='none';
  try{
    const result = await joinLeague(code);
    if(!result.ok){ if(errEl){errEl.textContent=result.msg;errEl.style.display='';} return; }
    activeLeagueId = code;
    await renderLeagueDetail(code);
  }catch(e){
    if(errEl){errEl.textContent='Error: '+e.message;errEl.style.display='';}
  }
}

async function openLeague(leagueId){
  activeLeagueId = leagueId;
  await renderLeagueDetail(leagueId);
}

async function renderLeagueDetail(leagueId){
  const el = document.getElementById('leaguesContent');
  if(!el) return;
  el.innerHTML = `<div class="leagues-page"><div style="color:var(--muted);font-family:'DM Mono',monospace;font-size:10px;text-align:center;padding:30px 0">LOADING STANDINGS…</div></div>`;

  let league = myLeagues.find(l=>l.id===leagueId);
  if(!league){
    try{
      const rows = await sbSelect('leagues',`id=eq.${leagueId}&select=*`);
      league = rows?.[0];
    }catch{}
  }
  const standings = await fetchLeagueStandings(leagueId);
  const meId = currentUser?.id;
  const isOwner = league?.owner_id === meId;

  const rankIcon = i => i===0?'🥇':i===1?'🥈':i===2?'🥉':`${i+1}`;

  el.innerHTML = `<div class="leagues-page">
    <div class="league-detail-hdr">
      <button class="league-back-btn" onclick="activeLeagueId=null;renderLeaguesView()">← Back</button>
      <div class="league-detail-name">${league?.name||leagueId}</div>
    </div>

    <div class="league-invite-box">
      <div class="league-invite-label">INVITE CODE — SHARE WITH FRIENDS</div>
      <div class="league-invite-code">${leagueId}</div>
      <button class="league-invite-copy" onclick="navigator.clipboard.writeText('${leagueId}').then(()=>this.textContent='✅ COPIED!').catch(()=>this.textContent='${leagueId}')">📋 COPY CODE</button>
      <button class="league-invite-copy" style="background:rgba(0,229,255,.08)" onclick="copyLeagueLink('${leagueId}')">🔗 SHARE LINK</button>
    </div>

    <div class="lb-subtitle" style="margin-bottom:10px;padding:0 4px">
      ${standings.length} MEMBER${standings.length!==1?'S':''} · RANKED BY WIN %
    </div>

    <div class="lb-table-wrap">
    <table class="lb-table">
      <thead class="lb-head">
        <tr>
          <th style="width:36px">#</th>
          <th>PICKER</th>
          <th class="num">W</th>
          <th class="num">L</th>
          <th class="num">WIN %</th>
          <th class="lb-bar-cell"></th>
        </tr>
      </thead>
      <tbody>
        ${standings.map((entry,i)=>{
          const isMe = entry.id===meId;
          const decided = entry.w+entry.l;
          const pct = decided>0?Math.round(entry.w/decided*100):0;
          return `<tr class="lb-row ${isMe?'me':''} ${i<3?'rank-'+(i+1):''}">
            <td class="lb-cell lb-rank">${rankIcon(i)}</td>
            <td class="lb-cell">
              <div class="lb-name-cell">
                <div class="lb-avatar ${isMe?'me':''}">${entry.name[0].toUpperCase()}</div>
                <div>
                  <div class="lb-username">${entry.name}${isMe?'<span class="lb-you"> YOU</span>':''}</div>
                  <div class="lb-last-pick">${entry.total||0} pick${(entry.total||0)!==1?'s':''}</div>
                </div>
              </div>
            </td>
            <td class="lb-cell num lb-w">${entry.w}</td>
            <td class="lb-cell num lb-l">${entry.l}</td>
            <td class="lb-cell num"><span class="lb-pct">${decided>0?pct+'%':'—'}</span></td>
            <td class="lb-cell lb-bar-cell">
              <div class="lb-bar-wrap"><div class="lb-bar" style="width:${pct}%"></div></div>
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
    </div>
    <div class="chat-wrap" id="leagueChatWrap-${leagueId}">
      <div class="chat-title">💬 LEAGUE CHAT</div>
      <div class="chat-messages" id="chatMessages-${leagueId}">
        <div style="color:var(--dim);font-family:'DM Mono',monospace;font-size:9px;text-align:center;padding:8px">Loading messages…</div>
      </div>
      <div class="chat-input-row">
        <input class="chat-input" id="chatInput-${leagueId}" placeholder="Say something…" maxlength="200"
          onkeydown="if(event.key==='Enter')sendChatMessage('${leagueId}')" />
        <button class="chat-send-btn" onclick="sendChatMessage('${leagueId}')">SEND</button>
      </div>
    </div>
  </div>`;
  loadChatMessages(leagueId);
}

// ── Delegated click handler for contest pick buttons — avoids inline onclick with team names
document.addEventListener('click',function(e){
  const btn=e.target.closest('.contest-pick-btn');
  if(!btn) return;
  const contestId=btn.dataset.cpcontest;
  const gameId=btn.dataset.cpgame;
  const side=btn.dataset.cpname; // full team name stored in data-cpname
  if(!contestId||!gameId||!side) return;
  e.stopPropagation();
  contestPick(contestId,gameId,side);
});

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════
buildDateStrip();
updateRecordUI();
initHero();
initUserWithAuth();
if(cache[selDate]){allGames=cache[selDate];clearSkeleton();fullRender();}
fetchDate(selDate).then(()=>{
  schedulePoll();
  prefetchNeighbors();
  if(typeof handleRouteChange==='function') handleRouteChange();
  snapshotOdds();          // baseline so first odds fetch only flashes real changes
  loadAllExternalOdds();   // immediate first odds fetch
  scheduleOddsPoll();      // then every 3 minutes
  fetchInjuries();         // load injury feed
  setTimeout(fetchWeatherForGames, 2000); // weather after initial load
  setTimeout(renderDailyChallenge, 1000);
  if(shouldShowWeeklyRecap()) setTimeout(showWeeklyRecap, 1500); // Monday recap
  patchCheckPickResultsForCelebrations(); // celebrations on pick settlement
  // Sync to Supabase on load
  publishToLeaderboard();
  publishPickTrends();
  refreshTrends();
  // Test Supabase connection
  (async()=>{
    try{
      const r = await Promise.race([
        fetch(`${SUPA_REST}/leaderboard?select=user_id&limit=1`,{headers:{...SUPA_HDR,'Accept':'application/json'}}),
        timeoutPromise(6000)
      ]);
      if(r.ok){
        const lb = await r.json();
        markSupaOk();
        console.log('✅ Supabase connected, leaderboard rows:',lb?.length??0);
      } else {
        throw new Error(`HTTP ${r.status}`);
      }
    }catch(e){
      if(e.message?.includes('Failed to fetch')||e.name==='AbortError'){
        console.warn('⚠️ Supabase unreachable on startup — is your project paused? Visit supabase.com/dashboard to resume it. Free tier pauses after 7 days of inactivity.');
      } else {
        console.warn('⚠️ Supabase startup check failed:',e.message);
      }
      supaOnline = false;
      supaFailCount = SUPA_MAX_FAILS;
      setTimeout(retrySupaConnection, 30000); // retry after 30s
    }
  })();
});
// ═══════════════════════════════════════════════════════
// MARCH MADNESS BRACKET
// ═══════════════════════════════════════════════════════
const BRACKET_KEY = 'mm_bracket_2025';

const MM_REGIONS = ['East','West','South','Midwest'];
const MM_SEEDS = [1,16,8,9,5,12,4,13,6,11,3,14,7,10,2,15];

function loadBracket(){
  try{ return JSON.parse(localStorage.getItem(BRACKET_KEY)||'null'); }catch{ return null; }
}
function saveBracket(b){ localStorage.setItem(BRACKET_KEY, JSON.stringify(b)); }

function initBracket(){
  const existing = loadBracket();
  if(existing) return existing;
  // Build blank bracket structure
  const bracket = { regions:{}, finalFour:{}, champion:null, picks:{} };
  MM_REGIONS.forEach(r=>{
    bracket.regions[r] = MM_SEEDS.map(seed=>({seed, name:'', region:r}));
  });
  bracket.finalFour = { East:null, West:null, South:null, Midwest:null };
  saveBracket(bracket);
  return bracket;
}

function renderBracketView(){
  const el = document.getElementById('bracketContent');
  if(!el) return;
  const bracket = initBracket();

  // Score: correct picks
  const picks_made = Object.values(bracket.picks||{}).filter(p=>p).length;

  el.innerHTML = `
    <div class="bracket-hdr">
      <div>
        <div class="bracket-title">🏀 March Madness 2025</div>
        <div class="bracket-sub">NCAA TOURNAMENT BRACKET</div>
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        <div class="bracket-score-wrap" style="margin:0;padding:8px 14px">
          <div class="bracket-score-item">
            <div class="bracket-score-num" style="font-size:16px">${picks_made}</div>
            <div class="bracket-score-lbl">PICKS MADE</div>
          </div>
        </div>
        <button class="bracket-reset-btn" onclick="resetBracket()">↺ RESET</button>
      </div>
    </div>

    <div style="overflow-x:auto;padding-bottom:16px">
      <div style="display:flex;gap:16px;min-width:1100px">
        ${MM_REGIONS.map(r=>renderRegion(bracket, r)).join('')}
      </div>
    </div>

    <div class="bracket-champion">
      <div class="bracket-champ-label">🏆 NATIONAL CHAMPION</div>
      ${bracket.champion
        ? `<div class="bracket-champ-name">${bracket.champion}</div>`
        : `<div class="bracket-champ-empty">Make your Final Four picks to reveal the champion</div>`}
    </div>

    <div style="padding:16px 0 8px">
      <div class="bracket-sub" style="margin-bottom:12px;padding:0 4px">FINAL FOUR</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${MM_REGIONS.map(r=>{
          const team = bracket.finalFour[r];
          return `<div style="flex:1;min-width:160px;background:var(--card);border:1px solid ${team?'var(--accent)':'var(--border)'};border-radius:8px;padding:12px;cursor:pointer" onclick="pickChampion('${r}')">
            <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-bottom:6px">${r.toUpperCase()} WINNER</div>
            <div style="font-size:13px;font-weight:700;color:${team?'var(--accent)':'var(--dim)'}">${team||'TBD'}</div>
          </div>`;
        }).join('')}
      </div>
    </div>
  `;
}

function renderRegion(bracket, region){
  const teams = bracket.regions[region];
  // Build rounds from teams
  // Round 1: 8 games (16 teams)
  // Round 2: 4 games, Round 3 (Sweet 16): 2 games, Round 4 (Elite 8): 1 game
  const rounds = [[], [], [], []];
  // Round 1: pair seeds
  for(let i=0;i<teams.length;i+=2){
    rounds[0].push([teams[i], teams[i+1]]);
  }
  // Rounds 2-4: advance winners or TBD
  for(let r=1;r<4;r++){
    const prev = rounds[r-1];
    for(let i=0;i<prev.length;i+=2){
      const t1 = getWinner(bracket, region, r-1, i);
      const t2 = getWinner(bracket, region, r-1, i+1);
      rounds[r].push([t1||{seed:'',name:'TBD',tbd:true}, t2||{seed:'',name:'TBD',tbd:true}]);
    }
  }

  const roundLabels = ['ROUND OF 64','ROUND OF 32','SWEET 16','ELITE 8'];

  return `<div style="flex:1;min-width:220px">
    <div style="font-family:'DM Mono',monospace;font-size:11px;font-weight:700;color:var(--accent);text-align:center;margin-bottom:10px;letter-spacing:2px">${region.toUpperCase()}</div>
    <div style="display:flex;gap:4px">
      ${rounds.map((games,ri)=>`
        <div style="flex:1;display:flex;flex-direction:column;gap:${Math.pow(2,ri)*4}px">
          <div class="bracket-round-label">${roundLabels[ri]}</div>
          ${games.map((game,gi)=>renderBGame(bracket, region, ri, gi, game)).join('')}
        </div>
      `).join('')}
    </div>
  </div>`;
}

function getWinner(bracket, region, round, gameIdx){
  const key = `${region}_r${round}_g${gameIdx}`;
  return bracket.picks[key] || null;
}

function renderBGame(bracket, region, round, gameIdx, teams){
  return `<div class="b-game">
    ${teams.map((t,ti)=>{
      const winner = getWinner(bracket, region, round, gameIdx);
      const isWinner = winner && winner.name===t.name && !t.tbd;
      const isLoser  = winner && winner.name!==t.name && !t.tbd;
      const cls = t.tbd?'tbd':(isWinner?'winner':(isLoser?'loser':''));
      return `<div class="b-team ${cls}" onclick="pickWinner('${region}',${round},${gameIdx},${ti})">
        <span class="b-seed">${t.seed||''}</span>
        <span class="b-name">${t.name||'TBD'}</span>
      </div>`;
    }).join('')}
  </div>`;
}

function pickWinner(region, round, gameIdx, teamIdx){
  const bracket = loadBracket();
  const key = `${region}_r${round}_g${gameIdx}`;

  let team;
  if(round===0){
    const teams = bracket.regions[region];
    team = teams[gameIdx*2+teamIdx];
  } else {
    const prevKey1 = `${region}_r${round-1}_g${gameIdx*2}`;
    const prevKey2 = `${region}_r${round-1}_g${gameIdx*2+1}`;
    const prev = [bracket.picks[prevKey1], bracket.picks[prevKey2]];
    team = prev[teamIdx];
  }
  if(!team||team.tbd) return;

  // Toggle: clicking same team removes pick
  if(bracket.picks[key]&&bracket.picks[key].name===team.name){
    bracket.picks[key]=null;
    // Cascade: remove any downstream picks that depended on this
    cascadeRemove(bracket, region, round, gameIdx);
  } else {
    bracket.picks[key]=team;
    // If this is round 3 (Elite 8), update Final Four
    if(round===3){
      bracket.finalFour[region]=team.name;
    }
  }
  saveBracket(bracket);
  renderBracketView();
}

function cascadeRemove(bracket, region, round, gameIdx){
  // Remove picks in subsequent rounds that had this game's winner
  const nextRound = round+1;
  const nextGame = Math.floor(gameIdx/2);
  const nextKey = `${region}_r${nextRound}_g${nextGame}`;
  if(bracket.picks[nextKey]){
    bracket.picks[nextKey]=null;
    if(nextRound===3) bracket.finalFour[region]=null;
    cascadeRemove(bracket, region, nextRound, nextGame);
  }
}

function pickChampion(region){
  const bracket = loadBracket();
  const team = bracket.finalFour[region];
  if(!team) return;
  bracket.champion = bracket.champion===team ? null : team;
  saveBracket(bracket);
  renderBracketView();
}

function resetBracket(){
  showConfirm('Reset your bracket?','This cannot be undone — all picks will be cleared.',()=>{
    localStorage.removeItem(BRACKET_KEY);
    renderBracketView();
  });
}

function setupTeamName(region, seedIdx, name){
  const bracket = loadBracket();
  bracket.regions[region][seedIdx].name = name;
  saveBracket(bracket);
}

// ═══════════════════════════════════════════════════════
// CELEBRATIONS
// ═══════════════════════════════════════════════════════
let confettiCanvas, confettiCtx, confettiParticles=[], confettiRunning=false;

function initConfetti(){
  if(confettiCanvas) return;
  confettiCanvas=document.createElement('canvas');
  confettiCanvas.className='confetti-canvas';
  confettiCanvas.id='confettiCanvas';
  document.body.appendChild(confettiCanvas);
  confettiCtx=confettiCanvas.getContext('2d');
  confettiCanvas.width=window.innerWidth;
  confettiCanvas.height=window.innerHeight;
  window.addEventListener('resize',()=>{
    if(confettiCanvas){confettiCanvas.width=window.innerWidth;confettiCanvas.height=window.innerHeight;}
  });
}

function launchConfetti(){
  initConfetti();
  confettiParticles=[];
  const colors=['#2ed573','#1e90ff','#ffa502','#ff4757','#eccc68','#a29bfe'];
  for(let i=0;i<120;i++){
    confettiParticles.push({
      x:Math.random()*confettiCanvas.width,
      y:-10,
      w:Math.random()*10+5,
      h:Math.random()*5+3,
      color:colors[Math.floor(Math.random()*colors.length)],
      rot:Math.random()*360,
      rotSpeed:(Math.random()-0.5)*8,
      vx:(Math.random()-0.5)*4,
      vy:Math.random()*4+2,
      opacity:1,
    });
  }
  if(!confettiRunning) animateConfetti();
}

function animateConfetti(){
  confettiRunning=true;
  confettiCtx.clearRect(0,0,confettiCanvas.width,confettiCanvas.height);
  confettiParticles=confettiParticles.filter(p=>p.opacity>0.05);
  confettiParticles.forEach(p=>{
    p.x+=p.vx; p.y+=p.vy; p.rot+=p.rotSpeed;
    if(p.y>confettiCanvas.height*0.7) p.opacity-=0.03;
    confettiCtx.save();
    confettiCtx.globalAlpha=p.opacity;
    confettiCtx.translate(p.x,p.y);
    confettiCtx.rotate(p.rot*Math.PI/180);
    confettiCtx.fillStyle=p.color;
    confettiCtx.fillRect(-p.w/2,-p.h/2,p.w,p.h);
    confettiCtx.restore();
  });
  if(confettiParticles.length>0) requestAnimationFrame(animateConfetti);
  else{ confettiRunning=false; confettiCtx.clearRect(0,0,confettiCanvas.width,confettiCanvas.height); }
}

function showWinToast(msg, isPush=false){
  let toast=document.getElementById('winToast');
  if(!toast){
    toast=document.createElement('div');
    toast.id='winToast';
    toast.className='win-toast';
    document.body.appendChild(toast);
  }
  toast.textContent=msg;
  toast.className='win-toast'+(isPush?' push-toast':'');
  setTimeout(()=>toast.classList.add('show'),10);
  setTimeout(()=>{ toast.classList.remove('show'); },3500);
}

function showWinCelebration(pick){
  if(pick.result==='won'){
    launchConfetti();
    const emoji = pick.type==='prop' ? '📊' : pick.type==='spread' ? '🏈' : '🎯';
    showWinToast(`${emoji} WIN! ${pick.description}`);
  } else if(pick.result==='push'){
    showWinToast(`🤝 PUSH — ${pick.description}`, true);
  }
}

// Celebrations are patched in at runtime via patchCheckPickResultsForCelebrations()

// ═══════════════════════════════════════════════════════
// CONFIDENCE SLIDER
// ═══════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════
// LOCK OF THE DAY
// One pick per calendar day can be designated as user's "Lock"
// Lock record is tracked separately on the leaderboard
// ═══════════════════════════════════════════════════════
function getTodayKey(){ return new Date().toISOString().slice(0,10); }

function getTodaysLock(){
  const today = getTodayKey();
  return picks.find(p => p.isLock && p.lockDate === today);
}

function canSetLock(pick){
  // Must be a pending, pre-game pick made today
  if(pick.result !== 'pending') return false;
  const g = allGames.find(x=>x.id===pick.gameId);
  if(g && !g.isPre) return false;
  const today = getTodayKey();
  const existing = getTodaysLock();
  // Can set if no lock today, or if this pick IS the lock (to toggle off)
  return !existing || (existing.gameId===pick.gameId && existing.type===pick.type && existing.side===pick.side);
}

function toggleLock(pickKey){
  const pick = picks.find(p=>`${p.gameId}_${p.type}_${p.side}`===pickKey);
  if(!pick) return;
  const today = getTodayKey();
  if(pick.isLock && pick.lockDate === today){
    // Remove lock
    pick.isLock = false;
    pick.lockDate = null;
  } else if(canSetLock(pick)){
    // Clear any existing lock for today first
    picks.forEach(p => { if(p.isLock && p.lockDate===today){ p.isLock=false; p.lockDate=null; } });
    pick.isLock = true;
    pick.lockDate = today;
    pick.confidence = 5; // Locks auto-get max confidence
    showWinToast('🔒 LOCK OF THE DAY set!');
  }
  savePicks();
  renderPicksPanel();
  renderScores();
  publishToLeaderboard();
}

function lockBtnHTML(pick){
  const pickKey = `${pick.gameId}_${pick.type}_${pick.side}`;
  const today = getTodayKey();
  const isLocked = pick.isLock && pick.lockDate === today;
  const canLock = canSetLock(pick);
  if(!canLock && !isLocked) return '';
  return `<button class="lock-btn ${isLocked?'locked':''}" onclick="event.stopPropagation();toggleLock('${pickKey}')">
    ${isLocked ? '🔒 LOCK OF THE DAY' : '🔓 SET AS LOCK'}
  </button>`;
}

function lockBadgeHTML(pick){
  if(!pick.isLock) return '';
  return `<span class="lock-badge"><span class="lock-badge-sm">🔒</span>LOCK</span>`;
}

function getLockRecord(){
  const lockPicks = picks.filter(p => p.isLock && p.result !== 'pending');
  const w = lockPicks.filter(p=>p.result==='won').length;
  const l = lockPicks.filter(p=>p.result==='lost').length;
  const p = lockPicks.filter(p=>p.result==='push').length;
  return {w, l, p, total: w+l+p};
}

function confidenceHTML(pickKey, currentConf=0){
  const stars = [1,2,3,4,5].map(s=>
    `<span class="conf-star ${s<=currentConf?'active':''}" onclick="setConfidence('${pickKey}',${s})" title="${s} star${s>1?'s':''}">★</span>`
  ).join('');
  return `<div class="confidence-wrap">
    <span class="confidence-label">CONFIDENCE</span>
    <div class="conf-stars" id="confStars_${pickKey}">${stars}</div>
  </div>`;
}

function setConfidence(pickKey, stars){
  // pickKey = gameId+type+side encoded
  const pick = picks.find(p=>`${p.gameId}_${p.type}_${p.side}`===pickKey);
  if(!pick) return;
  pick.confidence = pick.confidence===stars ? 0 : stars; // toggle off if same
  savePicks();
  // Update stars in DOM
  const wrap = document.getElementById(`confStars_${pickKey}`);
  if(wrap){
    wrap.querySelectorAll('.conf-star').forEach((el,i)=>{
      el.classList.toggle('active', i<pick.confidence);
    });
  }
  publishToLeaderboard();
}

// Weighted win % using confidence: 5★ = 3x weight, 4★ = 2x, 1-3★ = 1x
function weightedWinPct(userPicks){
  let weightedW=0, weightedTotal=0;
  userPicks.filter(p=>p.result==='won'||p.result==='lost').forEach(p=>{
    const w = p.confidence>=5?3 : p.confidence>=4?2 : 1;
    weightedTotal+=w;
    if(p.result==='won') weightedW+=w;
  });
  return weightedTotal>0 ? weightedW/weightedTotal : 0;
}

// ═══════════════════════════════════════════════════════
// PICK COMMENTS
// ═══════════════════════════════════════════════════════
function pickCommentHTML(pick, gameIsLocked){
  const key = `${pick.gameId}_${pick.type}_${pick.side}`;
  // Always show editable textarea for pending picks; display-only once settled
  if(pick.result==='pending'){
    return `<div class="pick-comment-wrap">
      <textarea class="pick-comment-input" rows="1" placeholder="Add a hot take… 🔥"
        onchange="savePickComment('${key}',this.value)"
        >${pick.comment||''}</textarea>
    </div>`;
  }
  if(pick.comment){
    return `<div class="pick-comment-wrap">
      <div class="pick-comment-display">${pick.comment}</div>
    </div>`;
  }
  return '';
}

function savePickComment(pickKey, text){
  const [gameId, type, ...sideParts] = pickKey.split('_');
  const side = sideParts.join('_');
  const pick = picks.find(p=>p.gameId===gameId&&p.type===type&&p.side===side);
  if(pick){ pick.comment=text.trim().slice(0,140); savePicks(); }
}

// ═══════════════════════════════════════════════════════
// PARLAY BUILDER
// ═══════════════════════════════════════════════════════
let parlayLegs = []; // [{gameId, type, side, description, odds}]
let parlayPanelOpen = false;
let parlayWager = 50; // user-adjustable bet size for the parlay

function americanToDecimal(american){
  const n = parseFloat(american);
  if(isNaN(n)) return 1.91; // default -110
  return n>0 ? (n/100)+1 : (100/Math.abs(n))+1;
}

function calcParlayOdds(legs){
  if(!legs.length) return {decimal:1, american:0, payout100:0};
  const decimal = legs.reduce((acc,l)=> acc * americanToDecimal(l.odds||'-110'), 1);
  const american = decimal>=2 ? Math.round((decimal-1)*100) : Math.round(-100/(decimal-1));
  const payout100 = Math.round((decimal-1)*100);
  return {decimal, american: american>0?`+${american}`:String(american), payout100};
}

function addToParlay(gameId, type, side, description){
  if(parlayLegs.length>=12){ showWinToast('⚠️ Max 12 legs per parlay', true); return; }
  // Prevent duplicate exact pick (same game + type + side)
  if(parlayLegs.find(l=>l.gameId===gameId&&l.type===type&&l.side===side)){
    showWinToast('⚠️ Already in parlay', true); return;
  }
  // Store date + league on each leg so we can fetch the game later for settlement
  const _g = allGames.find(x=>x.id===gameId);
  parlayLegs.push({
    gameId, type, side, description, odds:'-110',
    league: _g?.league || '',
    gameDate: selDate,
  });
  updateParlayFAB();
  renderParlayPanel();
  if(!parlayPanelOpen) openParlayPanel();
}

function removeFromParlay(idx){
  parlayLegs.splice(idx,1);
  updateParlayFAB();
  renderParlayPanel();
}

function updateParlayFAB(){
  const fab = document.getElementById('parlayFAB');
  if(!fab) return;
  fab.classList.toggle('has-picks', parlayLegs.length>0);
  const badge = document.getElementById('parlayBadge');
  if(badge) badge.textContent = parlayLegs.length;
}

function openParlayPanel(){
  parlayPanelOpen=true;
  document.getElementById('parlayPanel')?.classList.add('open');
}
function closeParlayPanel(){
  parlayPanelOpen=false;
  document.getElementById('parlayPanel')?.classList.remove('open');
}

function renderParlayPanel(){
  const el = document.getElementById('parlayLegsWrap');
  const oddsEl = document.getElementById('parlayOddsDisplay');
  const btnEl = document.getElementById('parlaySubmitBtn');
  if(!el) return;

  if(!parlayLegs.length){
    el.innerHTML=`<div class="parlay-empty">Add 2–12 picks to build a parlay</div>`;
    if(oddsEl) oddsEl.style.display='none';
    if(btnEl) btnEl.disabled=true;
    return;
  }

  el.innerHTML = parlayLegs.map((leg,i)=>`
    <div class="parlay-leg">
      <div class="parlay-leg-desc">${leg.description}</div>
      <button class="parlay-leg-remove" onclick="removeFromParlay(${i})">✕</button>
    </div>
  `).join('');

  if(parlayLegs.length>=2){
    const {american, decimal} = calcParlayOdds(parlayLegs);
    const profit = Math.round((decimal-1)*parlayWager*100)/100;
    const totalReturn = Math.round(decimal*parlayWager*100)/100;
    const balance = typeof computeBankroll==='function' ? computeBankroll() : 1000;
    const presets = [10,25,50,100,250];
    if(oddsEl){
      oddsEl.style.display='';
      oddsEl.innerHTML=`
        <div class="parlay-odds-num">${american}</div>
        <div class="parlay-odds-lbl">${parlayLegs.length}-LEG PARLAY ODDS</div>
        <div style="margin:10px 0 6px;display:flex;gap:4px;flex-wrap:wrap">
          ${presets.map(amt=>`<div
            style="flex:1;min-width:40px;padding:5px 2px;background:${parlayWager===amt?'rgba(255,215,0,.15)':'var(--bg)'};border:1px solid ${parlayWager===amt?'var(--gold)':'var(--border)'};border-radius:4px;font-family:'DM Mono',monospace;font-size:9px;color:${parlayWager===amt?'var(--gold)':'var(--muted)'};cursor:pointer;text-align:center"
            onclick="setParlayWager(${amt})">$${amt}</div>`).join('')}
          <input
            type="number" min="1" max="${Math.floor(balance)}" value="${parlayWager}"
            oninput="setParlayWager(+this.value)"
            style="flex:1;min-width:50px;background:var(--bg);border:1px solid var(--border);border-radius:4px;padding:4px 6px;color:var(--text);font-family:'DM Mono',monospace;font-size:10px;text-align:center;outline:none"
            onclick="event.stopPropagation()">
        </div>
        <div class="parlay-payout">
          Risk <strong style="color:var(--text)">$${parlayWager}</strong>
          · Win <strong style="color:#2ed573">+$${profit}</strong>
          · Return <strong style="color:var(--accent)">$${totalReturn}</strong>
        </div>`;
    }
    if(btnEl) btnEl.disabled=false;
  } else {
    if(oddsEl) oddsEl.style.display='none';
    if(btnEl) btnEl.disabled=true;
  }
}

function setParlayWager(amount){
  const balance = typeof computeBankroll==='function' ? computeBankroll() : 1000;
  parlayWager = Math.max(1, Math.min(Math.round(amount), Math.floor(balance)||1000));
  renderParlayPanel();
}

function submitParlay(){
  if(!currentUser){ alert('Enter your name first.'); return; }
  if(parlayLegs.length<2){ return; }
  const {american} = calcParlayOdds(parlayLegs);
  const desc = `${parlayLegs.length}-Leg Parlay (${american}): `+parlayLegs.map(l=>l.description).join(' + ');
  const parlayId = 'parlay_'+Date.now();
  picks.push({
    gameId: parlayId,
    type: 'parlay',
    side: 'parlay',
    description: desc,
    gameStr: parlayLegs.map(l=>l.description).join(' | '),
    result: 'pending',
    parlayLegs: parlayLegs.map(l=>({...l, gameDate: l.gameDate||selDate})),
    parlayOdds: american,
    wager: parlayWager,
    odds: american,
    league: '',
    madeAt: Date.now(),
  });
  savePicks();
  parlayLegs=[];
  updateParlayFAB();
  closeParlayPanel();
  updateRecordUI();
  renderPicksPanel();
  launchConfetti();
  showWinToast(`🎰 ${parlayLegs.length||'Multi'}-Leg Parlay placed!`);
}

// Settle parlay: all legs must win
function checkParlayResults(){
  let changed=false;

  // Build lookup of ALL cached games across ALL dates
  const allCachedGames = {};
  Object.values(cache).forEach(games=>{
    if(Array.isArray(games)) games.forEach(g=>{ allCachedGames[g.id]=g; });
  });
  allGames.forEach(g=>{ allCachedGames[g.id]=g; });

  picks.forEach(pick=>{
    if(pick.type!=='parlay'||pick.result!=='pending') return;
    const legs=pick.parlayLegs||[];
    if(!legs.length) return;

    // For each leg, try to find the game — if not in cache, kick off a background fetch
    // but don't block settlement of legs we CAN resolve
    const unloadedLegs = legs.filter(leg=>!allCachedGames[leg.gameId]);
    if(unloadedLegs.length){
      // Background-fetch missing game dates for next settlement cycle
      unloadedLegs.forEach(leg=>{
        const legLeague = leg.league || '';
        const legDate   = (leg.gameDate||'').replace(/-/g,'');
        // Try every league if leg.league is missing (old parlays)
        const leaguesToTry = legLeague
          ? [LEAGUES.find(l=>l.league===legLeague)].filter(Boolean)
          : LEAGUES;
        leaguesToTry.forEach(lg=>{
          if(!lg) return;
          // Try today and yesterday if no date stored
          const dates = legDate ? [legDate] : [
            selDate.replace(/-/g,''),
            new Date(Date.now()-86400000).toISOString().slice(0,10).replace(/-/g,''),
            new Date(Date.now()-2*86400000).toISOString().slice(0,10).replace(/-/g,''),
          ];
          dates.forEach(dt=>{
            go(`${ESPN}/${lg.sport}/${lg.league}/scoreboard?dates=${dt}`,5000)
              .then(d=>{
                if(!d) return;
                const parsed=parseGames(d,lg,lg.sport,lg.dot,lg.label);
                parsed.forEach(g=>{ allCachedGames[g.id]=g; cache[dt]=cache[dt]||[]; if(!cache[dt].find(x=>x.id===g.id)) cache[dt].push(g); });
                // Re-run settlement now that we have more data
                setTimeout(checkParlayResults, 500);
              }).catch(()=>{});
          });
        });
      });
      return; // wait for background fetch to complete
    }

    const results = legs.map(leg=>{
      const g = allCachedGames[leg.gameId];
      if(!g) return 'pending';
      if(g.isLive) return 'pending';
      if(g.isPre)  return 'pending';
      if(!g.isFinal) return 'pending';

      const hs=parseFloat(g.home.score), as2=parseFloat(g.away.score);
      if(isNaN(hs)||isNaN(as2)) return 'pending';

      if(leg.type==='spread'){
        const line=parseFloat(leg.description.split(' ').pop());
        if(isNaN(line)) return 'pending';
        const isHome=leg.side===g.home.name;
        const myScore=isHome?hs:as2, oppScore=isHome?as2:hs;
        const adj=myScore+line;
        if(Math.abs(adj-oppScore)<0.01) return 'push';
        return adj>oppScore?'won':'lost';
      } else if(leg.type==='total'){
        const total=parseFloat(leg.description.replace(/over |under /i,''));
        if(isNaN(total)) return 'pending';
        const combined=hs+as2;
        if(Math.abs(combined-total)<0.01) return 'push';
        return leg.side==='over'?(combined>total?'won':'lost'):(combined<total?'won':'lost');
      }
      return 'pending';
    });

    if(results.includes('pending')) return;
    if(results.includes('lost')){ pick.result='lost'; changed=true; }
    else if(results.every(r=>r==='push')){ pick.result='push'; changed=true; }
    else{ pick.result='won'; changed=true; }
  });

  if(changed){
    savePicks();
    checkAchievements();
    updateRecordUI();
    renderPicksPanel();
    publishToLeaderboard();
  }
}

// Manually settle a specific parlay pick using game scores from a provided results map.
// Called from the "Settle" button on stuck parlays.
async function manualSettleParlay(pickIdx){
  const pick = picks[pickIdx];
  if(!pick || pick.type!=='parlay') return;

  // Force-fetch all leg games right now across all leagues and recent dates
  const legs = pick.parlayLegs || [];
  const dates = [0,1,2,3].map(d=>new Date(Date.now()-d*86400000).toISOString().slice(0,10).replace(/-/g,''));

  showWinToast('🔄 Fetching game results…');

  await Promise.allSettled(LEAGUES.flatMap(lg=>
    dates.map(dt=>
      go(`${ESPN}/${lg.sport}/${lg.league}/scoreboard?dates=${dt}`,5000)
        .then(d=>{
          if(!d) return;
          const parsed=parseGames(d,lg,lg.sport,lg.dot,lg.label);
          parsed.forEach(g=>{ allGames.some(x=>x.id===g.id)||(allGames.push(g)); cache[dt]=cache[dt]||[]; if(!cache[dt].find(x=>x.id===g.id)) cache[dt].push(g); });
        }).catch(()=>{})
    )
  ));

  checkParlayResults();
  showWinToast('✅ Settlement check complete');
}

// ═══════════════════════════════════════════════════════
// BEST BET OF THE DAY
// ═══════════════════════════════════════════════════════
function computeBestBet(){
  // Find the game with most public picks (from pick_trends) or biggest line mover
  const pregames = allGames.filter(g=>g.isPre&&(g.odds.spread||g.odds.total));
  if(!pregames.length) return null;

  // Score each game: line movement + has odds
  let best = null, bestScore = -1;
  pregames.forEach(g=>{
    let score = 0;
    // Bonus for line movement
    const hist = oddsHistory[g.id];
    if(hist&&hist.length>1) score+=10;
    // Bonus for having both spread and total
    if(g.odds.spread&&g.odds.total) score+=5;
    // Bonus for bigger games (by league priority)
    const topLeagues=['NBA','NFL','MLB','NHL'];
    if(topLeagues.some(l=>g.leagueLabel.includes(l))) score+=3;
    if(score>bestScore){ bestScore=score; best=g; }
  });
  return best;
}

function renderBestBetCard(){
  const el=document.getElementById('bestBetWrap');
  if(!el) return;
  const g=computeBestBet();
  if(!g){ el.innerHTML=''; return; }
  const hist=oddsHistory[g.id];
  const reason=hist&&hist.length>1
    ? `Line has moved since open — sharp action detected`
    : `Top game on today's slate`;
  el.innerHTML=`<div class="best-bet-card" onclick="openGame('${g.id}')">
    <div class="best-bet-badge">⭐ BEST BET OF THE DAY <span style="color:var(--muted)">· ${g.leagueLabel}</span></div>
    <div class="best-bet-game">${g.away.name} @ ${g.home.name}</div>
    <div class="best-bet-line">${g.odds.spread||''} ${g.odds.total?'· '+g.odds.total:''}</div>
    <div class="best-bet-reason">${reason}</div>
  </div>`;
}

// ═══════════════════════════════════════════════════════
// INJURY FEED
// ═══════════════════════════════════════════════════════
let injuryCache = {};

async function fetchInjuries(){
  return cachedFetch('injuries:all', _fetchInjuriesImpl, 300000);
}
async function _fetchInjuriesImpl(){
  const outdoorLeagues=['americanfootball_nfl','baseball_mlb'];
  // ESPN injury endpoint per league
  const leagues=[
    {key:'basketball/nba',label:'NBA'},
    {key:'football/nfl',label:'NFL'},
    {key:'baseball/mlb',label:'MLB'},
    {key:'hockey/nhl',label:'NHL'},
  ];
  const injuries=[];
  await Promise.allSettled(leagues.map(async lg=>{
    try{
      const data=await go(`https://site.api.espn.com/apis/site/v2/sports/${lg.key}/injuries`,5000);
      if(!data||!data.injuries) return;
      data.injuries.slice(0,5).forEach(inj=>{
        const ath=inj.athlete||{};
        const status=inj.status||inj.type||'';
        injuries.push({
          name:ath.shortName||ath.displayName||'',
          team:inj.team?.abbreviation||'',
          status: status.toLowerCase().includes('out')?'out':
                  status.toLowerCase().includes('quest')?'questionable':'probable',
          statusLabel: status,
          league:lg.label,
        });
      });
    }catch{}
  }));
  injuryCache=injuries;
  renderInjuryFeed();
}

function renderInjuryFeed(){
  const el=document.getElementById('injuryStrip');
  if(!el||!injuryCache.length) return;
  el.innerHTML=injuryCache.slice(0,20).map(inj=>
    `<div class="injury-pill">
      <span class="injury-status ${inj.status}">${inj.statusLabel.toUpperCase().slice(0,4)}</span>
      <span class="injury-name">${inj.name}</span>
      <span style="color:var(--dim)">${inj.team}</span>
    </div>`
  ).join('');
}

// ═══════════════════════════════════════════════════════
// WEATHER FOR OUTDOOR GAMES
// ═══════════════════════════════════════════════════════
let weatherCache = {}; // gameId → {temp, wind, icon}

async function fetchWeatherForGames(){
  return cachedFetch('weather:all', _fetchWeatherImpl, 600000);
}
async function _fetchWeatherImpl(){
  const outdoorGames=allGames.filter(g=>
    g.isPre&&(g.league==='nfl'||g.league==='mlb')
  );
  await Promise.allSettled(outdoorGames.map(async g=>{
    try{
      // ESPN game summary has weather in competitions[0].weather
      const lg=LEAGUES.find(l=>l.league===g.league);
      if(!lg) return;
      const data=await go(`${ESPN}/${lg.sport}/${lg.league}/summary?event=${g.id}`,8000);
      const weather=data?.gameInfo?.weather||data?.weather;
      if(!weather) return;
      const temp=weather.temperature;
      const wind=weather.windSpeed||weather.gust;
      const cond=weather.displayValue||weather.shortDisplayName||'';
      weatherCache[g.id]={
        temp:temp?`${Math.round(temp)}°F`:'',
        wind:wind?`💨${Math.round(wind)}mph`:'',
        windSpeed:parseFloat(wind)||0,
        condition:cond,
      };
    }catch{}
  }));
}

function weatherHTML(gameId){
  const w=weatherCache[gameId];
  if(!w||(!w.temp&&!w.wind)) return '';
  const isWindy=w.windSpeed>=15;
  return `<span class="weather-pill ${isWindy?'wind-alert':''}" title="${w.condition}">
    ${w.temp} ${w.wind}${isWindy?' ⚠️':''}
  </span>`;
}

// ═══════════════════════════════════════════════════════
// HEAD-TO-HEAD RECORDS
// ═══════════════════════════════════════════════════════
async function computeH2H(myId){
  try{
    // Get all leaderboard entries to compare against
    const entries=await fetchLeaderboard();
    const others=entries.filter(e=>e.id!==myId);
    const myPicks=picks.filter(p=>p.result!=='pending');
    if(!myPicks.length||!others.length) return [];

    // For each other user, compare picks on same games
    const h2h=[];
    for(const other of others.slice(0,10)){
      const theirPicks=(other.recentPicks||[]);
      let w=0,l=0;
      myPicks.forEach(myP=>{
        const theirP=theirPicks.find(tp=>
          tp.gameId===myP.gameId&&tp.type===myP.type
        );
        if(!theirP||myP.result==='push'||theirP.result==='push') return;
        if(myP.result==='won'&&theirP.result==='lost') w++;
        else if(myP.result==='lost'&&theirP.result==='won') l++;
      });
      if(w+l>0) h2h.push({name:other.name, id:other.id, w, l});
    }
    return h2h.sort((a,b)=>(b.w+b.l)-(a.w+a.l));
  }catch(e){ return []; }
}

function renderH2HSection(h2hData){
  const el=document.getElementById('h2hSection');
  if(!el) return;
  if(!h2hData||!h2hData.length){
    el.innerHTML='';
    return;
  }
  el.innerHTML=`
    <div class="h2h-section">
      <div class="lb-subtitle" style="margin-bottom:10px">HEAD-TO-HEAD THIS SEASON</div>
      ${h2hData.map(r=>{
        const edge=r.w>r.l?'You have the edge':'They have the edge';
        return `<div class="h2h-row">
          <div class="h2h-name">${r.name}</div>
          <div class="h2h-record">${r.w}-${r.l}</div>
          <div class="h2h-edge">${edge}</div>
        </div>`;
      }).join('')}
    </div>`;
}

// ═══════════════════════════════════════════════════════
// WEEKLY RECAP
// ═══════════════════════════════════════════════════════
function getLastWeekRange(){
  const now=new Date();
  const dayOfWeek=now.getDay();
  const lastMonday=new Date(now);
  lastMonday.setDate(now.getDate()-dayOfWeek-6);
  lastMonday.setHours(0,0,0,0);
  const lastSunday=new Date(lastMonday);
  lastSunday.setDate(lastMonday.getDate()+6);
  lastSunday.setHours(23,59,59,999);
  return {start:lastMonday.getTime(), end:lastSunday.getTime()};
}

function shouldShowWeeklyRecap(){
  const lastShown=parseInt(localStorage.getItem('recap_last_shown')||'0');
  const now=Date.now();
  const lastMonday=new Date();
  lastMonday.setDate(lastMonday.getDate()-lastMonday.getDay()+1);
  lastMonday.setHours(0,0,0,0);
  // Show on Mondays if not already shown this week
  const isMonday=new Date().getDay()===1;
  return isMonday && lastShown<lastMonday.getTime();
}

function computeWeeklyRecap(){
  const {start,end}=getLastWeekRange();
  const weekPicks=picks.filter(p=>p.madeAt>=start&&p.madeAt<=end&&p.result!=='pending');
  if(!weekPicks.length) return null;
  const w=weekPicks.filter(p=>p.result==='won').length;
  const l=weekPicks.filter(p=>p.result==='lost').length;
  const pu=weekPicks.filter(p=>p.result==='push').length;
  const pct=w+l>0?Math.round(w/(w+l)*100):0;
  // Best win: highest confidence winning pick
  const bestWin=weekPicks.filter(p=>p.result==='won').sort((a,b)=>(b.confidence||0)-(a.confidence||0))[0];
  // Biggest loss
  const bigLoss=weekPicks.filter(p=>p.result==='lost')[0];
  return {w,l,pu,pct,total:weekPicks.length,bestWin,bigLoss};
}

function showWeeklyRecap(){
  const data=computeWeeklyRecap();
  if(!data) return;
  localStorage.setItem('recap_last_shown',Date.now());
  const overlay=document.createElement('div');
  overlay.className='recap-overlay';
  const weekStr=new Date().toLocaleDateString([],{month:'long',day:'numeric'});
  overlay.innerHTML=`<div class="recap-card">
    <div class="recap-title">📊 Weekly Recap</div>
    <div class="recap-sub">LAST WEEK · ${weekStr}</div>
    <div class="recap-stat-grid">
      <div class="recap-stat">
        <div class="recap-stat-num" style="color:var(--green)">${data.w}</div>
        <div class="recap-stat-lbl">WINS</div>
      </div>
      <div class="recap-stat">
        <div class="recap-stat-num" style="color:var(--red)">${data.l}</div>
        <div class="recap-stat-lbl">LOSSES</div>
      </div>
      <div class="recap-stat">
        <div class="recap-stat-num" style="color:var(--accent)">${data.pct}%</div>
        <div class="recap-stat-lbl">WIN RATE</div>
      </div>
      <div class="recap-stat">
        <div class="recap-stat-num">${data.total}</div>
        <div class="recap-stat-lbl">TOTAL PICKS</div>
      </div>
    </div>
    ${data.bestWin?`<div class="recap-highlight">
      🏆 Best pick: <strong>${data.bestWin.description}</strong>
    </div>`:''}
    ${data.bigLoss?`<div class="recap-highlight" style="background:rgba(255,71,87,.06);border-color:rgba(255,71,87,.15)">
      💔 Tough loss: <strong>${data.bigLoss.description}</strong>
    </div>`:''}
    <button class="recap-close-btn" onclick="this.closest('.recap-overlay').remove()">NICE — LET'S GO</button>
  </div>`;
  document.body.appendChild(overlay);
}

// ═══════════════════════════════════════════════════════
// BRACKET SCORING + LEADERBOARD
// ═══════════════════════════════════════════════════════
const BRACKET_ROUND_PTS=[1,2,4,8,16,32]; // R64,R32,S16,E8,F4,Champ

async function saveBracketToSupabase(){
  if(!currentUser) return;
  const bracket=loadBracket();
  if(!bracket) return;
  try{
    await sbUpsert('bracket_picks',{
      user_id:currentUser.id,
      user_name:currentUser.name,
      picks_data:JSON.stringify(bracket.picks),
      champion:bracket.champion||'',
      updated_at:Date.now(),
    });
  }catch(e){ console.warn('Bracket save failed:',e.message); }
}

async function fetchBracketLeaderboard(){
  try{
    const rows=await sbSelect('bracket_picks','select=user_id,user_name,champion,score&order=score.desc');
    return rows||[];
  }catch(e){ return []; }
}

function scoreBracket(userPicksObj, resultPicksObj){
  // resultPicksObj: same key format, value = winning team obj
  // Currently just counts picks made since actual results TBD until tournament
  let score=0;
  Object.entries(userPicksObj||{}).forEach(([key,val])=>{
    if(!val) return;
    const roundMatch=key.match(/_r(\d+)_/);
    if(!roundMatch) return;
    const round=parseInt(roundMatch[1]);
    if(resultPicksObj&&resultPicksObj[key]){
      if(resultPicksObj[key].name===val.name) score+=BRACKET_ROUND_PTS[round]||1;
    }
  });
  return score;
}

// ═══════════════════════════════════════════════════════
// HISTORICAL MATCHUP RECORDS
// ═══════════════════════════════════════════════════════
let matchupCache = {};

async function fetchMatchupHistory(game){
  if(!game) return null;
  const cacheKey=`${game.away.id}_${game.home.id}`;
  if(matchupCache[cacheKey]) return matchupCache[cacheKey];
  try{
    const lg=LEAGUES.find(l=>l.league===game.league);
    if(!lg) return null;
    const data=await go(`${ESPN}/${lg.sport}/${lg.league}/summary?event=${game.id}`,8000);
    const h2h=data?.predictor||data?.againstTheSpread||data?.teamStats;
    // ESPN head2head data is in different places per sport
    const series=data?.seasonseries||data?.record?.items;
    if(series&&series.length){
      const rec=series[0];
      const result={
        awayW: parseInt(rec.value||rec.wins||0),
        homeW: parseInt(rec.homeWins||rec.losses||0),
        label:`Last ${rec.displayValue||'matchups'}`,
      };
      matchupCache[cacheKey]=result;
      return result;
    }
  }catch{}
  return null;
}

// ═══════════════════════════════════════════════════════
// BANKROLL / FAKE MONEY SYSTEM
// ═══════════════════════════════════════════════════════
// STARTING_BANKROLL hoisted to top
// DEFAULT_WAGER hoisted to top

function bankrollKey(){ return `bankroll_${currentUser?.id||'anon'}`; }

function loadBankroll(){
  try{
    const stored = localStorage.getItem(bankrollKey());
    if(stored) return JSON.parse(stored);
  }catch{}
  return { balance: STARTING_BANKROLL };
}

function saveBankroll(br){
  localStorage.setItem(bankrollKey(), JSON.stringify(br));
}

// Compute bankroll from starting amount + all settled P&L
function computeBankroll(){
  let balance = STARTING_BANKROLL;
  picks.forEach(p=>{
    const wager = p.wager || 0;
    if(!wager) return;
    if(p.result === 'won')  balance += calcPayout(wager, p.odds || -110);
    else if(p.result === 'lost') balance -= wager;
    // push = no change, pending = not deducted yet
  });
  return Math.max(0, Math.round(balance * 100) / 100);
}

// Profit from American odds for a wager
function calcPayout(wager, americanOdds){
  const odds = parseFloat(americanOdds) || -110;
  if(odds > 0) return Math.round(wager * (odds / 100) * 100) / 100;
  return Math.round(wager * (100 / Math.abs(odds)) * 100) / 100;
}

// Total P&L across all settled picks
function totalPnL(){
  let pnl = 0;
  picks.filter(p=>p.result!=='pending'&&p.wager).forEach(p=>{
    if(p.result==='won')  pnl += calcPayout(p.wager, p.odds||-110);
    else if(p.result==='lost') pnl -= p.wager;
  });
  return Math.round(pnl * 100) / 100;
}

// Amount currently at risk in pending picks
function pendingExposure(){
  return picks.filter(p=>p.result==='pending'&&p.wager).reduce((s,p)=>s+(p.wager||0),0);
}

function updateBankrollUI(){
  const bar = document.getElementById('bankrollBar');
  const display = document.getElementById('bankrollDisplay');
  const pnl = document.getElementById('bankrollPnL');
  if(!bar||!display||!currentUser) return;

  bar.style.display = '';
  const balance = computeBankroll();
  const diff = balance - STARTING_BANKROLL;
  const pending = pendingExposure();

  display.textContent = `$${balance.toLocaleString()}`;
  display.className = 'bankroll-amount' + (diff>0?' up':diff<0?' down':'');

  const pnlStr = diff===0 ? 'EVEN' : (diff>0?'+':'')+`$${Math.abs(diff).toLocaleString()}`;
  const pendStr = pending>0 ? ` · $${pending} AT RISK` : '';
  pnl.textContent = `${pnlStr} ALL TIME${pendStr}`;
  pnl.style.color = diff>0?'#2ed573':diff<0?'#ff4757':'var(--muted)';
}

// Wager selector HTML shown under a pick once it's made
function wagerSelectorHTML(gameId, type){
  const existingPick = picks.find(p=>p.gameId===gameId&&p.type===type);
  if(!existingPick) return '';
  const wager = existingPick.wager || DEFAULT_WAGER;
  const presets = [25, 50, 100, 250];
  const profit = calcPayout(wager, existingPick.odds || -110);
  const balance = computeBankroll();

  return `<div class="wager-row" onclick="event.stopPropagation()">
    <span class="wager-label">BET</span>
    <div class="wager-presets">
      ${presets.map(amt=>
        `<div class="wager-preset ${wager===amt?'active':''}" onclick="setWager('${gameId}','${type}',${amt})">$${amt}</div>`
      ).join('')}
    </div>
    <input class="wager-custom" type="number" min="1" max="${Math.floor(balance)||STARTING_BANKROLL}" value="${wager}"
      onchange="setWager('${gameId}','${type}',+this.value)" onclick="event.stopPropagation()">
  </div>
  <div class="wager-payout">Win: <span class="win-amt">+$${profit}</span> · Risk: $${wager}</div>`;
}

function setWager(gameId, type, amount){
  const pick = picks.find(p=>p.gameId===gameId&&p.type===type);
  if(!pick) return;
  const balance = computeBankroll();
  pick.wager = Math.max(1, Math.min(Math.round(amount), Math.floor(balance)||STARTING_BANKROLL));
  savePicks();
  updateBankrollUI();
  renderScores();
}

// ── Patch checkPickResults to fire celebrations on settlement ──────
// Done at runtime after checkPickResults is defined, not at parse time
function patchCheckPickResultsForCelebrations(){
  const orig = checkPickResults;
  checkPickResults = function(){
    const before = picks.map(p=>({k:p.gameId+p.type+p.side, result:p.result}));
    orig();
    picks.forEach(p=>{
      const prev = before.find(b=>b.k===p.gameId+p.type+p.side);
      if(prev && prev.result==='pending' && p.result!=='pending'){
        showWinCelebration(p);
      }
    });
    updateBankrollUI();
  };
}


// ═══════════════════════════════════════════════════════
// TRENDS DASHBOARD
// ═══════════════════════════════════════════════════════
function renderTrendsDashboard(){
  const el = document.getElementById('trendsContent');
  if(!el) return;
  showViewLoader('trendsContent','LOADING TRENDS…');
  setTimeout(()=>{ // allow loader to paint

  // Compute personal stats from local picks
  const settled = picks.filter(p=>p.result!=='pending');
  const byType = {spread:{w:0,l:0,p:0}, total:{w:0,l:0,p:0}, prop:{w:0,l:0,p:0}, parlay:{w:0,l:0,p:0}};
  const byLeague = {};
  const byDay = {}; // 0=Sun..6=Sat
  const byResult = {won:0,lost:0,push:0};
  let totalWagered=0, totalProfit=0;

  settled.forEach(p=>{
    const t = p.type||'spread';
    if(byType[t]) {
      if(p.result==='won') byType[t].w++;
      else if(p.result==='lost') byType[t].l++;
      else byType[t].p++;
    }
    const lg = p.league||'Other';
    if(!byLeague[lg]) byLeague[lg]={w:0,l:0};
    if(p.result==='won') byLeague[lg].w++;
    else if(p.result==='lost') byLeague[lg].l++;

    const day = new Date(p.madeAt).getDay();
    if(!byDay[day]) byDay[day]={w:0,l:0};
    if(p.result==='won') byDay[day].w++;
    else if(p.result==='lost') byDay[day].l++;

    byResult[p.result]=(byResult[p.result]||0)+1;

    if(p.wager){
      totalWagered += p.wager;
      if(p.result==='won') totalProfit += calcPayout(p.wager, p.odds||-110);
      else if(p.result==='lost') totalProfit -= p.wager;
    }
  });

  const pct = (w,l) => w+l>0 ? Math.round(w/(w+l)*100) : null;
  const pctStr = (w,l) => { const p=pct(w,l); return p!==null?p+'%':'—'; };
  const pctColor = (w,l) => { const p=pct(w,l); return p===null?'':p>=55?'hot':p<=40?'cold':''; };

  const dayNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const bestDay = Object.entries(byDay)
    .filter(([,v])=>v.w+v.l>=3)
    .sort(([,a],[,b])=>pct(b.w,b.l)-pct(a.w,a.l))[0];
  const worstDay = Object.entries(byDay)
    .filter(([,v])=>v.w+v.l>=3)
    .sort(([,a],[,b])=>pct(a.w,a.l)-pct(b.w,b.l))[0];

  const leagueRows = Object.entries(byLeague)
    .filter(([,v])=>v.w+v.l>0)
    .sort(([,a],[,b])=>(b.w+b.l)-(a.w+a.l))
    .slice(0,6);

  const roi = totalWagered>0 ? Math.round(totalProfit/totalWagered*100) : 0;
  const totalDecided = byResult.won+byResult.lost;
  const overallPct = pct(byResult.won, byResult.lost);

  el.innerHTML = `
    <div class="trends-hdr">📊 Your Trends</div>
    <div style="font-family:'DM Mono',monospace;font-size:10px;color:var(--muted);letter-spacing:1px">${settled.length} SETTLED PICKS ALL TIME</div>

    <div class="trends-grid">

      <!-- Overall record -->
      <div class="trend-card">
        <div class="trend-card-title">OVERALL RECORD</div>
        <div style="display:flex;align-items:flex-end;gap:8px;margin-bottom:10px">
          <div class="trend-big-num" style="color:${overallPct>=55?'#2ed573':overallPct<=40?'#ff4757':'var(--text)'}">${byResult.won}</div>
          <div style="font-size:20px;color:var(--muted);margin-bottom:4px">-${byResult.lost}-${byResult.push}</div>
        </div>
        <div class="trend-mini-bar"><div class="trend-mini-fill" style="width:${overallPct||0}%;background:${overallPct>=55?'#2ed573':overallPct<=40?'#ff4757':'var(--accent)'}"></div></div>
        <div style="display:flex;justify-content:space-between;font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:4px">
          <span>${overallPct!==null?overallPct+'% WIN RATE':'—'}</span>
          <span>ROI ${roi>=0?'+':''}${roi}%</span>
        </div>
      </div>

      <!-- By pick type -->
      <div class="trend-card">
        <div class="trend-card-title">BY PICK TYPE</div>
        ${['spread','total','prop','parlay'].map(t=>{
          const {w,l} = byType[t];
          const p2 = pctStr(w,l);
          const c = pctColor(w,l);
          return `<div class="trend-stat-row">
            <div>
              <div class="trend-stat-label">${t.toUpperCase()}</div>
              <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--dim)">${w}-${l}</div>
            </div>
            <div class="trend-stat-val ${c}">${p2}</div>
          </div>`;
        }).join('')}
      </div>

      <!-- By league -->
      <div class="trend-card">
        <div class="trend-card-title">BY LEAGUE</div>
        ${leagueRows.length ? leagueRows.map(([lg,{w,l}])=>{
          const p2=pctStr(w,l), c=pctColor(w,l);
          const barW=pct(w,l)||0;
          return `<div class="trend-stat-row">
            <div style="flex:1">
              <div class="trend-stat-label">${lg}</div>
              <div class="trend-mini-bar" style="margin-top:3px"><div class="trend-mini-fill" style="width:${barW}%"></div></div>
            </div>
            <div style="text-align:right;margin-left:10px">
              <div class="trend-stat-val ${c}">${p2}</div>
              <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--dim)">${w}-${l}</div>
            </div>
          </div>`;
        }).join('') : '<div style="color:var(--dim);font-size:11px;padding:8px 0">No data yet — make some picks!</div>'}
      </div>

      <!-- By day of week -->
      <div class="trend-card">
        <div class="trend-card-title">BY DAY OF WEEK</div>
        <div style="display:flex;gap:4px;align-items:flex-end;height:60px;margin-bottom:8px">
          ${dayNames.map((d,i)=>{
            const {w=0,l=0} = byDay[i]||{};
            const p2=pct(w,l)||0;
            const h=Math.max(p2,4);
            const c=p2>=55?'#2ed573':p2<=40&&w+l>0?'#ff4757':'var(--accent)';
            return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px">
              <div style="width:100%;background:${c};border-radius:3px 3px 0 0;height:${h}%;opacity:${w+l>0?1:.2}"></div>
              <div style="font-family:'DM Mono',monospace;font-size:7px;color:var(--muted)">${d[0]}</div>
            </div>`;
          }).join('')}
        </div>
        ${bestDay ? `<div style="font-size:10px;color:#2ed573">🔥 Best: ${dayNames[bestDay[0]]} (${pctStr(bestDay[1].w,bestDay[1].l)})</div>` : ''}
        ${worstDay && worstDay[0]!==bestDay?.[0] ? `<div style="font-size:10px;color:#ff4757">❄️ Worst: ${dayNames[worstDay[0]]} (${pctStr(worstDay[1].w,worstDay[1].l)})</div>` : ''}
      </div>

      <!-- Bankroll chart -->
      <div class="trend-card">
        <div class="trend-card-title">BANKROLL HISTORY</div>
        ${renderMiniSparkline()}
      </div>

      <!-- Hot/cold streaks -->
      <div class="trend-card">
        <div class="trend-card-title">CURRENT FORM</div>
        ${renderStreakCard(settled)}
      </div>

    </div>`;
},0);
}

function renderMiniSparkline(){
  const wagered = picks.filter(p=>p.result!=='pending'&&p.wager).sort((a,b)=>a.madeAt-b.madeAt);
  if(wagered.length<2) return '<div style="color:var(--dim);font-size:11px">Make picks with wagers to see bankroll history</div>';
  let running = STARTING_BANKROLL;
  const points = [{y:running}];
  wagered.forEach(p=>{
    if(p.result==='won') running += calcPayout(p.wager, p.odds||-110);
    else if(p.result==='lost') running -= p.wager;
    points.push({y:Math.max(0,running)});
  });
  const min=Math.min(...points.map(p=>p.y));
  const max=Math.max(...points.map(p=>p.y));
  const range=max-min||1;
  const W=240,H=60;
  const coords = points.map((p,i)=>({
    x: i/(points.length-1)*W,
    y: H - ((p.y-min)/range)*H
  }));
  const path = coords.map((c,i)=>i===0?`M${c.x},${c.y}`:`L${c.x},${c.y}`).join(' ');
  const fillPath = path + ` L${W},${H} L0,${H} Z`;
  const lastY = points[points.length-1].y;
  const color = lastY>=STARTING_BANKROLL?'#2ed573':'#ff4757';
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:60px">
    <defs><linearGradient id="spGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${color}" stop-opacity=".3"/><stop offset="100%" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
    <path d="${fillPath}" fill="url(#spGrad)"/>
    <path d="${path}" fill="none" stroke="${color}" stroke-width="2"/>
  </svg>
  <div style="display:flex;justify-content:space-between;font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:4px">
    <span>$${STARTING_BANKROLL}</span><span style="color:${color}">$${Math.round(lastY).toLocaleString()}</span>
  </div>`;
}

function renderStreakCard(settled){
  if(!settled.length) return '<div style="color:var(--dim);font-size:11px">No settled picks yet</div>';
  const last10 = settled.slice(-10).reverse();
  const dots = last10.map(p=>{
    const c = p.result==='won'?'#2ed573':p.result==='lost'?'#ff4757':'var(--gold)';
    return `<div style="width:18px;height:18px;border-radius:50%;background:${c};display:flex;align-items:center;justify-content:center;font-size:9px">${p.result==='won'?'W':p.result==='lost'?'L':'P'}</div>`;
  }).join('');
  // Current streak
  let streak=0, streakType='';
  for(const p of settled.slice().reverse()){
    if(!streakType) streakType=p.result;
    if(p.result===streakType) streak++;
    else break;
  }
  const streakMsg = streak>=2 ? (streakType==='won'?`🔥 ${streak}-pick win streak!`:streakType==='lost'?`❄️ ${streak}-pick cold streak`:`${streak} pushes in a row`) : 'No active streak';
  return `<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px">${dots}</div>
    <div style="font-size:12px;font-weight:700">${streakMsg}</div>
    <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:4px">LAST ${last10.length} PICKS</div>`;
}

// ═══════════════════════════════════════════════════════
// PICK FEED
// ═══════════════════════════════════════════════════════
let feedTab = 'all';
let feedCache = [];

function switchFeedTab(tab){
  feedTab = tab;
  document.querySelectorAll('.feed-tab').forEach(el=>{
    el.classList.toggle('active', el.id===`feedTab${tab==='all'?'All':'League'}`);
  });
  renderPickFeed();
}

async function renderPickFeed(){
  const el = document.getElementById('feedContent');
  if(!el) return;
  el.innerHTML = '<div style="color:var(--dim);font-family:\'DM Mono\',monospace;font-size:10px;padding:16px;text-align:center">Loading feed…</div>';

  try{
    // Fetch all leaderboard entries which have recent_picks
    const entries = await fetchLeaderboard();
    const feed = [];
    entries.forEach(entry=>{
      (entry.recentPicks||[]).forEach(pk=>{
        feed.push({
          userId: entry.id,
          name: entry.name,
          ...pk,
          bankroll: entry.bankroll||1000,
        });
      });
    });
    // Sort by madeAt desc
    feed.sort((a,b)=>(b.madeAt||0)-(a.madeAt||0));
    feedCache = feed;
  }catch(e){
    // Fall back to local picks
    feedCache = picks.map(p=>({...p, userId:currentUser?.id, name:currentUser?.name||'You'}));
    feedCache.sort((a,b)=>(b.madeAt||0)-(a.madeAt||0));
  }

  renderFeedItems();
}

function renderFeedItems(){
  const el = document.getElementById('feedContent');
  if(!el) return;
  let items = feedCache;
  if(feedTab==='league' && currentUser){
    // Filter to only people in same leagues as me — simplified: just show current user + others who share a league
    // For now show all since league membership check would need extra query
    items = items.filter(p=>p.userId===currentUser.id);
  }
  if(!items.length){
    el.innerHTML = '<div style="color:var(--dim);font-family:\'DM Mono\',monospace;font-size:10px;padding:20px;text-align:center">No picks in feed yet</div>';
    return;
  }
  const isMe = id => id===currentUser?.id;
  el.innerHTML = items.slice(0,50).map(p=>{
    const ago = timeAgo(p.madeAt||0);
    const avatarClass = p.result==='won'?'settled-won':p.result==='lost'?'settled-lost':'';
    const pnl = p.result==='won'&&p.wager ? `+$${calcPayout(p.wager,p.odds||-110)}` : p.result==='lost'&&p.wager ? `-$${p.wager}` : '';
    const pnlClass = p.result==='won'?'pos':p.result==='lost'?'neg':'';
    return `<div class="feed-item">
      <div class="feed-item-top">
        <div class="feed-avatar ${avatarClass}">${(p.name||'?')[0].toUpperCase()}</div>
        <div class="feed-name">${p.name||'Anonymous'}${isMe(p.userId)?' <span style="color:var(--accent);font-size:9px">(you)</span>':''}</div>
        <div class="feed-time">${ago}</div>
      </div>
      <div class="feed-pick">${p.description||p.type||'Pick'}</div>
      ${p.comment?`<div class="feed-comment">"${p.comment}"</div>`:''}
      <div style="display:flex;align-items:center;margin-top:6px">
        <span class="feed-result-badge ${p.result||'pending'}">${(p.result||'PENDING').toUpperCase()}</span>
        ${pnl?`<span class="feed-pnl ${pnlClass}" style="margin-left:8px">${pnl}</span>`:''}
        ${p.wager&&p.result==='pending'?`<span style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-left:8px">$${p.wager} at risk</span>`:''}
        ${isMe(p.userId)?`<button class="pi-share-btn" style="margin-left:auto" onclick="sharePickCard(${JSON.stringify(p).replace(/"/g,'&quot;')})" title="Share pick">📤</button>`:''}
      </div>
    </div>`;
  }).join('');
}

function timeAgo(ts){
  if(!ts) return '';
  const s = Math.floor((Date.now()-ts)/1000);
  if(s<60) return 'just now';
  if(s<3600) return Math.floor(s/60)+'m ago';
  if(s<86400) return Math.floor(s/3600)+'h ago';
  return Math.floor(s/86400)+'d ago';
}

// ═══════════════════════════════════════════════════════
// SHAREABLE PICK CARDS
// ═══════════════════════════════════════════════════════
function sharePickCard(pick){
  const overlay = document.createElement('div');
  overlay.className = 'share-overlay';
  overlay.onclick = e => { if(e.target===overlay) overlay.remove(); };

  const canvas = document.createElement('canvas');
  const W = 640, H = 400;
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  const result = pick.result||'pending';
  const accentColor = result==='won'?'#2ed573':result==='lost'?'#ff4757':result==='push'?'#ffa502':'#00e5ff';
  const accentDark = result==='won'?'#1a8a4a':result==='lost'?'#a02a35':result==='push'?'#b87300':'#0097a7';

  // ── BACKGROUND: rich gradient with depth ──
  const bgGrad = ctx.createLinearGradient(0,0,W,H);
  bgGrad.addColorStop(0,'#080c10');
  bgGrad.addColorStop(0.5,'#0d1520');
  bgGrad.addColorStop(1,'#0a1018');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0,0,W,H);

  // ── AMBIENT GLOW: colored orb behind pick ──
  const orbGrad = ctx.createRadialGradient(480,100,0,480,100,260);
  orbGrad.addColorStop(0, accentColor+'25');
  orbGrad.addColorStop(0.5, accentColor+'08');
  orbGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = orbGrad;
  ctx.fillRect(0,0,W,H);

  // ── SCANLINES: subtle texture ──
  ctx.globalAlpha = 0.03;
  for(let y=0;y<H;y+=3){ ctx.fillStyle='#00e5ff'; ctx.fillRect(0,y,W,1); }
  ctx.globalAlpha = 1;

  // ── BORDER: gradient accent border ──
  ctx.save();
  const borderGrad = ctx.createLinearGradient(0,0,W,H);
  borderGrad.addColorStop(0, accentColor);
  borderGrad.addColorStop(0.5, accentColor+'60');
  borderGrad.addColorStop(1, accentDark);
  ctx.strokeStyle = borderGrad;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(2,2,W-4,H-4,14);
  ctx.stroke();
  ctx.restore();

  // ── Inner accent line at top ──
  const topGrad = ctx.createLinearGradient(0,0,W,0);
  topGrad.addColorStop(0,'transparent');
  topGrad.addColorStop(0.2, accentColor);
  topGrad.addColorStop(0.8, accentColor);
  topGrad.addColorStop(1,'transparent');
  ctx.strokeStyle = topGrad;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(24,3);
  ctx.lineTo(W-24,3);
  ctx.stroke();

  // ── LOGO: double chevron mark ──
  ctx.save();
  const logoGrad = ctx.createLinearGradient(24,20,60,56);
  logoGrad.addColorStop(0,'#00e5ff');
  logoGrad.addColorStop(1,'#00b8d4');
  ctx.fillStyle = logoGrad;
  // Primary chevron
  ctx.beginPath();
  ctx.moveTo(24,22); ctx.lineTo(38,36); ctx.lineTo(24,50);
  ctx.lineTo(29,50); ctx.lineTo(43,36); ctx.lineTo(29,22);
  ctx.closePath(); ctx.fill();
  // Ghost chevron
  ctx.globalAlpha = 0.4;
  ctx.beginPath();
  ctx.moveTo(34,22); ctx.lineTo(48,36); ctx.lineTo(34,50);
  ctx.lineTo(39,50); ctx.lineTo(53,36); ctx.lineTo(39,22);
  ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 1;
  // Wordmark
  ctx.fillStyle = '#00e5ff';
  ctx.font = '800 16px Syne, sans-serif';
  ctx.fillText('Sharp', 58, 41);
  ctx.fillStyle = '#e8f4f8';
  ctx.fillText('Pick', 108, 41);
  ctx.restore();

  // ── RESULT BADGE ──
  if(result!=='pending'){
    const badgeW = ctx.measureText(result.toUpperCase()).width;
    const bx = W-28-(badgeW+24);
    ctx.fillStyle = accentColor+'18';
    ctx.beginPath();
    ctx.roundRect(bx, 22, badgeW+24, 26, 6);
    ctx.fill();
    ctx.strokeStyle = accentColor+'40';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = accentColor;
    ctx.font = '700 11px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(result.toUpperCase(), bx+(badgeW+24)/2, 40);
    ctx.textAlign = 'left';
  } else {
    ctx.fillStyle = '#00e5ff18';
    ctx.beginPath();
    ctx.roundRect(W-100, 22, 72, 26, 6);
    ctx.fill();
    ctx.strokeStyle = '#00e5ff40';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = '#00e5ff';
    ctx.font = '700 11px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('PENDING', W-64, 40);
    ctx.textAlign = 'left';
  }

  // ── LEAGUE / TYPE TAG ──
  const leagueStr = (pick.league||'').toUpperCase();
  const typeStr = (pick.type||'spread').toUpperCase();
  if(leagueStr){
    ctx.fillStyle = '#1a2a3a';
    ctx.beginPath();
    ctx.roundRect(24, 64, ctx.measureText(leagueStr+'  ·  '+typeStr).width+20, 22, 4);
    ctx.fill();
    ctx.fillStyle = '#4a6070';
    ctx.font = '600 10px monospace';
    ctx.fillText(leagueStr + '  ·  ' + typeStr, 34, 79);
  }

  // ── PICK DESCRIPTION: large and bold ──
  ctx.fillStyle = '#ffffff';
  ctx.font = '800 30px Syne, sans-serif';
  const desc = pick.description||'Pick';
  const maxW = W-48;
  const words = desc.split(' ');
  var line='', pLines=[], lineH=38;
  words.forEach(function(w){
    var test=line+w+' ';
    if(ctx.measureText(test).width>maxW&&line){ pLines.push(line.trim()); line=w+' '; }
    else line=test;
  });
  pLines.push(line.trim());
  pLines.slice(0,2).forEach(function(l,i){ ctx.fillText(l, 24, 128+i*lineH); });

  // ── GAME CONTEXT ──
  const gameStr = pick.gameStr||'';
  if(gameStr){
    ctx.fillStyle = '#4a6070';
    ctx.font = '500 13px monospace';
    ctx.fillText(gameStr.slice(0,55), 24, 128+pLines.length*lineH+8);
  }

  // ── DIVIDER LINE ──
  var divY = 128+pLines.length*lineH+28;
  var divGrad = ctx.createLinearGradient(24,0,W-24,0);
  divGrad.addColorStop(0, '#1a2a3a');
  divGrad.addColorStop(0.5, accentColor+'40');
  divGrad.addColorStop(1, '#1a2a3a');
  ctx.strokeStyle = divGrad;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(24, divY);
  ctx.lineTo(W-24, divY);
  ctx.stroke();

  // ── WAGER / PAYOUT SECTION ──
  var statY = divY + 28;
  if(pick.wager){
    var profit = calcPayout(pick.wager, pick.odds||-110);
    // Wager block
    ctx.fillStyle = '#4a6070';
    ctx.font = '600 9px monospace';
    ctx.letterSpacing = '2px';
    ctx.fillText('RISKING', 24, statY);
    ctx.fillStyle = '#e8f4f8';
    ctx.font = '800 28px Syne, sans-serif';
    ctx.fillText('$'+pick.wager, 24, statY+32);

    // Payout block
    ctx.fillStyle = '#4a6070';
    ctx.font = '600 9px monospace';
    ctx.fillText('TO WIN', 180, statY);
    ctx.fillStyle = result==='won'?'#2ed573':'#00e5ff';
    ctx.font = '800 28px Syne, sans-serif';
    ctx.fillText('+$'+profit, 180, statY+32);

    // Odds block
    ctx.fillStyle = '#4a6070';
    ctx.font = '600 9px monospace';
    ctx.fillText('ODDS', 340, statY);
    ctx.fillStyle = '#e8f4f8';
    ctx.font = '800 28px Syne, sans-serif';
    ctx.fillText(String(pick.odds||-110), 340, statY+32);
  }

  // ── CONFIDENCE STARS ──
  if(pick.confidence){
    var starY = statY;
    ctx.fillStyle = '#ffd166';
    ctx.font = '18px sans-serif';
    var stars = '';
    for(var s=0;s<5;s++) stars += s<pick.confidence ? '★' : '☆';
    ctx.textAlign = 'right';
    ctx.fillText(stars, W-24, starY+12);
    ctx.textAlign = 'left';
    if(pick.isLock){
      ctx.fillStyle = '#ffd166';
      ctx.font = '700 9px monospace';
      ctx.textAlign = 'right';
      ctx.fillText('🔒 LOCK OF THE DAY', W-24, starY+28);
      ctx.textAlign = 'left';
    }
  }

  // ── COMMENT ──
  if(pick.comment){
    ctx.fillStyle = '#4a6070';
    ctx.font = 'italic 13px sans-serif';
    ctx.fillText('"'+pick.comment.slice(0,65)+'"', 24, statY+60);
  }

  // ── FOOTER: user + date ──
  ctx.fillStyle = '#1a2a3a';
  ctx.fillRect(0, H-44, W, 44);
  // Footer accent line
  var footGrad = ctx.createLinearGradient(0,0,W,0);
  footGrad.addColorStop(0, accentColor+'00');
  footGrad.addColorStop(0.3, accentColor+'60');
  footGrad.addColorStop(0.7, accentColor+'60');
  footGrad.addColorStop(1, accentColor+'00');
  ctx.strokeStyle = footGrad;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, H-44);
  ctx.lineTo(W, H-44);
  ctx.stroke();

  var userName = pick.name||currentUser?.name||'Anonymous';
  var dateStr = new Date(pick.madeAt||Date.now()).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
  ctx.fillStyle = '#4a6070';
  ctx.font = '500 11px monospace';
  ctx.fillText(userName+'  ·  '+dateStr, 24, H-18);

  // Footer logo mark (small)
  ctx.save();
  ctx.globalAlpha = 0.5;
  ctx.fillStyle = '#00e5ff';
  ctx.beginPath();
  ctx.moveTo(W-52, H-36); ctx.lineTo(W-42, H-24); ctx.lineTo(W-52, H-12);
  ctx.lineTo(W-49, H-12); ctx.lineTo(W-39, H-24); ctx.lineTo(W-49, H-36);
  ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 0.2;
  ctx.beginPath();
  ctx.moveTo(W-46, H-36); ctx.lineTo(W-36, H-24); ctx.lineTo(W-46, H-12);
  ctx.lineTo(W-43, H-12); ctx.lineTo(W-33, H-24); ctx.lineTo(W-43, H-36);
  ctx.closePath(); ctx.fill();
  ctx.restore();

  // sharppick.netlify.app text
  ctx.fillStyle = '#4a6070';
  ctx.font = '500 9px monospace';
  ctx.textAlign = 'right';
  ctx.fillText('sharppick.netlify.app', W-56, H-18);
  ctx.textAlign = 'left';

  canvas.style.borderRadius = '14px';
  canvas.style.maxWidth = '100%';

  overlay.innerHTML = '<div class="share-modal">'
    + '<div class="share-canvas-wrap" id="shareCanvasWrap"></div>'
    + '<div style="font-family:\'DM Mono\',monospace;font-size:9px;color:var(--muted);margin-bottom:12px;letter-spacing:1px">PICK CARD</div>'
    + '<div class="share-actions">'
    + '<button class="share-btn" onclick="this.closest(\'.share-overlay\').remove()">CLOSE</button>'
    + '<button class="share-btn primary" onclick="downloadPickCard()">⬇ DOWNLOAD</button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(overlay);
  document.getElementById('shareCanvasWrap').appendChild(canvas);
  window._shareCanvas = canvas;
}

function downloadPickCard(){
  if(!window._shareCanvas) return;
  const a = document.createElement('a');
  a.download = 'pick-card.png';
  a.href = window._shareCanvas.toDataURL('image/png');
  a.click();
}

// ═══════════════════════════════════════════════════════
// STEAM ALERTS
// ═══════════════════════════════════════════════════════
const STEAM_THRESHOLD = 1.5; // points of movement to trigger steam alert

function isSteaming(gameId){
  const hist = oddsHistory[gameId];
  if(!hist||hist.length<2) return false;
  const parseNum = s => { if(!s) return null; const m=s.match(/([+-]?\d+\.?\d*)\s*$/); return m?parseFloat(m[1]):null; };
  const current = parseNum(allGames.find(g=>g.id===gameId)?.odds?.spread);
  const opening = parseNum(hist[0].spread);
  if(current===null||opening===null) return false;
  return Math.abs(current-opening) >= STEAM_THRESHOLD;
}

function steamBadgeHTML(gameId){
  if(!isSteaming(gameId)) return '';
  return `<span class="steam-badge">🔥 STEAM</span>`;
}

// ═══════════════════════════════════════════════════════
// PUBLIC VS SHARP SPLIT
// ═══════════════════════════════════════════════════════
// Use our own pick_trends data as "public" and flag line movement as "sharp"
function pubSharpHTML(g){
  const t = cachedTrends[g.id];
  if(!t) return '';
  const sp = t.spread||{};
  const spTotal = Object.values(sp).reduce((a,b)=>a+b,0);
  if(spTotal<2) return '';

  const sides = Object.keys(sp);
  if(sides.length<2) return '';
  const [sideA, sideB] = sides;
  const pctA = Math.round((sp[sideA]||0)/spTotal*100);
  const pctB = 100-pctA;

  // If line moved against public favorite, flag as sharp action
  const hist = oddsHistory[g.id];
  const isSharpAlert = hist&&hist.length>1&&isSteaming(g.id);
  const publicFav = pctA>=pctB ? sideA : sideB;
  const sharpNote = isSharpAlert ? ` · ⚡ Sharp vs ${publicFav}` : '';

  return `<div class="pub-sharp-wrap">
    <div class="pub-sharp-label-row">
      <span>PUBLIC ${pctA}%</span>
      <span>${pctB}% PUBLIC${sharpNote}</span>
    </div>
    <div class="pub-sharp-bar">
      <div class="pub-sharp-public" style="width:${pctA}%"></div>
      <div class="pub-sharp-sharp" style="width:${pctB}%"></div>
    </div>
    <div class="pub-sharp-counts">
      <span class="pub-sharp-public-cnt">${sideA.split(' ').slice(-1)[0]} ${sp[sideA]||0} picks</span>
      <span class="pub-sharp-sharp-cnt">${sp[sideB]||0} picks ${sideB.split(' ').slice(-1)[0]}</span>
    </div>
  </div>`;
}

// ═══════════════════════════════════════════════════════
// DAILY PROP CHALLENGE
// ═══════════════════════════════════════════════════════
// CHALLENGE_KEY hoisted to top

function todayKey(){
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

async function loadDailyChallenge(){
  // Pick the featured prop: find a pre-game NBA/NFL game with props
  const game = allGames.find(g=>g.isPre&&(g.leagueLabel.includes('NBA')||g.leagueLabel.includes('NFL')));
  if(!game) return null;
  // Use a fixed daily challenge structure based on game + today's date
  const seed = parseInt(todayKey().replace(/-/g,''))%100;
  const playerNames = ['LeBron James','Stephen Curry','Luka Doncic','Kevin Durant','Giannis Antetokounmpo'];
  const stats = ['Points','Assists','Rebounds','3-Pointers Made'];
  const lines = [24.5, 27.5, 31.5, 8.5, 7.5, 5.5, 3.5, 2.5];
  const player = playerNames[seed%playerNames.length];
  const stat = stats[Math.floor(seed/25)%stats.length];
  const line = lines[seed%lines.length];
  return { gameId:game.id, player, stat, line, game:game.away.name+' @ '+game.home.name, league:game.leagueLabel };
}

async function renderDailyChallenge(){
  const el = document.getElementById('dailyChallengeWrap');
  if(!el) return;
  const challenge = await loadDailyChallenge();
  if(!challenge){ el.innerHTML=''; return; }

  const savedKey = `${CHALLENGE_KEY}_${todayKey()}`;
  const myPick = localStorage.getItem(savedKey);

  // Count total picks from Supabase trends (use as participant proxy)
  const totalPicks = Object.values(cachedTrends).reduce((sum,t)=>{
    return sum + Object.values(t.total||{}).reduce((a,b)=>a+b,0);
  },0);
  const participants = Math.max(totalPicks, myPick?1:0);

  el.innerHTML = `<div class="challenge-banner" onclick="event.stopPropagation()">
    <div class="challenge-badge"><span class="challenge-badge-dot"></span>DAILY CHALLENGE · ${new Date().toLocaleDateString([],{weekday:'long',month:'short',day:'numeric'})}</div>
    <div class="challenge-prop">${challenge.player}</div>
    <div class="challenge-line">${challenge.stat} O/U ${challenge.line} · ${challenge.league}</div>
    <div class="challenge-picks-row" onclick="event.stopPropagation()">
      <div class="challenge-pick-btn ${myPick==='over'?'picked-over':''}" onclick="makeDailyPick('over',${JSON.stringify(challenge).replace(/"/g,"'")})">⬆ OVER ${challenge.line}</div>
      <div class="challenge-pick-btn ${myPick==='under'?'picked-under':''}" onclick="makeDailyPick('under',${JSON.stringify(challenge).replace(/"/g,"'")})">⬇ UNDER ${challenge.line}</div>
    </div>
    <div class="challenge-participants">${participants>0?participants+' pick'+(participants!==1?'s':'')+' made today':'Be the first to pick!'}</div>
  </div>`;
}

function makeDailyPick(side, challenge){
  if(!currentUser){ alert('Enter your name to pick.'); return; }
  const savedKey = `${CHALLENGE_KEY}_${todayKey()}`;
  const existing = localStorage.getItem(savedKey);
  if(existing===side){ localStorage.removeItem(savedKey); }
  else{ localStorage.setItem(savedKey, side); }
  renderDailyChallenge();
  // Also push into regular picks system
  const desc = `${challenge.player} ${challenge.stat} ${side==='over'?'O':'U'} ${challenge.line}`;
  picks = picks.filter(p=>!p.description?.includes(challenge.player+'_challenge'));
  picks.push({
    gameId:'challenge_'+challenge.gameId+'_'+todayKey(),
    type:'prop', side,
    description: desc,
    gameStr: challenge.game,
    result:'pending',
    league: challenge.league,
    madeAt: Date.now(),
    wager: DEFAULT_WAGER, odds:-110,
  });
  savePicks();
  showWinToast(`🎯 Daily challenge pick: ${desc}`);
}



// ═══════════════════════════════════════════════════════
// LEAGUE CHAT
// ═══════════════════════════════════════════════════════
const CHAT_POLL_MS = 15000;
let chatPollTimer = null;
let chatMessages = {}; // leagueId -> [{id,user,name,text,ts,reactions}]

async function loadChatMessages(leagueId){
  clearInterval(chatPollTimer);
  try{
    const rows = await sbSelect('league_chat',
      `league_id=eq.${leagueId}&select=*&order=ts.asc&limit=80`);
    chatMessages[leagueId] = rows||[];
    renderChatMessages(leagueId);
  }catch(e){
    // Table might not exist yet — show create instructions
    const el = document.getElementById(`chatMessages-${leagueId}`);
    if(el) el.innerHTML = `<div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--dim);text-align:center;padding:10px">Run the chat SQL to enable this feature</div>`;
    return;
  }
  // Poll for new messages
  chatPollTimer = setInterval(()=>loadChatMessages(leagueId), CHAT_POLL_MS);
}

function renderChatMessages(leagueId){
  const el = document.getElementById(`chatMessages-${leagueId}`);
  if(!el) return;
  const msgs = chatMessages[leagueId]||[];
  if(!msgs.length){
    el.innerHTML = `<div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--dim);text-align:center;padding:10px">No messages yet — start the conversation!</div>`;
    return;
  }
  const REACTIONS = ['🔥','👀','💀','🤡','💰'];
  el.innerHTML = msgs.map(m=>{
    const isMe = m.user_id === currentUser?.id;
    const reactions = m.reactions||{};
    return `<div class="chat-msg">
      <div class="chat-avatar" style="${isMe?'background:var(--accent)':'background:#30363d'}">${(m.name||'?')[0].toUpperCase()}</div>
      <div class="chat-bubble">
        <div class="chat-name" style="${isMe?'color:var(--accent)':''}">${m.name||'Unknown'}</div>
        <div class="chat-text">${escapeHtml(m.text||'')}</div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px">
          <div class="chat-reactions">
            ${REACTIONS.map(r=>{
              const cnt = reactions[r]||0;
              const mine = (reactions[r+'_users']||[]).includes(currentUser?.id);
              return `<span class="chat-reaction${mine?' mine':''}" onclick="reactToMsg('${leagueId}','${m.id}','${r}')">${r}${cnt>0?` ${cnt}`:''}</span>`;
            }).join('')}
          </div>
          <div class="chat-time">${timeAgo(m.ts||0)}</div>
        </div>
      </div>
    </div>`;
  }).join('');
  // Scroll to bottom
  el.scrollTop = el.scrollHeight;
}

async function sendChatMessage(leagueId){
  if(!currentUser){ alert('Enter your name first.'); return; }
  const input = document.getElementById(`chatInput-${leagueId}`);
  const text = (input?.value||'').trim();
  if(!text) return;
  input.value = '';
  const msg = {
    league_id: leagueId,
    user_id: currentUser.id,
    name: currentUser.name,
    text,
    ts: Date.now(),
    reactions: {}
  };
  // Optimistic update
  if(!chatMessages[leagueId]) chatMessages[leagueId] = [];
  chatMessages[leagueId].push({...msg, id: 'temp_'+Date.now()});
  renderChatMessages(leagueId);
  try{ await sbUpsert('league_chat', msg); }
  catch(e){ console.warn('Chat send failed:', e?.message); }
  // Refresh to get server ID
  setTimeout(()=>loadChatMessages(leagueId), 500);
}

async function reactToMsg(leagueId, msgId, emoji){
  if(!currentUser) return;
  const msgs = chatMessages[leagueId]||[];
  const msg = msgs.find(m=>m.id===msgId);
  if(!msg) return;
  if(!msg.reactions) msg.reactions = {};
  const usersKey = emoji+'_users';
  if(!msg.reactions[usersKey]) msg.reactions[usersKey] = [];
  const idx = msg.reactions[usersKey].indexOf(currentUser.id);
  if(idx>=0){
    msg.reactions[usersKey].splice(idx,1);
    msg.reactions[emoji] = Math.max(0,(msg.reactions[emoji]||1)-1);
  } else {
    msg.reactions[usersKey].push(currentUser.id);
    msg.reactions[emoji] = (msg.reactions[emoji]||0)+1;
  }
  renderChatMessages(leagueId);
  try{ await sbUpsert('league_chat', {...msg}); }catch{}
}

function escapeHtml(str){
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ═══════════════════════════════════════════════════════
// PUSH NOTIFICATIONS
// ═══════════════════════════════════════════════════════
let pushPermission = Notification?.permission || 'default';
const PUSH_DISMISSED_KEY = 'push_prompt_dismissed';

function shouldShowPushPrompt(){
  if(pushPermission === 'granted' || pushPermission === 'denied') return false;
  if(localStorage.getItem(PUSH_DISMISSED_KEY)) return false;
  return 'Notification' in window;
}

function renderPushPrompt(){
  const existing = document.getElementById('pushPromptBanner');
  if(existing) existing.remove();
  if(!shouldShowPushPrompt()) return;

  const banner = document.createElement('div');
  banner.id = 'pushPromptBanner';
  banner.className = 'push-prompt';
  banner.innerHTML = `
    <span style="font-size:20px">🔔</span>
    <div class="push-prompt-text">
      <strong>Get notified when your picks settle</strong>
      Know the moment your parlay hits or a pick wins — no refreshing needed
    </div>
    <button class="push-enable-btn" onclick="requestPushPermission()">ENABLE</button>
    <button class="push-prompt-dismiss" onclick="dismissPushPrompt()" title="Dismiss">✕</button>`;

  // Inject below bankroll bar
  const bankrollBar = document.getElementById('bankrollBar');
  if(bankrollBar) bankrollBar.after(banner);
  else{
    const scoresView = document.getElementById('scoresView');
    if(scoresView) scoresView.prepend(banner);
  }
}

async function requestPushPermission(){
  if(!('Notification' in window)) return;
  const result = await Notification.requestPermission();
  pushPermission = result;
  document.getElementById('pushPromptBanner')?.remove();
  if(result === 'granted'){
    showWinToast('🔔 Notifications enabled! You\'ll be notified when picks settle.');
    registerServiceWorker();
  }
}

function dismissPushPrompt(){
  localStorage.setItem(PUSH_DISMISSED_KEY, '1');
  document.getElementById('pushPromptBanner')?.remove();
}

function registerServiceWorker(){
  if(!('serviceWorker' in navigator)) return;
  // Inline SW as blob since we're a single-file app
  const swCode = `
self.addEventListener('message', e => {
  if(e.data?.type === 'NOTIFY'){
    self.registration.showNotification(e.data.title, {
      body: e.data.body,
      icon: 'https://em-content.zobj.net/source/google/387/sports-medal_1f3c5.png',
      badge: 'https://em-content.zobj.net/source/google/387/sports-medal_1f3c5.png',
      tag: e.data.tag || 'pick-result',
      renotify: true
    });
  }
});`;
  const blob = new Blob([swCode], {type:'application/javascript'});
  const swUrl = URL.createObjectURL(blob);
  navigator.serviceWorker.register(swUrl).then(reg=>{
    window._swReg = reg;
    console.log('✅ Push SW registered');
  }).catch(e=>console.warn('SW register failed:', e));
}

function sendPushNotification(title, body, tag){
  if(pushPermission !== 'granted') return;
  if(window._swReg?.active){
    window._swReg.active.postMessage({type:'NOTIFY', title, body, tag});
  } else if('Notification' in window){
    new Notification(title, {body, tag});
  }
}

// Hook push into pick settlement
function notifyPickResult(pick){
  if(pushPermission !== 'granted') return;
  const result = pick.result;
  if(result === 'won'){
    const profit = pick.wager ? `+$${calcPayout(pick.wager, pick.odds||-110)}` : '';
    sendPushNotification(`✅ WIN! ${profit}`, pick.description, 'pick-won');
  } else if(result === 'lost'){
    const loss = pick.wager ? `-$${pick.wager}` : '';
    sendPushNotification(`❌ Loss ${loss}`, pick.description, 'pick-lost');
  } else if(result === 'push'){
    sendPushNotification(`↔ Push — money back`, pick.description, 'pick-push');
  }
}

// ═══════════════════════════════════════════════════════
// PROP BUILDER — browse actual game props
// ═══════════════════════════════════════════════════════
let propBuilderGameId = null;
let propBuilderProps = [];

function openPropBuilder(gameId){
  propBuilderGameId = gameId;
  const game = allGames.find(g=>g.id===gameId);
  if(!game) return;

  const overlay = document.createElement('div');
  overlay.id = 'propBuilderOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:600;display:flex;align-items:flex-end;justify-content:center;';
  overlay.onclick = e=>{ if(e.target===overlay) overlay.remove(); };

  overlay.innerHTML = `<div style="background:var(--card);border-top:1px solid var(--border);border-radius:16px 16px 0 0;width:100%;max-width:600px;max-height:80vh;overflow:hidden;display:flex;flex-direction:column;">
    <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
      <div>
        <div style="font-weight:700;font-size:14px">Prop Builder</div>
        <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:2px">${game.away.name} @ ${game.home.name}</div>
      </div>
      <button onclick="document.getElementById('propBuilderOverlay').remove()" style="background:none;border:none;color:var(--dim);font-size:18px;cursor:pointer">✕</button>
    </div>
    <div id="propBuilderContent" style="overflow-y:auto;padding:12px;flex:1;">
      <div style="font-family:'DM Mono',monospace;font-size:10px;color:var(--muted);text-align:center;padding:20px">Loading props…</div>
    </div>
  </div>`;

  document.body.appendChild(overlay);
  fetchAndRenderProps(gameId, game);
}

async function fetchAndRenderProps(gameId, game){
  const el = document.getElementById('propBuilderContent');
  if(!el) return;

  // Try to get props from ESPN odds endpoint
  const league = game.leagueKey||'nba';
  let props = [];
  try{
    // ESPN props endpoint
    const url = `https://sports.core.api.espn.com/v2/sports/basketball/leagues/${league}/events/${gameId}/competitions/${gameId}/odds`;
    const data = await go(url);
    // Parse player props if available
    const items = data?.items||[];
    items.forEach(item=>{
      (item.playerOdds||[]).forEach(po=>{
        (po.categories||[]).forEach(cat=>{
          (cat.props||[]).forEach(prop=>{
            props.push({
              player: po.athlete?.displayName||'Unknown',
              team: po.athlete?.teamAbbrev||'',
              stat: cat.name||prop.name||'Stat',
              line: prop.line,
              overOdds: prop.overOdds||prop.over,
              underOdds: prop.underOdds||prop.under,
              id: `${gameId}_${po.athlete?.id}_${prop.id||prop.name}`
            });
          });
        });
      });
    });
  }catch(e){}

  // Fallback: use synthetic props if ESPN returns nothing
  if(!props.length){
    const syntheticPlayers = [
      {player: game.away.name+' Player', stat:'Points', line: 22.5},
      {player: game.away.name+' Player', stat:'Assists', line: 5.5},
      {player: game.home.name+' Player', stat:'Points', line: 24.5},
      {player: game.home.name+' Player', stat:'Rebounds', line: 8.5},
    ];
    props = syntheticPlayers.map((p,i)=>({...p, overOdds:-115, underOdds:-105, id:`synth_${gameId}_${i}`}));
  }

  propBuilderProps = props;

  if(!props.length){
    el.innerHTML = `<div style="font-family:'DM Mono',monospace;font-size:10px;color:var(--dim);text-align:center;padding:20px">No props available for this game yet</div>`;
    return;
  }

  // Group by stat category
  const byStat = {};
  props.forEach(p=>{ if(!byStat[p.stat]) byStat[p.stat]=[]; byStat[p.stat].push(p); });

  el.innerHTML = Object.entries(byStat).map(([stat, players])=>`
    <div style="margin-bottom:16px">
      <div style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:2px;color:var(--muted);margin-bottom:8px">${stat.toUpperCase()}</div>
      <div class="prop-browse-grid">
        ${players.map(prop=>{
          const existingPick = picks.find(pk=>pk.gameId===prop.id&&pk.result==='pending');
          return `<div class="prop-browse-card">
            <div class="prop-browse-player">${prop.player}</div>
            <div class="prop-browse-stat">${prop.stat} · Line: ${prop.line} · ${prop.team}</div>
            <div class="prop-browse-btns">
              <div class="prop-browse-btn ${existingPick?.side==='over'?'picked':''}"
                onclick="makePropBuilderPick('${prop.id}','${prop.player}','${prop.stat}',${prop.line},'over','${gameId}')">
                ⬆ OVER ${prop.line}<br><span style="color:var(--dim)">${prop.overOdds||'−115'}</span>
              </div>
              <div class="prop-browse-btn ${existingPick?.side==='under'?'picked':''}"
                onclick="makePropBuilderPick('${prop.id}','${prop.player}','${prop.stat}',${prop.line},'under','${gameId}')">
                ⬇ UNDER ${prop.line}<br><span style="color:var(--dim)">${prop.underOdds||'−105'}</span>
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>`).join('');
}

function makePropBuilderPick(propId, player, stat, line, side, gameId){
  if(!currentUser){ alert('Enter your name first.'); return; }
  const game = allGames.find(g=>g.id===gameId)||{};
  // Remove existing pick for this prop
  picks = picks.filter(p=>!(p.gameId===propId&&p.result==='pending'));
  const desc = `${player} ${side==='over'?'O':'U'} ${line} ${stat}`;
  picks.push({
    gameId: propId,
    actualGameId: gameId,
    type: 'prop', side,
    description: desc,
    gameStr: `${game.away?.name||''} @ ${game.home?.name||''}`,
    result: 'pending',
    league: game.leagueLabel||'',
    madeAt: Date.now(),
    wager: DEFAULT_WAGER, odds: -110
  });
  savePicks();
  updateBankrollUI();
  showWinToast(`🎯 Picked: ${desc}`);
  // Re-render prop builder to show picked state
  const existGame = allGames.find(g=>g.id===gameId);
  if(existGame) fetchAndRenderProps(gameId, existGame);
}

// ═══════════════════════════════════════════════════════
// CLOSING LINE VALUE (CLV)
// ═══════════════════════════════════════════════════════
function calcCLV(pick){
  // CLV = did you beat the closing line?
  // We use oddsHistory: your pick vs the last odds snapshot before game started
  const hist = oddsHistory[pick.actualGameId||pick.gameId];
  if(!hist||hist.length<2) return null;
  if(pick.type!=='spread') return null;

  const opening = hist[0]?.spread;
  const closing = hist[hist.length-1]?.spread;
  if(!opening||!closing) return null;

  // Parse spread number
  const parseSpread = s=>{ const m=(s||'').match(/([+-]?\d+\.?\d*)\s*$/); return m?parseFloat(m[1]):null; };
  const closingNum = parseSpread(closing);
  if(closingNum===null) return null;

  // Pick side: if pick.side contains home team, they got home spread, else away
  // Simplified: positive CLV if the line moved in your favor after you picked
  const openNum = parseSpread(opening);
  if(openNum===null) return null;
  const movement = closingNum - openNum;
  // If you took the favorite (negative spread) and line got shorter, positive CLV
  // This is simplified — real CLV needs to know which side you took
  return movement !== 0 ? movement.toFixed(1) : null;
}

function clvBadgeHTML(pick){
  const clv = calcCLV(pick);
  if(!clv) return '';
  const pos = parseFloat(clv) > 0;
  return `<span style="font-family:'DM Mono',monospace;font-size:8px;padding:2px 5px;border-radius:3px;background:${pos?'rgba(46,213,115,.12)':'rgba(255,71,87,.1)'};color:${pos?'#2ed573':'#ff4757'};margin-left:4px" title="Closing Line Value">CLV ${pos?'+':''}${clv}</span>`;
}

// ═══════════════════════════════════════════════════════
// ONBOARDING
// ═══════════════════════════════════════════════════════
const ONBOARDED_KEY = 'livescore_onboarded_v1';

function checkOnboarding(){
  if(localStorage.getItem(ONBOARDED_KEY)) return;
  if(!currentUser) return; // wait until user sets their name
  showOnboarding();
}

function showOnboarding(){
  if(document.getElementById('onboardingModal')) return;

  const steps = [
    { icon:'<svg viewBox="0 0 80 80" width="56" height="56"><defs><linearGradient id="obLogo" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#00e5ff"/><stop offset="100%" stop-color="#00b8d4"/></linearGradient></defs><path d="M10 14 L34 40 L10 66 L20 66 L44 40 L20 14 Z" fill="url(#obLogo)"/><path d="M26 14 L50 40 L26 66 L36 66 L60 40 L36 14 Z" fill="url(#obLogo)" opacity="0.4"/></svg>', title:'Welcome to SharpPick!', body:'Pick games against real ESPN odds, track your bankroll, and compete on the leaderboard with friends.' },
    { icon:'📲', title:'Make Your Picks', body:'Tap any game card to pick the spread or total. Set your wager and add a hot take comment.' },
    { icon:'💰', title:'Manage Your Bankroll', body:'You start with $1,000. Your bankroll updates automatically as picks settle. Don\'t go broke!' },
    { icon:'🏅', title:'Compete with Friends', body:'Create or join a league with a code, then battle it out on the leaderboard. League chat lets you trash talk.' },
    { icon:'🎰', title:'Build Parlays', body:'Add 2-12 picks to a parlay for massive payouts. Tap the 🎰 button after making picks.' },
    { icon:'📊', title:'Track Your Trends', body:'The Trends tab shows your win rate by sport, day, and pick type so you can find your edge.' },
  ];

  let step = 0;

  const modal = document.createElement('div');
  modal.id = 'onboardingModal';
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:700;display:flex;align-items:center;justify-content:center;padding:20px;';

  function renderStep(){
    const s = steps[step];
    const progress = steps.map((_,i)=>`<div style="width:${i===step?20:6}px;height:6px;border-radius:3px;background:${i===step?'var(--accent)':'var(--border)'};transition:all .3s"></div>`).join('');
    modal.innerHTML = `<div style="background:var(--card);border:1px solid var(--border);border-radius:16px;padding:32px 24px;max-width:360px;width:100%;text-align:center;">
      <div style="font-size:48px;margin-bottom:16px">${s.icon}</div>
      <div style="font-size:18px;font-weight:800;margin-bottom:10px">${s.title}</div>
      <div style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:24px">${s.body}</div>
      <div style="display:flex;gap:4px;justify-content:center;margin-bottom:24px">${progress}</div>
      <div style="display:flex;gap:8px;">
        ${step>0?`<button onclick="prevOnboardStep()" style="flex:1;padding:12px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--muted);font-family:'DM Mono',monospace;font-size:10px;cursor:pointer">← BACK</button>`:''}
        <button onclick="${step<steps.length-1?'nextOnboardStep()':'finishOnboarding()'}" style="flex:2;padding:12px;border-radius:8px;border:none;background:var(--accent);color:#000;font-family:'DM Mono',monospace;font-size:11px;font-weight:700;cursor:pointer">
          ${step<steps.length-1?'NEXT →':'LET\'S GO! 🚀'}
        </button>
      </div>
      ${step===0?`<button onclick="finishOnboarding()" style="margin-top:10px;background:none;border:none;color:var(--dim);font-family:'DM Mono',monospace;font-size:9px;cursor:pointer">Skip intro</button>`:''}
    </div>`;
  }

  window.nextOnboardStep = ()=>{ step = Math.min(step+1, steps.length-1); renderStep(); };
  window.prevOnboardStep = ()=>{ step = Math.max(step-1, 0); renderStep(); };
  window.finishOnboarding = ()=>{
    localStorage.setItem(ONBOARDED_KEY, '1');
    modal.remove();
    // Show push prompt after onboarding
    setTimeout(renderPushPrompt, 1000);
  };

  renderStep();
  document.body.appendChild(modal);
}



// ═══════════════════════════════════════════════════════
// PICK SYNC — Supabase ↔ localStorage
// ═══════════════════════════════════════════════════════
let syncInProgress = false;
let lastSyncAt = 0;
const SYNC_THROTTLE_MS = 5000; // don't sync more than once per 5s

// Convert local pick → Supabase row
function pickToRow(p) {
  const userId = currentUser?.id;
  if (!userId) return null;
  // Stable ID: userId + gameId + type + side
  const id = btoa([userId, p.gameId, p.type||'', p.side||''].join('|')).replace(/[^a-zA-Z0-9]/g,'').slice(0,40);
  return {
    id,
    user_id: userId,
    game_id: p.gameId,
    actual_game_id: p.actualGameId || null,
    type: p.type || 'spread',
    side: p.side || null,
    description: p.description || null,
    game_str: p.gameStr || null,
    result: p.result || 'pending',
    league: p.league || null,
    made_at: p.madeAt || Date.now(),
    wager: p.wager || 50,
    odds: p.odds || -110,
    confidence: p.confidence || 0,
    comment: p.comment || null,
    line: p.line || null,
    player_id: p.playerId || null,
    stat_key: p.statKey || null,
    parlay_legs: p.parlayLegs ? JSON.stringify(p.parlayLegs) : null,
    parlay_odds: p.parlayOdds || null,
    settled_at: p.settledAt || null,
    updated_at: Date.now(),
  };
}

// Convert Supabase row → local pick
function rowToPick(row) {
  return {
    gameId: row.game_id,
    actualGameId: row.actual_game_id || undefined,
    type: row.type,
    side: row.side,
    description: row.description,
    gameStr: row.game_str,
    result: row.result || 'pending',
    league: row.league,
    madeAt: row.made_at,
    wager: row.wager || 50,
    odds: row.odds || -110,
    confidence: row.confidence || 0,
    comment: row.comment,
    line: row.line,
    playerId: row.player_id,
    statKey: row.stat_key,
    parlayLegs: row.parlay_legs ? (typeof row.parlay_legs === 'string' ? JSON.parse(row.parlay_legs) : row.parlay_legs) : undefined,
    parlayOdds: row.parlay_odds,
    settledAt: row.settled_at,
    _syncId: row.id, // keep server ID for updates
  };
}

// Push all local picks to Supabase (called from savePicks)
async function syncPicksToServer() {
  if (!currentUser || !supaOnline) return;
  if (syncInProgress) return;
  const now = Date.now();
  if (now - lastSyncAt < SYNC_THROTTLE_MS) return;
  lastSyncAt = now;
  syncInProgress = true;
  try {
    const rows = picks.map(pickToRow).filter(Boolean);
    if (!rows.length) { syncInProgress = false; return; }
    // Upsert in chunks of 50
    for (let i = 0; i < rows.length; i += 50) {
      await sbUpsert_batch('user_picks', rows.slice(i, i + 50));
    }
  } catch (e) {
    if (supaOnline !== false) console.warn('Pick sync to server failed:', e?.message);
  } finally {
    syncInProgress = false;
  }
}

// Batch upsert helper (sbUpsert does single rows)
async function sbUpsert_batch(table, rows) {
  const r = await sbFetch(`${SUPA_REST}/${table}`, {
    method: 'POST',
    headers: {...SUPA_HDR, 'Prefer': 'resolution=merge-duplicates,return=minimal'},
    body: JSON.stringify(rows),
  });
  if (!r.ok) {
    const txt = await r.text();
    throw new Error(`HTTP ${r.status}: ${txt}`);
  }
  markSupaOk();
}

// Pull picks from Supabase and merge with local
async function syncPicksFromServer(showIndicator = false) {
  if (!currentUser || !supaOnline) return false;
  try {
    if (showIndicator) showSyncIndicator('syncing');
    const rows = await sbSelect('user_picks',
      `user_id=eq.${currentUser.id}&select=*&order=made_at.desc&limit=500`);
    if (!rows?.length) {
      if (showIndicator) showSyncIndicator('ok');
      return false;
    }

    const serverPicks = rows.map(rowToPick);
    let merged = false;

    // Merge strategy: server wins on result, local wins on pending (client may have newer)
    serverPicks.forEach(sp => {
      const localIdx = picks.findIndex(lp =>
        lp.gameId === sp.gameId && lp.type === sp.type && lp.side === sp.side
      );
      if (localIdx === -1) {
        // New pick from server (another device)
        picks.push(sp);
        merged = true;
      } else {
        const lp = picks[localIdx];
        // Server settled a previously-pending pick → apply result
        if (lp.result === 'pending' && sp.result !== 'pending') {
          const wasSettled = picks[localIdx].result;
          picks[localIdx] = {...lp, result: sp.result, settledAt: sp.settledAt};
          merged = true;
          // Fire celebration for newly-settled pick
          if (wasSettled === 'pending') {
            showWinCelebration(picks[localIdx]);
            notifyPickResult(picks[localIdx]);
          }
        }
        // Sync comment/confidence from server if local doesn't have them
        if (!lp.comment && sp.comment) { picks[localIdx].comment = sp.comment; merged = true; }
        if (!lp.confidence && sp.confidence) { picks[localIdx].confidence = sp.confidence; merged = true; }
      }
    });

    if (merged) {
      // Save merged picks locally without triggering another server sync
      localStorage.setItem(picksKey(), JSON.stringify(picks));
      updateRecordUI();
      renderPicksPanel();
      updateBankrollUI();
      renderScores();
    }

    if (showIndicator) showSyncIndicator('ok');
    return merged;
  } catch (e) {
    if (supaOnline !== false) console.warn('Pick sync from server failed:', e?.message);
    if (showIndicator) showSyncIndicator('error');
    return false;
  }
}

// Delete a pick from server when user removes it
async function deletePickFromServer(pick) {
  if (!currentUser || !supaOnline) return;
  try {
    const row = pickToRow(pick);
    if (!row?.id) return;
    await sbFetch(`${SUPA_REST}/user_picks?id=eq.${row.id}`, {
      method: 'DELETE',
      headers: SUPA_HDR,
    });
  } catch (e) {
    if (supaOnline !== false) console.warn('Pick delete from server failed:', e?.message);
  }
}

// Sync indicator UI
function showSyncIndicator(state) {
  let el = document.getElementById('syncIndicator');
  if (!el) {
    el = document.createElement('div');
    el.id = 'syncIndicator';
    el.style.cssText = 'position:fixed;bottom:70px;right:12px;z-index:500;font-family:"DM Mono",monospace;font-size:9px;letter-spacing:1px;padding:4px 8px;border-radius:4px;transition:all .3s;pointer-events:none;';
    document.body.appendChild(el);
  }
  if (state === 'syncing') {
    el.textContent = '⟳ SYNCING';
    el.style.background = 'rgba(0,229,255,.12)';
    el.style.color = 'var(--accent)';
    el.style.opacity = '1';
  } else if (state === 'ok') {
    el.textContent = '✓ SYNCED';
    el.style.background = 'rgba(46,213,115,.12)';
    el.style.color = '#2ed573';
    el.style.opacity = '1';
    setTimeout(() => { el.style.opacity = '0'; }, 2000);
  } else {
    el.textContent = '⚠ OFFLINE';
    el.style.background = 'rgba(255,71,87,.1)';
    el.style.color = '#ff4757';
    el.style.opacity = '1';
    setTimeout(() => { el.style.opacity = '0'; }, 3000);
  }
}

// Poll server for newly-settled picks every 2 minutes
// serverSyncTimer hoisted to top
function startServerSync() {
  if (serverSyncTimer) clearInterval(serverSyncTimer);
  // Initial sync on login
  setTimeout(() => syncPicksFromServer(true), 2000);
  // Then every 2 minutes
  serverSyncTimer = setInterval(() => syncPicksFromServer(false), 120000);
}



// ═══════════════════════════════════════════════════════
// APP HERO
// ═══════════════════════════════════════════════════════
const HERO_DISMISSED_KEY = 'sharppick_hero_dismissed';
function initHero(){
  const hero = document.getElementById('appHero');
  if(!hero) return;
  if(localStorage.getItem(HERO_DISMISSED_KEY)){
    hero.style.display = 'none';
  } else {
    // Animate counters on landing page
    initLandingCounters();
  }
}
function dismissHero(){
  localStorage.setItem(HERO_DISMISSED_KEY,'1');
  const hero = document.getElementById('appHero');
  if(hero){
    hero.style.transition='opacity .4s ease, transform .4s ease';
    hero.style.opacity='0';
    hero.style.transform='translateY(-30px)';
    setTimeout(()=>hero.style.display='none',400);
  }
}
function initLandingCounters(){
  const counters = document.querySelectorAll('.lp-count');
  if(!counters.length) return;
  const observer = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        const el = entry.target;
        const target = parseInt(el.dataset.target)||0;
        const duration = 1800;
        const start = performance.now();
        function tick(now){
          const elapsed = now - start;
          const progress = Math.min(elapsed/duration, 1);
          const eased = 1 - Math.pow(1-progress, 3);
          el.textContent = Math.round(target * eased);
          if(progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        observer.unobserve(el);
      }
    });
  }, {threshold:0.3});
  counters.forEach(function(c){ observer.observe(c); });
}

// ═══════════════════════════════════════════════════════
// PUBLIC PROFILES
// ═══════════════════════════════════════════════════════
function openProfile(entry){
  if(!entry) return;
  const existing = document.getElementById('profileOverlay');
  if(existing) existing.remove();

  const isMe = entry.id === currentUser?.id;
  const decided = (entry.w||0)+(entry.l||0);
  const pct = decided>0 ? Math.round((entry.w||0)/decided*100) : 0;
  const bankroll = isMe ? computeBankroll() : (entry.bankroll||1000);
  const ratingsSnap = (isMe && typeof computeRatingsDaily==='function') ? computeRatingsDaily() : null;
  const pnl = bankroll - 1000;
  const pnlStr = (pnl>=0?'+':'')+pnl.toLocaleString();
  const pnlColor = pnl>0?'#2ed573':pnl<0?'#ff4757':'var(--muted)';

  // Build form breakdown from recentPicks
  const rp = entry.recentPicks||[];
  const byType = {spread:{w:0,l:0},total:{w:0,l:0},prop:{w:0,l:0},parlay:{w:0,l:0}};
  rp.forEach(p=>{ const t=p.type||'spread'; if(byType[t]){ if(p.result==='won') byType[t].w++; else if(p.result==='lost') byType[t].l++; }});
  const typeRows = Object.entries(byType).filter(([,v])=>v.w+v.l>0).map(([t,v])=>{
    const d=v.w+v.l; const p2=Math.round(v.w/d*100);
    return `<div class="profile-form-row"><span class="profile-form-label">${t.toUpperCase()}</span><span class="profile-form-val" style="color:${p2>=55?'#2ed573':p2<=40?'#ff4757':'var(--text)'}">${v.w}-${v.l} (${p2}%)</span></div>`;
  }).join('');

  // Recent form dots
  const form = rp.slice(-10).reverse().map(p=>`<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${p.result==='won'?'#2ed573':p.result==='lost'?'#ff4757':'var(--gold)'}"></span>`).join('');

  // H2H vs me
  const myPicks = picks.filter(p=>p.result!=='pending');
  const h2hWins = rp.filter(tp=> myPicks.some(mp=>mp.gameId===(tp.gameId||'') && mp.type===tp.type && mp.result==='won' && tp.result==='lost')).length;
  const h2hLosses = rp.filter(tp=> myPicks.some(mp=>mp.gameId===(tp.gameId||'') && mp.type===tp.type && mp.result==='lost' && tp.result==='won')).length;

  const overlay = document.createElement('div');
  overlay.id = 'profileOverlay';
  overlay.className = 'profile-overlay';
  overlay.onclick = e => { if(e.target===overlay) overlay.remove(); };

  overlay.innerHTML = `<div class="profile-sheet">
    <div class="profile-hero">
      <div class="profile-avatar-lg" style="${isMe?'background:var(--accent);color:#000':'background:#30363d'}">${(entry.name||'?')[0].toUpperCase()}</div>
      <div class="profile-name">${entry.name||'Unknown'}</div>
      <div class="profile-tagline">${isMe?'YOUR PROFILE':'PICKER PROFILE'} · ${entry.total||0} PICKS ALL TIME</div>
    </div>

    <div class="profile-stats-row">
      <div class="profile-stat">
        <div class="profile-stat-val" style="color:${pct>=55?'#2ed573':pct<=40?'#ff4757':'var(--text)'}">${pct}%</div>
        <div class="profile-stat-lbl">WIN RATE</div>
      </div>
      <div class="profile-stat">
        <div class="profile-stat-val">${entry.w||0}-${entry.l||0}</div>
        <div class="profile-stat-lbl">RECORD</div>
      </div>
      <div class="profile-stat">
        <div class="profile-stat-val" style="color:${pnlColor}">$${Math.abs(pnl).toLocaleString()}</div>
        <div class="profile-stat-lbl">${pnl>=0?'PROFIT':'DOWN'}</div>
      </div>
      <div class="profile-stat">
        <div class="profile-stat-val" style="color:${pnlColor}">$${bankroll.toLocaleString()}</div>
        <div class="profile-stat-lbl">BANKROLL</div>
      </div>
    </div>

    ${form ? `<div class="profile-section">
      <div class="profile-section-title">RECENT FORM</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap">${form}</div>
    </div>` : ''}

    ${typeRows ? `<div class="profile-section" style="padding-top:0">
      <div class="profile-section-title">BY TYPE</div>
      ${typeRows}
    </div>` : ''}

    ${!isMe && currentUser ? `<div class="profile-section" style="padding-top:0">
      <div class="profile-section-title">HEAD TO HEAD VS YOU</div>
      <div class="profile-form-row">
        <span class="profile-form-label">On same games</span>
        <span class="profile-form-val">${h2hWins>h2hLosses?'You lead':'They lead'}: ${Math.max(h2hWins,h2hLosses)}-${Math.min(h2hWins,h2hLosses)}</span>
      </div>
    </div>` : ''}

    ${!isMe && currentUser ? `<button class="profile-challenge-btn" onclick="startBattle('${entry.id}','${entry.name}');document.getElementById('profileOverlay').remove();setMode('battles')">⚔️ CHALLENGE ${entry.name.toUpperCase()} TO A BATTLE</button>` : ''}

    <div style="padding:0 16px 20px">
      <button onclick="document.getElementById('profileOverlay').remove()" style="width:100%;padding:10px;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--muted);font-family:'DM Mono',monospace;font-size:10px;cursor:pointer">CLOSE</button>
    </div>
  </div>`;

  document.body.appendChild(overlay);
}

// ═══════════════════════════════════════════════════════
// PERSONAL EDGE FINDER
// ═══════════════════════════════════════════════════════
function renderEdgeFinder(){
  // Edge finder is part of trends dashboard — called from renderTrendsDashboard
  const settled = picks.filter(p=>p.result!=='pending'&&p.result!=='push');
  const insights = [];

  // Helper
  const pct=(w,l)=>w+l>0?Math.round(w/(w+l)*100):null;
  const edge=(w,l)=>{ const p=pct(w,l); return p!==null?p-50:null; };

  // 1. Best/worst league
  const byLeague={};
  settled.forEach(p=>{
    const lg=p.league||'Other';
    if(!byLeague[lg]) byLeague[lg]={w:0,l:0};
    if(p.result==='won') byLeague[lg].w++; else byLeague[lg].l++;
  });
  const leagueEdges=Object.entries(byLeague).filter(([,v])=>v.w+v.l>=5);
  if(leagueEdges.length){
    const best=leagueEdges.sort(([,a],[,b])=>pct(b.w,b.l)-pct(a.w,a.l))[0];
    const worst=leagueEdges.sort(([,a],[,b])=>pct(a.w,a.l)-pct(b.w,b.l))[0];
    const [bl,bv]=best; const bp=pct(bv.w,bv.l);
    const [wl,wv]=worst; const wp=pct(wv.w,wv.l);
    if(bp>=55) insights.push({type:'hot',title:`🔥 Your ${bl} edge`,sub:`${bv.w}-${bv.l} record`,body:`You win ${bp}% of your ${bl} picks — significantly above average. Lean into this.`,pct:bp});
    if(wp<=40) insights.push({type:'cold',title:`❄️ Avoid ${wl}`,sub:`${wv.w}-${wv.l} record`,body:`You're only hitting ${wp}% on ${wl} picks. Consider skipping these or reducing your wager size.`,pct:wp});
  }

  // 2. Best pick type
  const byType={spread:{w:0,l:0},total:{w:0,l:0},prop:{w:0,l:0}};
  settled.forEach(p=>{ const t=p.type||'spread'; if(byType[t]){ if(p.result==='won') byType[t].w++; else byType[t].l++; }});
  const typeEdges=Object.entries(byType).filter(([,v])=>v.w+v.l>=5);
  if(typeEdges.length){
    const bestType=typeEdges.sort(([,a],[,b])=>pct(b.w,b.l)-pct(a.w,a.l))[0];
    const [bt,bv]=bestType; const bp=pct(bv.w,bv.l);
    if(bp>=55) insights.push({type:'hot',title:`💡 Stick to ${bt}s`,sub:`${bv.w}-${bv.l} on ${bt}s`,body:`You're hitting ${bp}% on ${bt} picks. This is your bread and butter.`,pct:bp});
  }

  // 3. Best day of week
  const byDay={};
  settled.forEach(p=>{
    const d=new Date(p.madeAt).getDay();
    if(!byDay[d]) byDay[d]={w:0,l:0};
    if(p.result==='won') byDay[d].w++; else byDay[d].l++;
  });
  const dayNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const dayEdges=Object.entries(byDay).filter(([,v])=>v.w+v.l>=3);
  if(dayEdges.length){
    const bestDay=dayEdges.sort(([,a],[,b])=>pct(b.w,b.l)-pct(a.w,a.l))[0];
    const [d,dv]=bestDay; const dp=pct(dv.w,dv.l);
    if(dp>=58) insights.push({type:'hot',title:`📅 ${dayNames[d]} is your day`,sub:`${dv.w}-${dv.l} on ${dayNames[d]}s`,body:`You win ${dp}% of picks made on ${dayNames[d]}. Load up your slate.`,pct:dp});
  }

  // 4. Wager sizing insight
  const bigWagers=settled.filter(p=>p.wager&&p.wager>=100);
  const smallWagers=settled.filter(p=>p.wager&&p.wager<100);
  if(bigWagers.length>=5&&smallWagers.length>=5){
    const bigPct=pct(bigWagers.filter(p=>p.result==='won').length,bigWagers.filter(p=>p.result==='lost').length);
    const smPct=pct(smallWagers.filter(p=>p.result==='won').length,smallWagers.filter(p=>p.result==='lost').length);
    if(bigPct!==null&&smPct!==null&&bigPct>smPct+10){
      insights.push({type:'hot',title:'💰 Bet bigger when confident',sub:`${bigPct}% on $100+ bets vs ${smPct}% on smaller`,body:`Your win rate on larger bets is ${bigPct-smPct} points higher. Your instincts are good when you size up.`,pct:bigPct});
    } else if(smPct!==null&&bigPct!==null&&smPct>bigPct+10){
      insights.push({type:'neutral',title:'⚠️ Shrink your big bets',sub:`Only ${bigPct}% on $100+ bets`,body:`You're actually worse on your bigger bets. Consider capping wagers at $75 until your larger picks improve.`,pct:bigPct});
    }
  }

  // 5. Tonight's games that match your edges
  const tonightGames=allGames.filter(g=>g.isPre);
  const edgeLeagues=Object.entries(byLeague).filter(([,v])=>pct(v.w,v.l)>=55).map(([lg])=>lg);
  const tonightEdge=tonightGames.filter(g=>edgeLeagues.some(lg=>g.leagueLabel?.includes(lg)));
  if(tonightEdge.length&&edgeLeagues.length){
    insights.push({type:'tonight',title:`🎯 ${tonightEdge.length} game${tonightEdge.length!==1?'s':''} in your wheelhouse tonight`,sub:tonightEdge.map(g=>`${g.away.name} @ ${g.home.name}`).join(' · ').slice(0,80),body:`Tonight has games in ${edgeLeagues.join(', ')} — leagues where you have a proven edge. Prime time to pick.`,pct:null});
  }

  if(!insights.length){
    return `<div style="color:var(--dim);font-family:'DM Mono',monospace;font-size:10px;text-align:center;padding:20px">Make at least 5 settled picks to unlock your edge analysis</div>`;
  }

  return insights.map(ins=>`<div class="edge-insight ${ins.type==='tonight'?'edge-tonight':ins.type}">
    <div class="edge-insight-title">${ins.title}</div>
    <div class="edge-insight-sub">${ins.sub}</div>
    <div class="edge-insight-body">
      ${ins.pct!==null?`<span class="edge-pct-pill ${ins.type}">${ins.pct}%</span>`:''}
      ${ins.body}
    </div>
  </div>`).join('');
}

// ═══════════════════════════════════════════════════════
// PICK BATTLES
// ═══════════════════════════════════════════════════════
const BATTLES_KEY = 'pick_battles';

function loadBattles(){
  try{ return JSON.parse(localStorage.getItem(BATTLES_KEY)||'[]'); }catch{ return []; }
}
function saveBattles(battles){
  localStorage.setItem(BATTLES_KEY, JSON.stringify(battles));
  // Sync to Supabase
  if(currentUser && supaOnline){
    sbUpsert('pick_battles', {user_id: currentUser.id, battles: battles, updated_at: Date.now()}).catch(()=>{});
  }
}

async function renderBattlesView(){
  const el = document.getElementById('battlesContent');
  if(!el) return;
  if(!currentUser){ el.innerHTML=`<div style="text-align:center;padding:30px;color:var(--muted);font-family:'DM Mono',monospace;font-size:10px">Sign in to create battles</div>`; return; }
  showViewLoader('battlesContent','LOADING BATTLES…');

  // Fetch leaderboard data to get real opponent records
  let lbEntries = [];
  try { lbEntries = await fetchLeaderboard(); } catch(e) {}
  const lbMap = {};
  lbEntries.forEach(e => { lbMap[e.id] = e; lbMap[e.name?.toLowerCase()] = e; });

  const battles = loadBattles();

  // Render new battle form
  let html = `<div class="new-battle-form">
    <div style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:2px;color:var(--muted);margin-bottom:10px">⚔️ NEW BATTLE</div>
    <input class="battle-input" id="battleOpponentName" placeholder="Opponent's display name…" list="battleNameSuggest" />
    <datalist id="battleNameSuggest">${lbEntries.filter(e=>e.id!==currentUser?.id).map(e=>`<option value="${e.name}">`).join('')}</datalist>
    <div style="display:flex;gap:6px;margin-bottom:8px">
      <select class="battle-input" id="battleDuration" style="margin:0">
        <option value="7">1 week</option>
        <option value="14">2 weeks</option>
        <option value="30">This month</option>
      </select>
      <select class="battle-input" id="battleLeague" style="margin:0">
        <option value="all">All sports</option>
        <option value="NFL">NFL only</option>
        <option value="NBA">NBA only</option>
        <option value="MLB">MLB only</option>
      </select>
    </div>
    <button class="battle-submit-btn" onclick="createBattle()">⚔️ SEND CHALLENGE</button>
  </div>`;

  if(!battles.length){
    html += `<div style="text-align:center;padding:20px;color:var(--dim);font-family:'DM Mono',monospace;font-size:10px">No active battles — challenge someone from the leaderboard!</div>`;
  } else {
    battles.forEach((b,i)=>{
      // My record during the battle window
      const myPicks = picks.filter(p=>p.result!=='pending'&&p.madeAt>=b.startAt&&(!b.league||b.league==='all'||p.league?.includes(b.league)));
      const myW = myPicks.filter(p=>p.result==='won').length;
      const myL = myPicks.filter(p=>p.result==='lost').length;

      // REAL opponent data from leaderboard
      const opp = lbMap[b.opponentId] || lbMap[b.opponentName?.toLowerCase()];
      let theirW = 0, theirL = 0, oppLinked = false;
      if(opp && opp.recentPicks) {
        // Filter opponent's recent picks to the battle window
        const oppPicks = opp.recentPicks.filter(p => p.madeAt >= b.startAt && p.result !== 'push');
        theirW = oppPicks.filter(p => p.result === 'won').length;
        theirL = oppPicks.filter(p => p.result === 'lost').length;
        oppLinked = true;
        // Update stored opponent ID for faster future lookups
        if(!b.opponentId && opp.id) { b.opponentId = opp.id; saveBattles(battles); }
      }

      const myPct = Math.round((myW+myL>0?myW/(myW+myL):0)*100);
      const theirPct = Math.round((theirW+theirL>0?theirW/(theirW+theirL):0)*100);
      const daysLeft = Math.max(0, Math.ceil((b.startAt + b.durationDays*86400000 - Date.now())/86400000));
      const ended = daysLeft===0;
      let status, statusClass;
      if(!ended){ status='ACTIVE'; statusClass='active'; }
      else if(myW>theirW){ status='YOU WON 🏆'; statusClass='won'; }
      else if(theirW>myW){ status='YOU LOST'; statusClass='lost'; }
      else{ status='TIED'; statusClass='tied'; }
      const myBarPct = Math.round((myW/Math.max(myW+theirW,1))*100);

      html += `<div class="battle-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
          <div style="font-size:11px;font-weight:700">vs ${b.opponentName}</div>
          <span class="battle-status ${statusClass}">${status}</span>
        </div>
        ${!oppLinked?`<div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--gold);padding:4px 8px;background:rgba(255,165,2,.06);border-radius:4px;margin-bottom:8px">⚠️ Opponent "${b.opponentName}" not found on the leaderboard — they need to make some picks first</div>`:''}
        <div class="battle-vs">
          <div class="battle-player">
            <div class="battle-player-name">${currentUser.name}</div>
            <div class="battle-player-rec">${myW}W-${myL}L · ${myPct}%</div>
          </div>
          <div class="battle-vs-badge">VS</div>
          <div class="battle-player">
            <div class="battle-player-name">${b.opponentName}</div>
            <div class="battle-player-rec">${theirW}W-${theirL}L · ${theirPct}%</div>
          </div>
        </div>
        <div class="battle-progress">
          <div class="battle-progress-me" style="width:${myBarPct}%"></div>
          <div class="battle-progress-them" style="width:${100-myBarPct}%"></div>
        </div>
        <div class="battle-meta">
          <span>${b.league&&b.league!=='all'?b.league+' only':'All sports'}</span>
          <span>${ended?'Ended':''+daysLeft+' day'+(daysLeft!==1?'s':'')+' left'}</span>
          <button onclick="deleteBattle(${i})" style="background:none;border:none;color:var(--dim);cursor:pointer;font-size:10px">✕ Remove</button>
        </div>
      </div>`;
    });
  }

  el.innerHTML = html;
}

function createBattle(){
  if(!currentUser){ alert('Enter your name first.'); return; }
  const name = (document.getElementById('battleOpponentName')?.value||'').trim();
  const duration = parseInt(document.getElementById('battleDuration')?.value||'7');
  const league = document.getElementById('battleLeague')?.value||'all';
  if(!name){ alert('Enter your opponent\'s name.'); return; }

  // Try to find opponent in cached leaderboard for ID linking
  let oppId = null;
  try {
    const lbStr = localStorage.getItem('lb_cache');
    if(lbStr) {
      const entries = JSON.parse(lbStr);
      const match = entries.find(e => e.name?.toLowerCase() === name.toLowerCase());
      if(match) oppId = match.id || match.user_id;
    }
  } catch(e){}

  const battles = loadBattles();
  battles.unshift({
    id: Date.now().toString(),
    opponentName: name,
    opponentId: oppId,
    durationDays: duration,
    league,
    startAt: Date.now(),
  });
  saveBattles(battles);
  renderBattlesView();
  showWinToast(`⚔️ Battle started vs ${name}! Go get 'em.`);
}

function startBattle(opponentId, opponentName){
  if(!currentUser) return;
  const battles = loadBattles();
  battles.unshift({
    id: Date.now().toString(),
    opponentName,
    opponentId,
    durationDays: 7,
    league: 'all',
    startAt: Date.now(),
    opponentW: 0, opponentL: 0,
  });
  saveBattles(battles);
  showWinToast(`⚔️ Battle started vs ${opponentName}!`);
}

function showNewBattleForm(){
  document.getElementById('battleOpponentName')?.focus();
}

function deleteBattle(idx){
  const battles = loadBattles();
  battles.splice(idx,1);
  saveBattles(battles);
  renderBattlesView();
}

// ═══════════════════════════════════════════════════════
// WEEKLY RECAP
// ═══════════════════════════════════════════════════════
function getWeeklyRecap(){
  const now = Date.now();
  const weekAgo = now - 7*86400000;
  const weekPicks = picks.filter(p=>p.madeAt>=weekAgo&&p.result!=='pending');
  if(!weekPicks.length) return null;

  const w = weekPicks.filter(p=>p.result==='won').length;
  const l = weekPicks.filter(p=>p.result==='lost').length;
  const decided = w+l;
  const pct = decided>0?Math.round(w/decided*100):0;
  const pnl = weekPicks.reduce((sum,p)=>{
    if(p.result==='won') return sum+calcPayout(p.wager||50,p.odds||-110);
    if(p.result==='lost') return sum-(p.wager||50);
    return sum;
  },0);

  // Best pick
  const bestPick = weekPicks.filter(p=>p.result==='won'&&p.wager).sort((a,b)=>
    calcPayout(b.wager||50,b.odds||-110)-calcPayout(a.wager||50,a.odds||-110))[0];

  // Best league
  const lgMap={};
  weekPicks.forEach(p=>{ const lg=p.league||'Other'; if(!lgMap[lg]) lgMap[lg]={w:0,l:0}; if(p.result==='won') lgMap[lg].w++; else lgMap[lg].l++; });
  const bestLg = Object.entries(lgMap).filter(([,v])=>v.w+v.l>=2).sort(([,a],[,b])=>(b.w/(b.w+b.l))-(a.w/(a.w+a.l)))[0];

  // Headline
  let headline;
  if(pct>=65) headline = `🔥 Scorching week — you hit ${pct}% and pocketed ${pnl>=0?'+':''}$${Math.round(pnl)}`;
  else if(pct>=50) headline = `📈 Solid week — ${w}W-${l}L, ${pnl>=0?'+':''}$${Math.round(pnl)} on the bankroll`;
  else if(pct>0) headline = `📉 Rough week — ${w}W-${l}L. Bounce back time.`;
  else headline = `No settled picks this week — get in the action!`;

  return { w, l, pct, pnl: Math.round(pnl), bestPick, bestLg: bestLg?.[0], weekPicks };
}

function renderWeeklyRecap(){
  const recap = getWeeklyRecap();
  if(!recap) return;

  // Show as a card in scoresView if it hasn't been dismissed this week
  const weekKey = `recap_dismissed_${new Date().toISOString().slice(0,10).slice(0,7)}`;
  if(localStorage.getItem(weekKey)) return;

  const wrap = document.getElementById('slateSummary');
  if(!wrap) return;

  const el = document.createElement('div');
  el.className = 'recap-card';
  el.id = 'weeklyRecapCard';
  el.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between">
      <div class="recap-week">WEEKLY RECAP · LAST 7 DAYS</div>
      <button onclick="dismissWeeklyRecap()" style="background:none;border:none;color:var(--dim);cursor:pointer;font-size:12px">✕</button>
    </div>
    <div class="recap-headline">${recap.headline||recap.w+'W-'+recap.l+'L this week'}</div>
    <div class="recap-stats">
      <div class="recap-stat-chip"><div class="recap-stat-chip-val" style="color:${recap.pct>=50?'#2ed573':'#ff4757'}">${recap.pct}%</div><div class="recap-stat-chip-lbl">WIN RATE</div></div>
      <div class="recap-stat-chip"><div class="recap-stat-chip-val">${recap.w}-${recap.l}</div><div class="recap-stat-chip-lbl">RECORD</div></div>
      <div class="recap-stat-chip"><div class="recap-stat-chip-val" style="color:${recap.pnl>=0?'#2ed573':'#ff4757'}">${recap.pnl>=0?'+':''}$${Math.abs(recap.pnl)}</div><div class="recap-stat-chip-lbl">P&L</div></div>
      ${recap.bestLg?`<div class="recap-stat-chip"><div class="recap-stat-chip-val" style="font-size:11px">${recap.bestLg}</div><div class="recap-stat-chip-lbl">BEST LEAGUE</div></div>`:''}
    </div>
    ${recap.bestPick?`<div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:8px">🏆 Best pick: ${recap.bestPick.description} (+$${calcPayout(recap.bestPick.wager||50,recap.bestPick.odds||-110)})</div>`:''}
  `;

  // Insert before scoresGrid
  const grid = document.getElementById('scoresGrid');
  if(grid) grid.before(el);
}

function dismissWeeklyRecap(){
  const weekKey = `recap_dismissed_${new Date().toISOString().slice(0,10).slice(0,7)}`;
  localStorage.setItem(weekKey,'1');
  document.getElementById('weeklyRecapCard')?.remove();
}

// Weekly recap push notification — schedule for Monday morning
function scheduleWeeklyRecapPush(){
  if(pushPermission !== 'granted') return;
  const recap = getWeeklyRecap();
  if(!recap) return;
  // Send immediately if it's Monday and we haven't sent this week
  const sentKey = `recap_push_${new Date().toISOString().slice(0,7)}`;
  if(localStorage.getItem(sentKey)) return;
  const today = new Date().getDay();
  if(today === 1){ // Monday
    localStorage.setItem(sentKey,'1');
    const msg = `${recap.w}W-${recap.l}L last week (${recap.pct}%) · ${recap.pnl>=0?'+':''}$${Math.abs(recap.pnl)} P&L`;
    sendPushNotification('📊 Your Weekly Recap', msg, 'weekly-recap');
  }
}



// ── PWA Manifest — injected via JS to avoid HTML attribute quoting issues ──
(function injectManifest() {
  const manifest = {
    name: 'SharpPick',
    short_name: 'SharpPick',
    description: "Sports pick'em with real odds and analytics",
    start_url: './',
    display: 'standalone',
    background_color: '#080c10',
    theme_color: '#00e5ff',
    orientation: 'portrait',
    icons: [{
      src: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='20' fill='%23080c10'/><text y='72' font-size='58' text-anchor='middle' x='50'>🏆</text></svg>",
      sizes: 'any',
      type: 'image/svg+xml',
      purpose: 'any maskable'
    }]
  };
  const blob = new Blob([JSON.stringify(manifest)], {type: 'application/manifest+json'});
  const url = URL.createObjectURL(blob);
  const link = document.getElementById('pwaManifest') || document.createElement('link');
  link.id = 'pwaManifest';
  link.rel = 'manifest';
  link.href = url;
  if(!link.parentNode) document.head.appendChild(link);
})();

// ── Suppress benign "message channel closed" extension errors ──────
window.addEventListener('unhandledrejection', e => {
  if(e.reason?.message?.includes('message channel closed') ||
     e.reason?.message?.includes('listener indicated')) {
    e.preventDefault(); // suppress — this is a browser extension conflict, not our bug
  }
});
// (hoisted to top)
// (hoisted to top)

function switchAuthTab(tab) {
  currentAuthTab = tab;
  // Tabs
  ['login','signup','guest'].forEach(t => {
    const key = t.charAt(0).toUpperCase() + t.slice(1);
    const tabEl = document.getElementById('authTab' + key);
    const panelEl = document.getElementById('authPanel' + key);
    if(tabEl) tabEl.classList.toggle('active', t === tab);
    if(panelEl) panelEl.style.display = (t === tab) ? 'block' : 'none';
  });
  const msg = document.getElementById('authMessage');
  if(msg) msg.style.display = 'none';
  // Focus first input in active panel
  const activePanel = document.getElementById('authPanel' + tab.charAt(0).toUpperCase() + tab.slice(1));
  if(activePanel) {
    const firstInput = activePanel.querySelector('input');
    if(firstInput) setTimeout(() => firstInput.focus(), 50);
  }
}

// Auth rate-limit guard — Supabase free tier: 3 auth requests/hour per IP
// (hoisted to top)
// (hoisted to top)
// AUTH_COOLDOWN_MS hoisted to top

function checkAuthRateLimit(errEl) {
  const now = Date.now();
  // Reset counter if >1 hour since first attempt
  if(now - _authLastAttempt > 3600000) _authAttemptCount = 0;
  if(now - _authLastAttempt < AUTH_COOLDOWN_MS) {
    const wait = Math.ceil((AUTH_COOLDOWN_MS - (now - _authLastAttempt)) / 1000);
    if(errEl) errEl.textContent = `Please wait ${wait}s before trying again.`;
    return false;
  }
  _authLastAttempt = now;
  _authAttemptCount++;
  return true;
}

function friendlyAuthError(status, data) {
  if(status === 429) return '⚠️ Too many attempts. Supabase limits auth to a few tries per hour on the free tier. Wait a few minutes, or use "Guest" mode for now.';
  if(status === 400) return data?.error_description || data?.msg || 'Invalid email or password.';
  if(status === 422) return 'Email already registered — try signing in instead.';
  if(status === 500) return 'Server error. Try again in a moment.';
  return data?.error_description || data?.msg || `Auth error (${status})`;
}

async function submitSignup() {
  try {
  const name = (document.getElementById('signupName')?.value||'').trim();
  const email = (document.getElementById('signupEmail')?.value||'').trim();
  const password = (document.getElementById('signupPassword')?.value||'').trim();
  const err = document.getElementById('signupError');
  if(!name){ err.textContent='Display name required.'; return; }
  if(!email||!email.includes('@')){ err.textContent='Valid email required.'; return; }
  if(password.length<8){ err.textContent='Password must be 8+ characters.'; return; }
  if(!checkAuthRateLimit(err)) return;
  err.textContent='';
  const btn = document.querySelector('#authPanelSignup .name-submit-btn');
  if(btn){ btn.textContent='Creating account…'; btn.disabled=true; }
  try {
    const r = await fetch(`${SUPA_AUTH}/signup`, {
      method:'POST', headers: SUPA_AUTH_HDR,
      body: JSON.stringify({ email, password, data: { display_name: name } })
    });
    const data = await r.json();
    if(!r.ok) throw new Error(friendlyAuthError(r.status, data));
    if(data.session) {
      // Signed up and immediately signed in (email confirm disabled)
      await handleAuthSession(data.session, name);
    } else if(data.user) {
      // Email confirmation required OR already registered
      if(data.user.identities?.length === 0) {
        // Email already registered — redirect to login
        const errEl = document.getElementById('signupError');
        if(errEl) errEl.textContent = 'Email already registered. Try signing in instead.';
        setTimeout(()=>switchAuthTab('login'), 2000);
      } else {
        showAuthMessage('✅ Check your email to confirm your account, then sign in!', true);
      }
    } else {
      showAuthMessage('✅ Account created! Check your email, then sign in.', true);
    }
  } catch(e) {
    const errEl = document.getElementById('signupError');
    if(errEl) errEl.textContent = e.message || 'Something went wrong. Try again.';
    console.error('Signup error:', e);
  } finally {
    const btnEl = document.querySelector('#authPanelSignup .name-submit-btn');
    if(btnEl){ btnEl.textContent='CREATE ACCOUNT →'; btnEl.disabled=false; }
  }
  } catch(outerErr) { console.error('submitSignup outer error:', outerErr); }
}

async function submitLogin() {
  const email = (document.getElementById('loginEmail')?.value||'').trim();
  const password = (document.getElementById('loginPassword')?.value||'').trim();
  const err = document.getElementById('loginError');
  if(!email){ err.textContent='Email required.'; return; }
  if(!password){ err.textContent='Password required.'; return; }
  if(!checkAuthRateLimit(err)) return;
  err.textContent='';
  const btn = document.querySelector('#authPanelLogin .name-submit-btn');
  if(btn){ btn.textContent='Signing in…'; btn.disabled=true; }
  try {
    const r = await fetch(`${SUPA_AUTH}/token?grant_type=password`, {
      method:'POST', headers: SUPA_AUTH_HDR,
      body: JSON.stringify({ email, password })
    });
    const data = await r.json();
    if(!r.ok) throw new Error(friendlyAuthError(r.status, data));
    await handleAuthSession(data, data.user?.user_metadata?.display_name);
  } catch(e) {
    const errEl = document.getElementById('loginError');
    if(errEl) errEl.textContent = e.message || 'Something went wrong. Try again.';
    console.error('Login error:', e);
  } finally {
    const btnEl = document.querySelector('#authPanelLogin .name-submit-btn');
    if(btnEl){ btnEl.textContent='SIGN IN →'; btnEl.disabled=false; }
  }
}

async function submitMagicLink() {
  const email = (document.getElementById('loginEmail')?.value||'').trim();
  const err = document.getElementById('loginError');
  if(!email||!email.includes('@')){ err.textContent='Enter your email first.'; return; }
  err.textContent='';
  try {
    const r = await fetch(`${SUPA_AUTH}/magiclink`, {
      method:'POST', headers: SUPA_AUTH_HDR,
      body: JSON.stringify({ email })
    });
    if(r.ok) {
      showAuthMessage('✅ Magic link sent! Check your email and click the link to sign in.', true);
    } else {
      const d = await r.json();
      err.textContent = d.msg || 'Failed to send magic link.';
    }
  } catch(e) {
    err.textContent = e.message;
  }
}

function submitGuest() {
  const name = (document.getElementById('guestName')?.value||'').trim();
  const err = document.getElementById('guestError');
  if(!name||name.length<2){ err.textContent='Name must be at least 2 characters.'; return; }
  // Guest mode: use localStorage UID like before, no Supabase auth
  let uid = localStorage.getItem('ls_uid');
  if(!uid){ uid='guest_'+Math.random().toString(36).slice(2)+Date.now().toString(36); localStorage.setItem('ls_uid',uid); }
  currentUser = { name, id: uid, isGuest: true };
  saveUser(currentUser);
  document.getElementById('nameModalOverlay').classList.add('hidden');
  applyUser();
}

async function handleAuthSession(session, displayName) {
  authSession = session;
  const userId = session.user?.id;
  const email = session.user?.email;
  const name = displayName || session.user?.user_metadata?.display_name || email?.split('@')[0] || 'Player';
  // Store token for API calls
  localStorage.setItem('sb_token', session.access_token);
  localStorage.setItem('sb_refresh', session.refresh_token||'');
  localStorage.setItem('sb_user_id', userId);
  // Update SUPA_HDR to use auth token
  Object.assign(SUPA_HDR, { 'Authorization': 'Bearer ' + session.access_token });
  currentUser = { name, id: userId, email, isGuest: false, verified: true };
  saveUser(currentUser);
  document.getElementById('nameModalOverlay').classList.add('hidden');
  // Show verified badge in user chip
  const chip = document.getElementById('userChip');
  if(chip) chip.title = `Signed in as ${email}`;
  applyUser();
}

function showAuthMessage(msg, success=true) {
  const el = document.getElementById('authMessage');
  if(!el) return;
  el.textContent = msg;
  el.style.display = '';
  el.style.color = success ? '#2ed573' : '#ff4757';
  // Hide all panels
  ['Login','Signup','Guest'].forEach(p => {
    const el2 = document.getElementById('authPanel'+p);
    if(el2) el2.style.display = 'none';
  });
}

async function restoreAuthSession() {
  const token = localStorage.getItem('sb_token');
  const refresh = localStorage.getItem('sb_refresh');
  if(!token) return false;

  // Quick local check: decode JWT exp without network call
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const expiry = payload.exp * 1000;
    if(Date.now() < expiry - 60000) {
      // Token still valid — use it without a network call
      Object.assign(SUPA_HDR, { 'Authorization': 'Bearer '+token });
      authSession = { access_token: token, user: { id: localStorage.getItem('sb_user_id') } };
      const savedUser = loadUser();
      if(savedUser) { currentUser = { ...savedUser, verified: true }; return true; }
      return false;
    }
  } catch(e) {
    // Bad token format — clear it
    localStorage.removeItem('sb_token');
    localStorage.removeItem('sb_refresh');
    return false;
  }

  // Token expired — try refresh (only one network call, not two)
  if(!refresh) {
    localStorage.removeItem('sb_token');
    return false;
  }
  try {
    const r = await fetch(`${SUPA_AUTH}/token?grant_type=refresh_token`, {
      method:'POST', headers: SUPA_AUTH_HDR,
      body: JSON.stringify({ refresh_token: refresh })
    });
    if(r.ok) {
      const data = await r.json();
      localStorage.setItem('sb_token', data.access_token);
      localStorage.setItem('sb_refresh', data.refresh_token||'');
      localStorage.setItem('sb_user_id', data.user?.id||'');
      Object.assign(SUPA_HDR, { 'Authorization': 'Bearer '+data.access_token });
      authSession = data;
      const savedUser = loadUser();
      if(savedUser) { currentUser = { ...savedUser, verified: true }; return true; }
      return false;
    }
  } catch(e) {}

  // Refresh failed — clear stale tokens so we don't loop
  localStorage.removeItem('sb_token');
  localStorage.removeItem('sb_refresh');
  return false;
}

async function signOut() {
  try {
    await fetch(`${SUPA_AUTH}/logout`, {
      method:'POST',
      headers: { ...SUPA_AUTH_HDR, 'Authorization': 'Bearer '+(localStorage.getItem('sb_token')||'') }
    });
  } catch(e) {}
  localStorage.removeItem('sb_token');
  localStorage.removeItem('sb_refresh');
  localStorage.removeItem('sb_user_id');
  localStorage.removeItem('ls_user');
  authSession = null;
  currentUser = null;
  picks = [];
  location.reload();
}

// Handle magic link token in URL hash
function checkAuthRedirect() {
  const hash = window.location.hash;
  if(hash.includes('access_token=')) {
    const params = new URLSearchParams(hash.replace('#',''));
    const token = params.get('access_token');
    const refresh = params.get('refresh_token');
    if(token) {
      localStorage.setItem('sb_token', token);
      if(refresh) localStorage.setItem('sb_refresh', refresh);
      // Clean URL
      history.replaceState(null,'',window.location.pathname);
      // Restore session
      restoreAuthSession().then(ok => { if(ok && currentUser) applyUser(); });
    }
  }
}

// ═══════════════════════════════════════════════════════
// WEBSOCKET LIVE SCORES
// ═══════════════════════════════════════════════════════
// (hoisted to top)
// (hoisted to top)
// (hoisted to top)
// (hoisted to top)

function startWebSocket(gameIds) {
  if(!gameIds?.length) return;
  stopWebSocket();
  wsEnabled = true;
  wsGameIds = new Set(gameIds);

  // ESPN WebSocket for live scores
  // Falls back to fast polling if WS unavailable
  try {
    // Use ESPN's streaming endpoint
    const wsUrl = `wss://streaming.espn.com/v2/subscribe?apiKey=${encodeURIComponent(SUPA_KEY)}&topics=${gameIds.map(id=>`gp_${id}`).join(',')}`;
    // ESPN WS requires auth we don't have — use SSE-style fast polling instead
    startFastPoll(gameIds);
  } catch(e) {
    startFastPoll(gameIds);
  }
}

// (hoisted to top)
function startFastPoll(gameIds) {
  clearInterval(fastPollTimer);
  if(!gameIds?.length) return;
  console.log(`⚡ Fast poll started for ${gameIds.length} live game(s) — 8s interval`);
  fastPollTimer = setInterval(async () => {
    const stillLive = allGames.filter(g=>g.isLive).map(g=>g.id);
    if(!stillLive.length) { stopFastPoll(); return; }
    // Fetch just the live games — targeted, not full date fetch
    const updates = await Promise.allSettled(
      stillLive.slice(0,3).map(gid => {
        const g = allGames.find(x=>x.id===gid);
        if(!g) return Promise.resolve(null);
        const lg = LEAGUES.find(l=>l.league===g.league);
        if(!lg) return Promise.resolve(null);
        return go(`${ESPN}/${lg.sport}/${lg.league}/scoreboard?dates=${selDate}`, 5000);
      })
    );
    let changed = false;
    updates.forEach(r => {
      if(r.status==='fulfilled' && r.value?.events) {
        r.value.events.forEach(ev => {
          const comp = ev.competitions?.[0];
          if(!comp) return;
          const gid = ev.id;
          const g = allGames.find(x=>x.id===gid);
          if(!g||!g.isLive) return;
          const home = comp.competitors?.find(c=>c.homeAway==='home');
          const away = comp.competitors?.find(c=>c.homeAway==='away');
          if(!home||!away) return;
          const newHS = parseInt(home.score)||0;
          const newAS = parseInt(away.score)||0;
          const newStatus = comp.status?.displayClock || g.statusText;
          if(g.home.score !== newHS || g.away.score !== newAS || g.statusText !== newStatus) {
            g.home.score = newHS; g.away.score = newAS; g.statusText = newStatus;
            changed = true;
          }
        });
      }
    });
    if(changed) {
      patchScores();
      checkPickResults();
      checkParlayResults();
      if(openGameId) { const g=allGames.find(x=>x.id===openGameId); if(g) updateModalScoreboard(g); }
    }
  }, 8000); // 8 second fast poll during live games
}

function stopFastPoll() {
  clearInterval(fastPollTimer);
  fastPollTimer = null;
  console.log('⏸ Fast poll stopped — no live games');
}

function stopWebSocket() {
  if(wsConnection) { try { wsConnection.close(); } catch(e){} wsConnection = null; }
  stopFastPoll();
}

// Hook into schedulePoll — when live games detected, upgrade to fast poll
function upgradePollIfLive() {
  const liveGames = allGames.filter(g=>g.isLive);
  if(liveGames.length && !fastPollTimer) {
    startFastPoll(liveGames.map(g=>g.id));
  } else if(!liveGames.length && fastPollTimer) {
    stopFastPoll();
  }
}

// ═══════════════════════════════════════════════════════
// DEEP LINKS / HASH ROUTING
// ═══════════════════════════════════════════════════════
const ROUTES = {
  '/league/:code':   (p) => { setMode('leaderboard'); switchLbTab('leagues'); setTimeout(()=>openLeague(p.code), 300); },
  '/profile/:id':    (p) => { setTimeout(()=>openProfileById(p.id), 300); },
  '/pick/:id':       (p) => { setTimeout(()=>openPickById(p.id), 300); },
  '/battle/:id':     (p) => { setMode('battles'); },
  '/scores':         ()  => { setMode('scores'); },
  '/trends':         ()  => { setMode('trends'); },
  '/history':        ()  => { setMode('history'); },
};

function parseRoute(hash) {
  const path = hash.replace('#','').replace(/^\/$/,'') || '/scores';
  for(const [pattern, handler] of Object.entries(ROUTES)) {
    const keys = [];
    const regStr = pattern.replace(/:([^/]+)/g, (_,k) => { keys.push(k); return '([^/]+)'; });
    const match = path.match(new RegExp('^'+regStr+'$'));
    if(match) {
      const params = {};
      keys.forEach((k,i) => params[k] = decodeURIComponent(match[i+1]||''));
      return { handler, params };
    }
  }
  return null;
}

function navigateTo(path) {
  history.pushState(null,'','#'+path);
  const route = parseRoute(path);
  if(route) route.handler(route.params);
}

function getShareableLink(type, id) {
  return `${window.location.origin}${window.location.pathname}#/${type}/${id}`;
}

function handleRouteChange() {
  const hash = window.location.hash;
  if(!hash || hash === '#' || hash.includes('access_token=')) return;
  const route = parseRoute(hash);
  if(route) route.handler(route.params);
}

window.addEventListener('popstate', handleRouteChange);

async function openProfileById(userId) {
  // Find in cached leaderboard
  const entries = await fetchLeaderboard();
  const entry = entries.find(e=>e.id===userId);
  if(entry) { openProfile(entry); return; }
  // Try fetching from Supabase directly
  try {
    const rows = await sbSelect('leaderboard', `user_id=eq.${userId}&select=*`);
    if(rows?.[0]) {
      const r = rows[0];
      openProfile({ id:r.user_id, name:r.name, w:r.w||0, l:r.l||0, p:r.p||0, total:r.total||0, bankroll:r.bankroll||1000, pnl:r.pnl||0, recentPicks:r.recent_picks||[] });
    }
  } catch(e) {}
}

function openPickById(pickId) {
  const pick = picks.find(p => p._syncId===pickId || (p.gameId+p.type+p.side)===pickId);
  if(pick) { sharePickCard({...pick, name:currentUser?.name}); }
}

// Shareable link helpers — add to pick cards and profiles
function copyProfileLink(userId) {
  const link = getShareableLink('profile', userId);
  navigator.clipboard.writeText(link).then(()=>showWinToast('🔗 Profile link copied!'));
}

function copyLeagueLink(code) {
  const link = getShareableLink('league', code);
  navigator.clipboard.writeText(link).then(()=>showWinToast('🔗 League link copied!'));
}

// ═══════════════════════════════════════════════════════
// SETTLEMENT AUDIT TRAIL
// ═══════════════════════════════════════════════════════
function recordSettlement(pick, finalHomeScore, finalAwayScore, method='client') {
  pick.settledAt = Date.now();
  pick.settleMethod = method; // 'client' | 'server' | 'manual'
  pick.finalScore = finalHomeScore !== undefined ? `${finalAwayScore}-${finalHomeScore}` : null;
}

function settlementAuditHTML(pick) {
  if(pick.result==='pending' || !pick.settledAt) return '';
  const time = pick.settledAt ? new Date(pick.settledAt).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}) : '';
  const method = pick.settleMethod || 'client';
  const score = pick.finalScore ? `Final: ${pick.finalScore}` : '';
  const verified = method==='server';
  return `<div class="settle-audit">
    ${time ? `<span class="settle-audit-item">🕐 ${time}</span>` : ''}
    ${score ? `<span class="settle-audit-item">📊 ${score}</span>` : ''}
    <span class="settle-audit-item ${verified?'verified':''}">
      ${verified ? '✅ Server verified' : '📱 Client settled'}
    </span>
  </div>`;
}

// Patch checkPickResults to record audit data
const _origCheckPicks = checkPickResults;
checkPickResults = function() {
  const before = picks.map(p=>({k:p.gameId+p.type+p.side, result:p.result}));
  _origCheckPicks.call(this);
  picks.forEach(p => {
    const prev = before.find(b=>b.k===p.gameId+p.type+p.side);
    if(prev?.result==='pending' && p.result!=='pending') {
      const g = allGames.find(x=>x.id===p.gameId||x.id===p.actualGameId);
      recordSettlement(p, g?.home?.score, g?.away?.score, 'client');
    }
  });
};

// ═══════════════════════════════════════════════════════
// UPDATED initUser — tries auth restore first
// ═══════════════════════════════════════════════════════
async function initUserWithAuth() {
  // 1. Check for magic link / OAuth redirect in URL
  checkAuthRedirect();

  // 2. Try to restore Supabase session
  const restored = await restoreAuthSession();
  if(restored && currentUser) {
    picks = loadPicks();
    applyUser();
    document.getElementById('nameModalOverlay').classList.add('hidden');
    return;
  }

  // 3. Fall back to saved guest/local user
  const u = loadUser();
  if(u && u.name) {
    currentUser = u;
    picks = loadPicks();
    applyUser();
    document.getElementById('nameModalOverlay').classList.add('hidden');
    return;
  }

  // 4. Show auth modal — default to signup for new users
  switchAuthTab('signup');
  setTimeout(()=>{ document.getElementById('signupName')?.focus(); }, 100);
}



// ═══════════════════════════════════════════════════════
// USER MENU DROPDOWN (replaces promptRename click)
// ═══════════════════════════════════════════════════════
function showUserMenu() {
  const existing = document.getElementById('userMenuDropdown');
  if(existing) { existing.remove(); return; }

  const chip = document.getElementById('userChip');
  if(!chip) return;
  const rect = chip.getBoundingClientRect();

  const menu = document.createElement('div');
  menu.id = 'userMenuDropdown';
  menu.style.cssText = `position:fixed;top:${rect.bottom+6}px;right:${window.innerWidth-rect.right}px;
    background:var(--card);border:1px solid var(--border);border-radius:10px;
    min-width:180px;z-index:400;box-shadow:0 8px 32px rgba(0,0,0,.4);overflow:hidden;`;

  const isGuest = currentUser?.isGuest;
  const isVerified = currentUser?.verified;

  menu.innerHTML = `
    <div style="padding:10px 14px;border-bottom:1px solid var(--border);">
      <div style="font-weight:700;font-size:12px">${currentUser?.name||'Player'}</div>
      <div style="font-family:'DM Mono',monospace;font-size:8px;color:${isGuest?'var(--gold)':isVerified?'#2ed573':'var(--muted)'};margin-top:2px">
        ${isGuest?'⚠️ GUEST MODE':isVerified?'✅ VERIFIED ACCOUNT':'LOCAL ACCOUNT'}
      </div>
      ${currentUser?.email?`<div style="font-size:9px;color:var(--dim);margin-top:2px">${currentUser.email}</div>`:''}
    </div>
    <div style="padding:6px 0;">
      ${isGuest?`<button class="user-menu-item" onclick="userMenuAction('upgrade')">🔐 Create Account</button>`:''}
      <button class="user-menu-item" onclick="userMenuAction('rename')">✏️ Change Display Name</button>
      <button class="user-menu-item" onclick="userMenuAction('profile')">👤 My Profile</button>
      <button class="user-menu-item" onclick="userMenuAction('copyProfile')">🔗 Copy Profile Link</button>
    </div>
    <div style="padding:6px 0;border-top:1px solid var(--border);">
      <button class="user-menu-item" onclick="userMenuAction('signout')" style="color:#ff4757">
        ${isGuest?'🚪 Clear Data':'🚪 Sign Out'}
      </button>
    </div>`;

  document.body.appendChild(menu);

  // Close on outside click
  setTimeout(()=>{
    document.addEventListener('click', function handler(e){
      if(!menu.contains(e.target) && !chip.contains(e.target)){
        menu.remove();
        document.removeEventListener('click', handler);
      }
    });
  }, 10);
}

function userMenuAction(action) {
  document.getElementById('userMenuDropdown')?.remove();
  switch(action) {
    case 'rename':
      const newName = prompt('Change your display name:', currentUser?.name||'');
      if(!newName?.trim()) return;
      const name = newName.trim().slice(0,24);
      currentUser = {...currentUser, name};
      saveUser(currentUser);
      applyUser();
      publishToLeaderboard();
      showWinToast('✅ Name updated!');
      break;
    case 'profile':
      if(currentUser) {
        const myEntry = {
          id: currentUser.id,
          name: currentUser.name,
          w: picks.filter(p=>p.result==='won').length,
          l: picks.filter(p=>p.result==='lost').length,
          p: picks.filter(p=>p.result==='push').length,
          total: picks.length,
          bankroll: computeBankroll(),
          pnl: totalPnL(),
          recentPicks: picks.filter(p=>p.result!=='pending').slice(-20).map(p=>({result:p.result,type:p.type,madeAt:p.madeAt})),
        };
        openProfile(myEntry);
      }
      break;
    case 'copyProfile':
      if(currentUser) copyProfileLink(currentUser.id);
      break;
    case 'upgrade':
      // Show auth modal in signup tab
      document.getElementById('nameModalOverlay')?.classList.remove('hidden');
      switchAuthTab('signup');
      break;
    case 'signout':
      showConfirm(currentUser?.isGuest?'Clear all data?':'Sign out?',currentUser?.isGuest?'This cannot be undone.':'You can sign back in anytime.',()=>{
        if(typeof signOut==='function') signOut();
        else { localStorage.clear(); location.reload(); }
      });
      break;
  }
}

// CSS for user menu
(function() {
  const style = document.createElement('style');
  style.textContent = `.user-menu-item{display:block;width:100%;padding:9px 14px;background:none;border:none;color:var(--text);font-size:12px;text-align:left;cursor:pointer;transition:background .1s;}.user-menu-item:hover{background:rgba(255,255,255,.04);}`;
  document.head.appendChild(style);
})();


// ═══════════════════════════════════════════════════════
// UX HELPERS — replaces alert() and confirm()
// ═══════════════════════════════════════════════════════

// Show auth modal with a contextual prompt instead of alert()
function showAuthPrompt(action) {
  const modal = document.getElementById('nameModalOverlay');
  if(!modal) return;
  // Flash the auth modal with a hint
  modal.classList.remove('hidden');
  switchAuthTab('signup');
  const tagline = document.querySelector('.auth-tagline');
  if(tagline && action) {
    const orig = tagline.textContent;
    tagline.textContent = `Sign up to ${action}`;
    tagline.style.color = 'var(--accent)';
    setTimeout(()=>{ tagline.textContent=orig; tagline.style.color=''; }, 3000);
  }
  setTimeout(()=>document.getElementById('signupName')?.focus(), 100);
}

// Beautiful confirm dialog replacing native confirm()
function showConfirm(title, body, onConfirm, confirmLabel='Confirm', danger=true) {
  const existing = document.getElementById('confirmModal');
  if(existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'confirmModal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:900;display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(4px);';

  overlay.innerHTML = `<div style="background:var(--card);border:1px solid var(--border);border-radius:14px;padding:24px;max-width:320px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.5);">
    <div style="font-size:16px;font-weight:800;margin-bottom:8px">${title}</div>
    <div style="font-size:12px;color:var(--muted);line-height:1.5;margin-bottom:20px">${body}</div>
    <div style="display:flex;gap:8px">
      <button id="confirmModalCancel" style="flex:1;padding:10px;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--muted);font-family:'DM Mono',monospace;font-size:10px;cursor:pointer">CANCEL</button>
      <button id="confirmModalOk" style="flex:1;padding:10px;background:${danger?'#ff4757':'var(--accent)'};border:none;border-radius:8px;color:${danger?'#fff':'#000'};font-family:'DM Mono',monospace;font-size:10px;font-weight:700;cursor:pointer">${confirmLabel.toUpperCase()}</button>
    </div>
  </div>`;

  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  overlay.addEventListener('click', e => { if(e.target===overlay) close(); });
  document.getElementById('confirmModalCancel').onclick = close;
  document.getElementById('confirmModalOk').onclick = () => { close(); onConfirm(); };
  document.getElementById('confirmModalOk').focus();
}

// ═══════════════════════════════════════════════════════
// GUEST → ACCOUNT PICK MIGRATION
// ═══════════════════════════════════════════════════════
// Called inside handleAuthSession when a guest upgrades
async function migrateGuestPicks(oldUserId, newUserId) {
  if(!oldUserId || !newUserId || oldUserId === newUserId) return;
  // Load picks from old guest key
  const guestKey = `ls_picks_${oldUserId}`;
  let guestPicks = [];
  try { guestPicks = JSON.parse(localStorage.getItem(guestKey)||'[]'); } catch{}
  if(!guestPicks.length) return;

  console.log(`📦 Migrating ${guestPicks.length} guest picks to new account…`);
  // Re-assign all picks to new user ID — they'll sync on next savePicks
  picks = [...guestPicks, ...picks.filter(p =>
    !guestPicks.some(gp => gp.gameId===p.gameId && gp.type===p.type && gp.side===p.side)
  )];
  localStorage.setItem(`ls_picks_${newUserId}`, JSON.stringify(picks));
  localStorage.removeItem(guestKey);
  await syncPicksToServer();
  showWinToast(`✅ ${guestPicks.length} picks migrated to your new account!`);
}

// ═══════════════════════════════════════════════════════
// MOBILE NAV — "MORE" DRAWER
// ═══════════════════════════════════════════════════════
function openMoreDrawer() {
  const existing = document.getElementById('moreDrawer');
  if(existing) { existing.remove(); return; }

  const drawer = document.createElement('div');
  drawer.id = 'moreDrawer';
  drawer.style.cssText = 'position:fixed;bottom:60px;left:0;right:0;background:rgba(8,12,16,.98);border-top:1px solid var(--border);z-index:175;padding:12px;backdrop-filter:blur(20px);display:grid;grid-template-columns:repeat(4,1fr);gap:8px;';

  const moreItems = [
    { label:'News',     icon:'📰', mode:'news' },
    { label:'Analytics',icon:'📊', mode:'analysis' },
    { label:'Pick\'em', icon:'🏆', mode:'contests' },
    { label:'History',  icon:'📋', mode:'history' },
    { label:'Battles',  icon:'⚔️', mode:'battles' },
    { label:'Feed',     icon:'👥', mode:'feed' },
    { label:'Bracket',  icon:'🏀', mode:'bracket' },
    { label:'Calendar', icon:'📅', mode:'calendar' },
  ];

  drawer.innerHTML = moreItems.map(item => `
    <button onclick="setMode('${item.mode}');closeMoreDrawer()" style="background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px 8px;display:flex;flex-direction:column;align-items:center;gap:4px;cursor:pointer;">
      <span style="font-size:18px">${item.icon}</span>
      <span style="font-family:'DM Mono',monospace;font-size:8px;color:var(--muted);letter-spacing:.5px">${item.label.toUpperCase()}</span>
    </button>`).join('');

  document.body.appendChild(drawer);

  // Close on outside click
  setTimeout(()=>{
    document.addEventListener('click', function handler(e){
      const btn = document.getElementById('mobBtnMore');
      if(!drawer.contains(e.target) && !btn?.contains(e.target)){
        drawer.remove();
        document.removeEventListener('click', handler);
      }
    });
  }, 10);
}

function closeMoreDrawer() {
  document.getElementById('moreDrawer')?.remove();
}

// ═══════════════════════════════════════════════════════
// LOADING STATES for Trends, Battles, Feed
// ═══════════════════════════════════════════════════════
function showViewLoader(containerId, msg='Loading…') {
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 20px;gap:12px">
    <div style="width:20px;height:20px;border:2px solid var(--dim);border-top-color:var(--accent);border-radius:50%;animation:spin 1s linear infinite"></div>
    <div style="font-family:'DM Mono',monospace;font-size:10px;color:var(--muted);letter-spacing:2px">${msg}</div>
  </div>`;
}



// ═══════════════════════════════════════════════════════
// BANKROLL CHART — full interactive SVG in Analysis view
// ═══════════════════════════════════════════════════════
function renderBankrollChart() {
  const wagered = picks.filter(p=>p.result!=='pending'&&p.wager).sort((a,b)=>a.madeAt-b.madeAt);
  if(wagered.length < 2) return `<div style="color:var(--dim);font-family:'DM Mono',monospace;font-size:11px;text-align:center;padding:20px">Make 2+ picks with wagers to see your chart</div>`;

  let running = STARTING_BANKROLL;
  const points = [{y: running, pick: null, date: null}];
  wagered.forEach(p => {
    if(p.result==='won') running += calcPayout(p.wager, p.odds||-110);
    else if(p.result==='lost') running -= p.wager;
    points.push({
      y: Math.max(0, Math.round(running)),
      pick: p,
      date: new Date(p.madeAt).toLocaleDateString([],{month:'short',day:'numeric'})
    });
  });

  const min = Math.min(...points.map(p=>p.y));
  const max = Math.max(...points.map(p=>p.y));
  const range = max - min || 100;
  const W = 400, H = 120, PAD = 8;
  const coords = points.map((p,i) => ({
    x: PAD + (i / (points.length-1)) * (W - PAD*2),
    y: PAD + (1 - (p.y - min) / range) * (H - PAD*2),
    ...p
  }));

  const path = coords.map((c,i) => i===0 ? `M${c.x},${c.y}` : `L${c.x},${c.y}`).join(' ');
  const fillPath = path + ` L${coords[coords.length-1].x},${H} L${PAD},${H} Z`;
  const lastVal = points[points.length-1].y;
  const color = lastVal >= STARTING_BANKROLL ? '#2ed573' : '#ff4757';
  const pnl = lastVal - STARTING_BANKROLL;
  const pnlStr = (pnl >= 0 ? '+' : '') + '$' + Math.abs(Math.round(pnl)).toLocaleString();

  // Dots for last few picks
  const dotHtml = coords.slice(-8).map(c => {
    const dc = c.pick?.result==='won' ? '#2ed573' : c.pick?.result==='lost' ? '#ff4757' : 'var(--gold)';
    return `<circle cx="${c.x}" cy="${c.y}" r="3" fill="${dc}" stroke="var(--card)" stroke-width="1.5"/>`;
  }).join('');

  // Baseline at $1000
  const baseY = PAD + (1 - (STARTING_BANKROLL - min) / range) * (H - PAD*2);
  const baseLine = baseY > PAD && baseY < H ? `<line x1="${PAD}" y1="${baseY}" x2="${W-PAD}" y2="${baseY}" stroke="rgba(255,255,255,.08)" stroke-width="1" stroke-dasharray="4,4"/>` : '';

  return `
    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:12px">
      <div>
        <div style="font-size:28px;font-weight:800;font-family:'Syne',sans-serif;color:${color}">${'$'+lastVal.toLocaleString()}</div>
        <div style="font-family:'DM Mono',monospace;font-size:10px;color:${color}">${pnlStr} all time</div>
      </div>
      <div style="text-align:right;font-family:'DM Mono',monospace;font-size:9px;color:var(--muted)">
        <div>START $${STARTING_BANKROLL.toLocaleString()}</div>
        <div>${wagered.length} PICKS</div>
      </div>
    </div>
    <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:${H}px;overflow:visible">
      <defs>
        <linearGradient id="bankGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${color}" stop-opacity=".25"/>
          <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
        </linearGradient>
      </defs>
      ${baseLine}
      <path d="${fillPath}" fill="url(#bankGrad)"/>
      <path d="${path}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
      ${dotHtml}
    </svg>
    <div style="display:flex;justify-content:space-between;font-family:'DM Mono',monospace;font-size:9px;color:var(--dim);margin-top:6px">
      <span>${points[1]?.date||''}</span>
      <span>— — — $${STARTING_BANKROLL.toLocaleString()} baseline — — —</span>
      <span>TODAY</span>
    </div>`;
}

// ═══════════════════════════════════════════════════════
// MY ACTION VIEW — Focused view of all games user has picks on
// Shows live games first, then upcoming, then recently settled
// ═══════════════════════════════════════════════════════
function renderMyActionView(){
  const el = document.getElementById('myactionContent');
  if(!el) return;

  const pendingPicks = picks.filter(p => p.result === 'pending' && p.type !== 'parlay');
  const todaySettled = picks.filter(p => p.result !== 'pending' && p.type !== 'parlay' && p.madeAt && (Date.now() - p.madeAt < 86400000));

  if(!pendingPicks.length && !todaySettled.length){
    el.innerHTML = `<div class="myaction-hdr">
      <div><div class="myaction-title">🎯 My Action</div><div class="myaction-subtitle">GAMES WITH YOUR PICKS</div></div>
    </div>
    <div class="myaction-empty">
      <div class="myaction-empty-icon">🎯</div>
      NO ACTIVE PICKS<br><br>
      <span style="color:var(--dim)">Make some picks from the Scores tab<br>and they'll appear here</span><br><br>
      <button onclick="setMode('scores')" style="background:var(--accent);color:#000;border:none;border-radius:6px;padding:8px 20px;font-family:'DM Mono',monospace;font-size:10px;font-weight:700;cursor:pointer;letter-spacing:1px">BROWSE GAMES →</button>
    </div>`;
    return;
  }

  // Group picks by game
  const gamePickMap = {};
  [...pendingPicks, ...todaySettled].forEach(p => {
    const gid = p.gameId;
    if(!gamePickMap[gid]) gamePickMap[gid] = {picks:[], game: allGames.find(g=>g.id===gid)};
    gamePickMap[gid].picks.push(p);
  });

  // Categorize
  const liveEntries = [], upcomingEntries = [], settledEntries = [];
  Object.values(gamePickMap).forEach(entry => {
    const g = entry.game;
    if(!g){
      // Game not in cache — might be from a different date
      const hasSettled = entry.picks.some(p=>p.result!=='pending');
      if(hasSettled) settledEntries.push(entry);
      else upcomingEntries.push(entry);
      return;
    }
    if(g.isLive) liveEntries.push(entry);
    else if(g.isPre) upcomingEntries.push(entry);
    else settledEntries.push(entry);
  });

  // Summary stats
  const dayPicks = [...pendingPicks, ...todaySettled];
  const dayWon = dayPicks.filter(p=>p.result==='won').length;
  const dayLost = dayPicks.filter(p=>p.result==='lost').length;
  let dayPnL = 0;
  dayPicks.forEach(p => {
    if(p.result==='won' && p.wager) dayPnL += calcPayout(p.wager, p.odds||-110);
    else if(p.result==='lost' && p.wager) dayPnL -= p.wager;
  });
  const pnlClass = dayPnL > 0 ? 'pos' : dayPnL < 0 ? 'neg' : 'even';
  const pnlStr = (dayPnL >= 0 ? '+' : '') + '$' + Math.abs(Math.round(dayPnL));
  const todaysLock = getTodaysLock();

  let html = `<div class="myaction-hdr">
    <div>
      <div class="myaction-title">🎯 My Action</div>
      <div class="myaction-subtitle">${dayPicks.length} PICK${dayPicks.length!==1?'S':''} TODAY</div>
    </div>
    <div class="myaction-pnl ${pnlClass}">${pnlStr}</div>
  </div>`;

  // Summary cards
  html += `<div class="myaction-summary">
    <div class="myaction-stat"><div class="myaction-stat-val" style="color:var(--green)">${liveEntries.length}</div><div class="myaction-stat-lbl">LIVE</div></div>
    <div class="myaction-stat"><div class="myaction-stat-val" style="color:var(--gold)">${upcomingEntries.length}</div><div class="myaction-stat-lbl">UPCOMING</div></div>
    <div class="myaction-stat"><div class="myaction-stat-val">${dayWon}W-${dayLost}L</div><div class="myaction-stat-lbl">TODAY</div></div>
  </div>`;

  // Today's Lock callout
  if(todaysLock){
    html += `<div style="background:rgba(255,165,2,.06);border:1px solid rgba(255,165,2,.2);border-radius:8px;padding:10px 12px;margin-bottom:14px;display:flex;align-items:center;gap:10px">
      <span style="font-size:20px">🔒</span>
      <div style="flex:1">
        <div style="font-family:'DM Mono',monospace;font-size:8px;color:var(--gold);letter-spacing:1.5px;margin-bottom:2px">LOCK OF THE DAY</div>
        <div style="font-size:12px;font-weight:700">${todaysLock.description}</div>
        ${todaysLock.wager?`<div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:2px">💰 $${todaysLock.wager} to win +$${calcPayout(todaysLock.wager,todaysLock.odds||-110)}</div>`:''}
      </div>
      <span style="font-family:'DM Mono',monospace;font-size:10px;color:${todaysLock.result==='won'?'var(--green)':todaysLock.result==='lost'?'var(--red)':'var(--gold)'}">${todaysLock.result==='pending'?'PENDING':todaysLock.result.toUpperCase()}</span>
    </div>`;
  }

  function renderActionCard(entry, category){
    const g = entry.game;
    const gameName = g ? `${g.away.name} @ ${g.home.name}` : (entry.picks[0]?.gameStr || 'Unknown Game');
    const scoreText = g && !g.isPre ? `${g.away.score} — ${g.home.score}` : '';
    const statusText = g ? (g.isLive ? g.statusText : g.isPre ? g.startTime : 'FINAL') : '';

    let cardsHtml = `<div class="myaction-card ${category}" onclick="${g?`openGame('${g.id}')`:''}">
      <div class="myaction-game">
        <div>
          <div class="myaction-teams">${gameName}</div>
          <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:2px">${entry.picks[0]?.league||''} · ${statusText}</div>
        </div>
        ${scoreText?`<div class="myaction-score">${scoreText}</div>`:''}
      </div>`;

    entry.picks.forEach(p => {
      let statusClass = '', statusLabel = '';
      if(p.result === 'won'){ statusClass='won'; statusLabel='✅ WON'; }
      else if(p.result === 'lost'){ statusClass='lost'; statusLabel='❌ LOST'; }
      else if(p.result === 'push'){ statusClass='push'; statusLabel='↔ PUSH'; }
      else if(g && g.isLive){
        const cov = evaluateCovering(p, g);
        if(cov === true){ statusClass='covering'; statusLabel='✅ COVERING'; }
        else if(cov === false){ statusClass='losing'; statusLabel='⚠️ LOSING'; }
        else{ statusClass='push'; statusLabel='↔ PUSH'; }
      } else {
        statusClass='pending'; statusLabel='⏳ PENDING';
      }

      cardsHtml += `<div class="myaction-pick-row">
        ${p.isLock?'<span class="lock-badge"><span class="lock-badge-sm">🔒</span>LOCK</span>':''}
        <div class="myaction-pick-desc">${p.description}</div>
        <span class="myaction-status ${statusClass}">${statusLabel}</span>
        ${p.wager?`<span class="myaction-wager">$${p.wager}</span>`:''}
      </div>`;
    });

    cardsHtml += `</div>`;
    return cardsHtml;
  }

  if(liveEntries.length){
    html += `<div class="myaction-section-title"><span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--green);animation:pulse 1.2s infinite"></span> LIVE — ${liveEntries.length} GAME${liveEntries.length!==1?'S':''}</div>`;
    liveEntries.forEach(e => { html += renderActionCard(e, 'live'); });
  }

  if(upcomingEntries.length){
    html += `<div class="myaction-section-title">UPCOMING — ${upcomingEntries.length} GAME${upcomingEntries.length!==1?'S':''}</div>`;
    upcomingEntries.forEach(e => { html += renderActionCard(e, 'upcoming'); });
  }

  if(settledEntries.length){
    html += `<div class="myaction-section-title">SETTLED TODAY</div>`;
    settledEntries.forEach(e => { html += renderActionCard(e, 'settled'); });
  }

  el.innerHTML = html;
}

// ═══════════════════════════════════════════════════════
// LIVE PICK TRACKER BAR
// ═══════════════════════════════════════════════════════
function renderLivePickBar() {
  // Find pending picks on live games
  const liveGames = allGames.filter(g => g.isLive);
  if(!liveGames.length) {
    document.getElementById('livePickBar')?.remove();
    return;
  }

  const livePicks = picks.filter(p => {
    if(p.result !== 'pending') return false;
    return liveGames.some(g => g.id === p.gameId || g.id === p.actualGameId);
  });

  if(!livePicks.length) {
    document.getElementById('livePickBar')?.remove();
    return;
  }

  let bar = document.getElementById('livePickBar');
  if(!bar) {
    bar = document.createElement('div');
    bar.id = 'livePickBar';
    bar.style.cssText = 'position:sticky;top:0;z-index:160;background:rgba(8,12,16,.97);border-bottom:1px solid rgba(46,213,115,.2);backdrop-filter:blur(10px);overflow:hidden;';
    // Insert before slateSummary
    const slate = document.getElementById('slateSummary');
    if(slate) slate.before(bar);
    else document.getElementById('scoresView')?.prepend(bar);
  }

  const items = livePicks.map(p => {
    const g = liveGames.find(x => x.id === p.gameId || x.id === p.actualGameId);
    if(!g) return '';
    const hs = g.home.score, as2 = g.away.score;
    const mySide = p.side;
    const isCovering = evaluateCovering(p, g);
    const statusColor = isCovering === true ? '#2ed573' : isCovering === false ? '#ff4757' : 'var(--gold)';
    const statusIcon = isCovering === true ? '✅' : isCovering === false ? '⚠️' : '⏳';
    return `<div style="display:flex;align-items:center;gap:8px;padding:6px 12px;border-bottom:1px solid rgba(255,255,255,.04);cursor:pointer" onclick="openGame('${g.id}')">
      <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#2ed573;animation:pulse 1.2s infinite;flex-shrink:0"></span>
      <span style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);flex-shrink:0">${g.statusText}</span>
      <span style="font-family:'DM Mono',monospace;font-size:10px;font-weight:700;flex:1;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">${g.away.abbr} ${as2} — ${g.home.abbr} ${hs}</span>
      <span style="font-size:9px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:140px">${p.description}</span>
      <span style="font-family:'DM Mono',monospace;font-size:9px;color:${statusColor};flex-shrink:0">${statusIcon} ${isCovering===true?'COVERING':isCovering===false?'LOSING':'PUSH'}</span>
    </div>`;
  }).join('');

  bar.innerHTML = `<div style="font-family:'DM Mono',monospace;font-size:8px;letter-spacing:2px;color:#2ed573;padding:4px 12px;display:flex;align-items:center;gap:6px">
    <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#2ed573;animation:pulse 1.2s infinite"></span>
    LIVE — ${livePicks.length} PICK${livePicks.length!==1?'S':''} IN ACTION
  </div>${items}`;
}

// Evaluate if a pending pick is currently covering
function evaluateCovering(pick, game) {
  if(!game.isLive) return null;
  const hs = parseInt(game.home.score) || 0;
  const as2 = parseInt(game.away.score) || 0;
  try {
    if(pick.type === 'spread') {
      const line = parseFloat((pick.description||'').match(/([+-][\d.]+)/)?.[1] || '0');
      const isHome = pick.side?.includes(game.home.name) || pick.side?.includes(game.home.abbr);
      const margin = isHome ? hs - as2 : as2 - hs;
      const adjusted = margin + line;
      if(Math.abs(adjusted) < 0.5) return null; // push territory
      return adjusted > 0;
    } else if(pick.type === 'total') {
      const total = hs + as2;
      const line = parseFloat((pick.description||'').match(/([\d.]+)/)?.[1] || '0');
      const isOver = pick.side?.toLowerCase().includes('over') || pick.description?.toLowerCase().includes('over');
      if(Math.abs(total - line) < 0.5) return null;
      return isOver ? total > line : total < line;
    }
  } catch(e) {}
  return null;
}

// ═══════════════════════════════════════════════════════
// WIN SHARE PROMPT
// ═══════════════════════════════════════════════════════
function showWinSharePrompt(pick) {
  // Delay slightly so confetti plays first
  setTimeout(() => {
    const existing = document.getElementById('winSharePrompt');
    if(existing) existing.remove();

    const profit = pick.wager ? `+$${calcPayout(pick.wager, pick.odds||-110)}` : '';
    const overlay = document.createElement('div');
    overlay.id = 'winSharePrompt';
    overlay.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);z-index:500;width:calc(100% - 32px);max-width:360px;';

    overlay.innerHTML = `<div style="background:linear-gradient(135deg,rgba(46,213,115,.15),rgba(0,229,255,.08));border:1px solid rgba(46,213,115,.3);border-radius:14px;padding:16px;backdrop-filter:blur(20px);box-shadow:0 20px 60px rgba(0,0,0,.6)">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
        <span style="font-size:24px">🏆</span>
        <div>
          <div style="font-size:13px;font-weight:800">Winner! ${profit}</div>
          <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:2px">${pick.description}</div>
        </div>
        <button onclick="document.getElementById('winSharePrompt').remove()" style="margin-left:auto;background:none;border:none;color:var(--dim);cursor:pointer;font-size:16px;flex-shrink:0">✕</button>
      </div>
      <div style="display:flex;gap:8px">
        <button onclick="shareWin(${JSON.stringify(pick).replace(/"/g,'&quot;')})" style="flex:1;padding:9px;background:rgba(46,213,115,.15);border:1px solid rgba(46,213,115,.3);border-radius:8px;color:#2ed573;font-family:'DM Mono',monospace;font-size:9px;font-weight:700;cursor:pointer;letter-spacing:1px">📤 SHARE WIN</button>
        <button onclick="postWinToFeed(${JSON.stringify(pick).replace(/"/g,'&quot;')})" style="flex:1;padding:9px;background:rgba(0,229,255,.08);border:1px solid rgba(0,229,255,.15);border-radius:8px;color:var(--accent);font-family:'DM Mono',monospace;font-size:9px;font-weight:700;cursor:pointer;letter-spacing:1px">📢 POST TO FEED</button>
      </div>
    </div>`;

    document.body.appendChild(overlay);
    setTimeout(() => overlay.remove(), 8000); // auto-dismiss
  }, 1500);
}

function shareWin(pick) {
  document.getElementById('winSharePrompt')?.remove();
  sharePickCard({...pick, name: currentUser?.name});
}

function postWinToFeed(pick) {
  document.getElementById('winSharePrompt')?.remove();
  // Already published via publishToLeaderboard — just show confirmation
  publishToLeaderboard();
  showWinToast('📢 Shared to feed!');
}

// ═══════════════════════════════════════════════════════
// GLOBAL SEARCH
// ═══════════════════════════════════════════════════════
// (hoisted to top)

function toggleSearch() {
  searchOpen = !searchOpen;
  let panel = document.getElementById('globalSearchPanel');
  if(!searchOpen) { panel?.remove(); return; }
  if(panel) return;

  panel = document.createElement('div');
  panel.id = 'globalSearchPanel';
  panel.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:600;background:rgba(0,0,0,.92);backdrop-filter:blur(10px);display:flex;flex-direction:column;padding:16px;';
  panel.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
      <input id="globalSearchInput" type="search" placeholder="Search games, teams, your picks…"
        style="flex:1;background:var(--card);border:1px solid var(--accent);border-radius:10px;padding:12px 16px;color:var(--text);font-size:15px;outline:none;font-family:'DM Sans',sans-serif"
        oninput="runSearch(this.value)" autocomplete="off" spellcheck="false">
      <button onclick="toggleSearch()" style="background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;padding:8px">✕</button>
    </div>
    <div id="searchResults" style="overflow-y:auto;flex:1"></div>`;

  document.body.appendChild(panel);
  setTimeout(() => document.getElementById('globalSearchInput')?.focus(), 50);

  // ESC to close
  panel._escHandler = e => { if(e.key==='Escape') toggleSearch(); };
  document.addEventListener('keydown', panel._escHandler);
}

function runSearch(q) {
  const el = document.getElementById('searchResults');
  if(!el) return;
  const query = q.trim().toLowerCase();
  if(!query) { el.innerHTML = renderSearchPlaceholder(); return; }

  const results = [];

  // Search games
  allGames.forEach(g => {
    if(g.home.name.toLowerCase().includes(query) || g.away.name.toLowerCase().includes(query) ||
       g.home.abbr.toLowerCase().includes(query) || g.away.abbr.toLowerCase().includes(query)) {
      results.push({ type: 'game', g, score: g.isLive ? 3 : g.isPre ? 2 : 1 });
    }
  });

  // Search pick history
  picks.filter(p => p.result!=='pending').forEach(p => {
    if(p.description?.toLowerCase().includes(query) || p.gameStr?.toLowerCase().includes(query) ||
       p.league?.toLowerCase().includes(query)) {
      results.push({ type: 'pick', p, score: 0 });
    }
  });

  results.sort((a,b) => b.score - a.score);

  if(!results.length) {
    el.innerHTML = `<div style="text-align:center;padding:40px;color:var(--dim);font-family:'DM Mono',monospace;font-size:11px">No results for "${q}"</div>`;
    return;
  }

  const games = results.filter(r=>r.type==='game').slice(0,8);
  const pickResults = results.filter(r=>r.type==='pick').slice(0,6);

  let html = '';
  if(games.length) {
    html += `<div style="font-family:'DM Mono',monospace;font-size:8px;letter-spacing:2px;color:var(--muted);margin-bottom:8px">GAMES</div>`;
    html += games.map(({g}) => `<div onclick="closeSearchAndOpen('${g.id}')" style="background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:8px;cursor:pointer;display:flex;align-items:center;justify-content:space-between">
      <div>
        <div style="font-size:12px;font-weight:700">${g.away.name} <span style="color:var(--muted)">@</span> ${g.home.name}</div>
        <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:3px">${g.leagueLabel} · ${g.isLive?'<span style="color:#2ed573">LIVE</span>':g.isFinal?'Final':g.startTime}</div>
      </div>
      ${g.isLive?`<div style="font-weight:700">${g.away.score}—${g.home.score}</div>`:''}
    </div>`).join('');
  }
  if(pickResults.length) {
    html += `<div style="font-family:'DM Mono',monospace;font-size:8px;letter-spacing:2px;color:var(--muted);margin:16px 0 8px">YOUR PICKS</div>`;
    html += pickResults.map(({p}) => `<div style="background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
      <div>
        <div style="font-size:11px;font-weight:600">${p.description}</div>
        <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:3px">${p.league||''} · ${new Date(p.madeAt).toLocaleDateString()}</div>
      </div>
      <span style="font-family:'DM Mono',monospace;font-size:9px;padding:3px 8px;border-radius:4px;background:${p.result==='won'?'rgba(46,213,115,.12)':p.result==='lost'?'rgba(255,71,87,.1)':'rgba(255,255,255,.05)'};color:${p.result==='won'?'#2ed573':p.result==='lost'?'#ff4757':'var(--muted)'}">${p.result.toUpperCase()}</span>
    </div>`).join('');
  }
  el.innerHTML = html;
}

function renderSearchPlaceholder() {
  const pending = picks.filter(p=>p.result==='pending').length;
  const liveCount = allGames.filter(g=>g.isLive).length;
  return `<div style="padding:8px 0;font-family:'DM Mono',monospace;font-size:10px;color:var(--muted)">
    ${liveCount?`<div onclick="closeSearchAndMode('scores')" style="padding:10px;border-radius:8px;margin-bottom:6px;cursor:pointer;background:rgba(46,213,115,.06);border:1px solid rgba(46,213,115,.1)">🟢 ${liveCount} game${liveCount!==1?'s':''} live right now</div>`:''}
    ${pending?`<div onclick="toggleSearch();openPanel()" style="padding:10px;border-radius:8px;margin-bottom:6px;cursor:pointer;background:var(--card);border:1px solid var(--border)">🎯 You have ${pending} pending pick${pending!==1?'s':''}</div>`:''}
    <div style="color:var(--dim);text-align:center;padding:20px;letter-spacing:1px">TYPE TO SEARCH TEAMS · GAMES · PICKS</div>
  </div>`;
}

function closeSearchAndOpen(gameId) {
  toggleSearch();
  searchOpen = false;
  setMode('scores');
  setTimeout(() => openGame(gameId), 200);
}

function closeSearchAndMode(mode) {
  toggleSearch();
  searchOpen = false;
  setMode(mode);
}

// ═══════════════════════════════════════════════════════
// DAILY DIGEST NOTIFICATION
// ═══════════════════════════════════════════════════════
function scheduleDailyDigest() {
  if(pushPermission !== 'granted') return;
  const now = new Date();
  const sentKey = `digest_sent_${now.toISOString().slice(0,10)}`;
  if(localStorage.getItem(sentKey)) return;

  const hour = now.getHours();
  // Send between 9-11am local time
  if(hour < 9 || hour > 11) return;

  localStorage.setItem(sentKey, '1');

  // Build digest message
  const todayGames = allGames.filter(g => g.isPre || g.isLive);
  const pendingPicks = picks.filter(p => p.result === 'pending');
  const bankroll = computeBankroll();
  const pnl = bankroll - STARTING_BANKROLL;
  const streak = calcPickStats(picks);

  let title = '📊 SharpPick Daily Briefing';
  let body = '';

  if(todayGames.length && pendingPicks.length) {
    body = `${todayGames.length} games today · ${pendingPicks.length} picks live · $${Math.round(bankroll).toLocaleString()} bankroll`;
  } else if(todayGames.length) {
    body = `${todayGames.length} games on today's slate · Bankroll: $${Math.round(bankroll).toLocaleString()}${pnl!==0?' ('+((pnl>0?'+':'')+'$'+Math.round(pnl))+')':''}`;
  } else {
    body = `Bankroll: $${Math.round(bankroll).toLocaleString()} · ${streak.curStreak>1?streak.curStreak+'-pick win streak · ':''}Check today's slate`;
  }

  if(streak.curStreak >= 3) title = `🔥 ${streak.curStreak}-pick streak! · ${title}`;

  sendPushNotification(title, body, 'daily-digest');
}

// ═══════════════════════════════════════════════════════
// IMPROVED EMPTY STATES
// ═══════════════════════════════════════════════════════
function getBestGameToday() {
  // Return the game with the most props/action for empty state CTA
  const preGames = allGames.filter(g => g.isPre);
  if(!preGames.length) return allGames[0] || null;
  // Prefer games with odds
  return preGames.find(g => g.odds?.spread) || preGames[0];
}

function emptyPicksHTML() {
  const game = getBestGameToday();
  if(!game) {
    return `<div class="no-picks">NO PICKS YET<br><br><small style="font-size:10px;color:var(--dim)">Browse today's games and tap any card to get started</small></div>`;
  }
  const hasOdds = game.odds?.spread;
  return `<div class="no-picks" style="padding:24px">
    <div style="font-size:28px;margin-bottom:12px">🎯</div>
    <div style="font-size:13px;font-weight:700;margin-bottom:6px">No picks yet</div>
    <div style="font-size:11px;color:var(--dim);margin-bottom:20px">Tap a game card to pick spreads, totals, and props</div>
    <div onclick="closePanel();setMode('scores');setTimeout(()=>openGame('${game.id}'),200)" style="background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px;cursor:pointer;text-align:left">
      <div style="font-family:'DM Mono',monospace;font-size:8px;color:var(--muted);margin-bottom:6px">FEATURED GAME · TAP TO PICK</div>
      <div style="font-size:12px;font-weight:700;margin-bottom:4px">${game.away.name} @ ${game.home.name}</div>
      <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted)">${game.leagueLabel} · ${game.startTime}${hasOdds?' · '+game.odds.spread:''}</div>
    </div>
  </div>`;
}

// ═══════════════════════════════════════════════════════
// LEAGUE PERSONALITY — name + emoji in header
// ═══════════════════════════════════════════════════════
function renderLeagueHeader(league) {
  if(!league) return '';
  const emoji = league.emoji || '🏆';
  const name = league.name || 'My League';
  const memberCount = league.members?.length || 0;
  const myRank = league.members ? (() => {
    const sorted = [...league.members].sort((a,b)=>(b.w||0)-(a.w||0));
    const idx = sorted.findIndex(m=>m.id===currentUser?.id);
    return idx >= 0 ? idx+1 : null;
  })() : null;

  return `<div style="background:linear-gradient(135deg,rgba(0,229,255,.06),rgba(138,43,226,.04));border-bottom:1px solid var(--border);padding:16px">
    <div style="display:flex;align-items:center;gap:12px">
      <div style="font-size:32px">${emoji}</div>
      <div style="flex:1">
        <div style="font-size:18px;font-weight:800">${name}</div>
        <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--muted);margin-top:2px">
          ${memberCount} MEMBER${memberCount!==1?'S':''} ${myRank?'· YOU ARE #'+myRank:''}
        </div>
      </div>
      <button onclick="copyLeagueLink('${league.id}')" style="background:rgba(0,229,255,.08);border:1px solid rgba(0,229,255,.15);border-radius:8px;padding:7px 12px;color:var(--accent);font-family:'DM Mono',monospace;font-size:8px;cursor:pointer;letter-spacing:1px">🔗 INVITE</button>
    </div>
    ${myRank === 1 ? `<div style="margin-top:10px;font-family:'DM Mono',monospace;font-size:9px;color:var(--gold)">👑 You're leading this league. Don't let up.</div>` :
      myRank ? `<div style="margin-top:10px;font-family:'DM Mono',monospace;font-size:9px;color:var(--muted)">You're #${myRank}. ${myRank===2?'One spot from the top.':myRank<=4?'In the hunt.':'Keep picking.'}</div>` : ''}
  </div>`;
}



